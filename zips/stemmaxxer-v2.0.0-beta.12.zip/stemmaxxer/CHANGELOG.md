# STEMMAXXER — Changelog

High-level summary of each build, newest first (mirrors the in-app Workbench → Changelog tab).

## 2.0.0-beta.12
STEMMAXXER now updates itself from its own GitHub release channel — new builds appear as normal one-click updates in wp-admin (with check-now, beta/stable channel switch, and one-click rollback on the Plugins screen). No more manual zip uploads.

## 2.0.0-beta.11
Lock-screen Now-Playing artwork is now the STEMMAXXER album cover (was the low-res site favicon), with the current song’s title and artist. The widget’s play/pause, skip, and scrub controls drive the player. iOS + Android (Media Session API).

## 2.0.0-beta.10
Mobile transport gains Restart and Reset buttons (same behavior as desktop): Restart jumps to the start and keeps playing; Reset stops, clears mute/solo/feature, returns faders to default, and clears the loop.

## 2.0.0-beta.9
Mobile: left-justified track names + a LOADING screen that blocks play until a switched song fully loads (fixes out-of-sync playback). Desktop: track names match the channel-number size; new Workbench Fader-width control widens the LED track + handle (deployable).

## 2.0.0-beta.8
Mobile view shows the build version next to the STEMMAXXER LITE logo.

## 2.0.0-beta.7
Mobile track header redesign: +/− and M/S become full-height edge controls fused to the strip frame, name centered between them; the active control tints the whole frame (focus > solo > mute), with a focused strip showing solo/mute as a detached inset pill. MUTE is now blue instead of red, desktop included.

## 2.0.0-beta.6
Fader Style (LED Ladder / Solid Fill) from the Workbench now applies to the mobile view too — deploy Solid Fill and the mobile faders match, same zone colors and thresholds as desktop.

## 2.0.0-beta.5
More reliable song loading: stems retry with backoff instead of giving up on the first hiccup, and load a few at a time (steadier on mobile/Firefox). On mobile a failed stem shows a FILE ERROR / RETRY button to reload just that part.

## 2.0.0-beta.4
LITE mobile: double-tap speed % to reset to 100%, loop controls centered as one cluster, playback bar timeline ticks (matching desktop), and the volume handle stays clear of the M/S buttons. Desktop: Learn button is now RTFM with a manual icon.

## 2.0.0-beta.3
LITE mobile A/B section looping: tap A / B on the playback bar to loop just a section (draggable flags, shaded region, ⟳ to arm, ✕ to clear); no A/B = whole song.

## 2.0.0-beta.2
LITE mobile polish: a visible + FOCUS button per channel (flips to −), speed as −/nn%/+ with + capped at 100%, channels renumbered (Drums = 1), and a chunkier high-contrast slider handle with the meter clamped so it never passes the handle.

## 2.0.0-beta.1
STEMMAXXER LITE (beta): a finger-friendly mobile mixer. On phones the new CONSOLE view replaces the “open on desktop” screen with big touch faders, mute/solo, tap-a-name to FOCUS a part, loop, speed, and count-in/click chips — same songs, same engine. Turn on device preview to try it; Publish when ready. PADS view + skin picker next.

## 1.14.35
On phones, the "Optimized for desktop" screen now has a "Use it here anyway" button that opens the full mixer on your phone (handy for testing) — remembered on that device. The dedicated mobile view is coming in v2.0.

## 1.14.34
iPhone fix: songs now play even with Silent Mode on — the mixer declares itself media playback and keeps a silent loop alive, so the ring/silent switch no longer mutes the stems.

## 1.14.33
Fixed the empty resource-type dropdown in Settings → STEMMAXXER when adding a new resource row.

## 1.14.32
NEW Changelog tab in the Workbench (this list).

## 1.14.31
Footer tagline and the Report-a-bug / Request-a-feature links now share one line.

## 1.14.30
Bandmates can edit any mixer-added resource — its label, description, link or type.

## 1.14.29
“Report a bug” and “Request a feature” links in the footer email Chris directly.

## 1.14.28
Fixed typing in a resource’s Label/Description fields (the song typeahead was stealing keystrokes).

## 1.14.27
Footer redone as a cleaner, more readable two-line stack.

## 1.14.26
Optional short description under each resource link.

## 1.14.25
Resources list widened, lighter panel with an orange frame, and dims the mixer behind it — plus Workbench controls to tune it.

## 1.14.24
Fixed the band resource Add form (all fields visible); type now auto-detects from the link.

## 1.14.23
Song banner and Resources became one flush, segmented bar.

## 1.14.22
Moved Resources up into the song banner, out of the crowded transport.

## 1.14.21
NEW per-song Resources — labeled links per song; bandmates can add their own.

## 1.14.20
The whole Workbench is now behind your deploy passkey.

## 1.14.19
NEW Workbench “Traffic” tab — a light per-day page hit counter.

## 1.14.18
Song titles now keep punctuation the file name can’t hold (parentheses, apostrophes, ampersands).

## 1.14.17
New Reset button icon (mixer-faders glyph) so it no longer reads as “stop”.

## 1.14.16
Publishing a beta feature to the band is now one-way and permanent (“baked in”).

## 1.14.15
The A and B loop flags can be dragged along the playback bar.

## 1.14.14
Workbench control for the A/B marker color; fixed deploy of the playback-handle colors.

## 1.14.13
“Add stem to existing song” on the on-site Add page.

## 1.14.12
Playback bar shows a subtle timeline ruler.

## 1.14.11
Workbench cleanup (retired the old EQ controls).

## 1.14.10
A/B looping graduated to a permanent feature; published features now persist across updates.

## 1.14.9
NEW band/song banner selector (beta); an A/B loop clear button.

## 1.14.8
Workbench controls for the playback-bar drag handle.

## 1.14.7
Playback-bar drag handle restyled (flat, hamburger lines).

## 1.14.6
Beta/Preview became per-feature; A/B position flags; a taller playback bar.

## 1.14.5
Workbench Beta list shows exactly which features are still unpublished.

## 1.14.4
The “Learn” (teacher mode) button moved to the far right.

## 1.14.3
Channel “+” feature buttons turned accent orange.

## 1.14.2
Fixed the Preview / Publish buttons in the Workbench.

## 1.14.1
Song selector no longer squashed by a crowded transport.

## 1.14.0
NEW Charts/Lesson links per song, A/B section looping (beta), and the beta/preview channel.

## 1.13.0
Each channel’s “+” feature button moved into that channel’s header.

## 1.12.0
NEW “Click” / metronome channel.

## 1.11.x
NEW Teacher mode (“Learn” — hover any control for a plain-English explanation); no more Save-Permalinks step.

## 1.10.x
NEW on-site “Add a Song” page — convert Logic exports and upload right in the browser, passkey-gated.

## 1.9.0
NEW Band__Song__Instrument naming (no track numbers); alphabetical selector; the companion Stem Converter tool.

## 1.8.x
Deploy-live settings, a drag grip on the playback bar, a one-line keyboard legend, and polish.

## 1.7.0
The banner shows a live EQ visualization of the playing mix.

## 1.6.x
NEW now-loaded song banner (BAND — TITLE) and a master volume slider.

## 1.5.x
Deploy Settings Live; the Workbench became fully hidden (Shift+W only).

## 1.4.0
Playback bar taller and clickable; a silence watchdog.

## 1.3.0
NEW pitch-preserved slow-down speed; automatic BPM detection.

## 1.2.x
NEW live LED meters; a feature “+” button per stem; a meter-range control.

## 1.1.0
NEW Workbench panel; LED-ladder faders; full-width logo.

## 1.0.0
Initial release — the vertical channel-strip stem mixer.
