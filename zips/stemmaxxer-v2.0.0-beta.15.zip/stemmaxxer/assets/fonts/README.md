# STEMMAXXER self-hosted fonts

These three families were formerly loaded from `fonts.googleapis.com` /
`fonts.gstatic.com`. Third-party privacy browsers (e.g. **Firefox Focus**)
block cross-origin font requests, which dropped every webfont and let the
Big Shoulders / mono stacks fall back to a serif (Times / Courier). Serving
the fonts **same-origin** from here sidesteps that blocking entirely
(same-origin requests are never third-party), and `font-display:swap`
guarantees text paints immediately either way.

All three are **variable** fonts, so a single latin-subset `.woff2` per
family covers every weight the player uses.

| File | Family | Weights used | Subset | Size |
|---|---|---|---|---|
| `bricolage-grotesque-latin.woff2` | Bricolage Grotesque | 400–800 (variable) | latin | ~75 KB |
| `jetbrains-mono-latin.woff2` | JetBrains Mono | 400 / 500 / 700 (variable) | latin | ~31 KB |
| `big-shoulders-display-latin.woff2` | Big Shoulders Display | 600 / 700 / 800 (variable) | latin | ~35 KB |

Total added zip weight ≈ **140 KB** (`bin/build-zip.sh` already copies
`assets/`, so they ship automatically).

## Provenance

Downloaded from Google Fonts' `css2` API (latin unicode-range block only,
`v24` / `v9` files) — the exact same binaries Google served before.
`unicode-range` is latin: `U+0000-00FF` plus the usual punctuation set.

## Licenses

All three are licensed under the **SIL Open Font License, Version 1.1**.
The full license text for each is included alongside the fonts:

- `OFL-BigShouldersDisplay.txt` — Copyright 2019 The Big Shoulders Project Authors
- `OFL-JetBrainsMono.txt` — Copyright 2020 The JetBrains Mono Project Authors
- `OFL-BricolageGrotesque.txt` — Copyright 2022 The Bricolage Grotesque Project Authors
