<?php if (!defined('ABSPATH')) exit; /* @var bool $smx_failed */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>STEMMAXXER</title>
<style>
  /* Self-hosted fonts (assets/fonts/) — same-origin so privacy browsers that
     block third-party requests (Firefox Focus) keep them. Variable → one woff2. */
  @font-face{font-family:'JetBrains Mono';font-style:normal;font-weight:400 700;font-display:swap;
    src:url('<?php echo esc_url($smx_fonts_url); ?>/jetbrains-mono-latin.woff2') format('woff2');}
  @font-face{font-family:'Big Shoulders Display';font-style:normal;font-weight:600 800;font-display:swap;
    src:url('<?php echo esc_url($smx_fonts_url); ?>/big-shoulders-display-latin.woff2') format('woff2');}
  *{box-sizing:border-box;}
  body{
    margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;
    background:radial-gradient(900px 500px at 50% -10%, #1c1c20 0%, #141416 60%);
    font-family:'JetBrains Mono',ui-monospace,'SF Mono',SFMono-Regular,Menlo,Consolas,monospace;color:#e9e9ec;padding:20px;
  }
  .gate{
    width:100%;max-width:380px;text-align:center;
    background:#202027;border:2px solid #50505c;border-radius:12px;
    padding:36px 30px;box-shadow:0 24px 60px rgba(0,0,0,.55);
  }
  .wm{font-family:'Big Shoulders Display','Arial Narrow','Roboto Condensed',system-ui,sans-serif;font-weight:800;font-size:32px;letter-spacing:.06em;color:#c9c9cf;}
  .wm .xx{color:#ef7d1c;}
  .sub{font-size:9px;letter-spacing:.28em;color:#63636d;text-transform:uppercase;margin:4px 0 26px;}
  input[type=password]{
    width:100%;padding:11px 14px;border-radius:8px;border:1px solid #50505c;
    background:#141418;color:#e9e9ec;font-family:inherit;font-size:14px;letter-spacing:.1em;
    outline:none;text-align:center;
  }
  input[type=password]:focus{border-color:#ef7d1c;}
  button{
    margin-top:14px;width:100%;padding:11px;border-radius:8px;cursor:pointer;
    background:linear-gradient(180deg,#f38c30,#e06f10);border:1px solid #f7a04d;
    color:#160d02;font-family:inherit;font-weight:700;font-size:12px;letter-spacing:.18em;text-transform:uppercase;
  }
  .err{color:#e6402a;font-size:11px;letter-spacing:.1em;margin-top:14px;<?php echo $smx_failed ? '' : 'display:none;'; ?>}
</style>
</head>
<body>
  <form class="gate" method="post" action="">
    <div class="wm">STEMMA<span class="xx">XX</span>ER</div>
    <div class="sub">Band Access Only</div>
    <input type="password" name="smx_pass" placeholder="password" autofocus autocomplete="current-password">
    <button type="submit">Enter</button>
    <div class="err">WRONG PASSWORD — TRY AGAIN</div>
  </form>
</body>
</html>
