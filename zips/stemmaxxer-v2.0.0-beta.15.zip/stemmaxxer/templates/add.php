<?php
if (!defined('ABSPATH')) exit;
/* Vars from smx_render_add_page():
 * @var string $smx_assets   plugin assets URL (trailing slash)
 * @var string $smx_ajax_url admin-ajax.php URL
 * @var string $smx_nonce    smx_ingest nonce
 * @var bool   $smx_key_set  true if the passkey has been configured (not CHANGE-ME)
 * @var string $smx_version
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>STEMMAXXER — Add a Song</title>
<style>
  /* Self-hosted fonts (assets/fonts/) — same-origin so privacy browsers that
     block third-party requests (Firefox Focus) keep them. Variable → one woff2. */
  @font-face{font-family:'JetBrains Mono';font-style:normal;font-weight:400 700;font-display:swap;
    src:url('<?php echo esc_url($smx_assets); ?>fonts/jetbrains-mono-latin.woff2') format('woff2');}
  @font-face{font-family:'Big Shoulders Display';font-style:normal;font-weight:600 800;font-display:swap;
    src:url('<?php echo esc_url($smx_assets); ?>fonts/big-shoulders-display-latin.woff2') format('woff2');}
  :root{
    --bg:#141416; --panel:#1e1e24; --panel2:#25252b; --line:#3a3a44; --line2:#50505c;
    --text:#e9e9ec; --dim:#9a9aa4; --dimmer:#63636d; --orange:#ef7d1c; --orange2:#f7a04d;
    --green:#39d353; --red:#e6402a;
  }
  *{box-sizing:border-box;}
  body{margin:0;min-height:100vh;background:radial-gradient(1100px 600px at 50% -10%, #1c1c20 0%, #141416 60%);
    font-family:'JetBrains Mono',ui-monospace,'SF Mono',SFMono-Regular,Menlo,Consolas,monospace;color:var(--text);padding:28px 20px 60px;}
  .wrap{max-width:940px;margin:0 auto;}
  header{display:flex;align-items:baseline;gap:14px;flex-wrap:wrap;margin-bottom:2px;}
  .logo{font-family:'Big Shoulders Display','Arial Narrow','Roboto Condensed',system-ui,sans-serif;font-weight:800;font-size:40px;letter-spacing:.04em;line-height:1;}
  .logo .xx{color:var(--orange);}
  .logo .sub{font-family:'Big Shoulders Display','Arial Narrow','Roboto Condensed',system-ui,sans-serif;font-weight:700;font-size:22px;color:var(--dim);letter-spacing:.03em;}
  .tag{font-size:11px;letter-spacing:.2em;color:var(--dimmer);text-transform:uppercase;margin:4px 0 22px;}
  .tag a{color:var(--orange2);text-decoration:none;}

  .card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:20px 22px;margin-bottom:18px;}
  .card h2{font-family:'Big Shoulders Display','Arial Narrow','Roboto Condensed',system-ui,sans-serif;font-weight:700;font-size:19px;letter-spacing:.04em;margin:0 0 14px;color:#cfcfd6;text-transform:uppercase;}
  .card h2 .n{color:var(--orange);}

  label.fld{display:block;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin-bottom:6px;}
  .row2{display:flex;gap:16px;flex-wrap:wrap;}
  .row2 > div{flex:1 1 260px;}
  input[type=text],input[type=password]{width:100%;padding:11px 13px;border-radius:8px;border:1px solid var(--line2);
    background:#141418;color:var(--text);font-family:inherit;font-size:14px;outline:none;}
  input:focus{border-color:var(--orange);}

  #drop{border:2px dashed var(--line2);border-radius:12px;padding:34px 20px;text-align:center;color:var(--dim);cursor:pointer;transition:all .15s ease;background:#17171c;}
  #drop.hover{border-color:var(--orange);background:#1d1a15;color:var(--text);}
  #drop strong{color:var(--text);} #drop .big{font-size:15px;margin-bottom:6px;} #drop .small{font-size:12px;color:var(--dimmer);}

  table{width:100%;border-collapse:collapse;margin-top:6px;}
  th,td{text-align:left;padding:9px 10px;font-size:13px;border-bottom:1px solid var(--line);vertical-align:middle;}
  th{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);}
  td.fname{font-size:12px;color:var(--dim);word-break:break-all;max-width:300px;}
  td.out{font-size:12px;color:var(--orange2);word-break:break-all;}
  select{padding:8px 10px;border-radius:7px;border:1px solid var(--line2);background:#141418;color:var(--text);font-family:inherit;font-size:13px;outline:none;cursor:pointer;}
  select:focus{border-color:var(--orange);}
  .st{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--dimmer);white-space:nowrap;}
  .st.done{color:var(--green);} .st.work{color:var(--orange2);} .st.err{color:var(--red);}
  .xnote{display:block;color:var(--dimmer);font-size:10px;letter-spacing:.04em;text-transform:uppercase;white-space:nowrap;margin-top:2px;}
  .rm{background:none;border:1px solid var(--line2);color:var(--dim);border-radius:6px;padding:4px 9px;cursor:pointer;font-family:inherit;font-size:12px;}
  .rm:hover{border-color:var(--red);color:var(--red);}

  .btn{display:inline-flex;align-items:center;gap:9px;padding:12px 22px;border-radius:9px;cursor:pointer;border:1px solid var(--orange2);
    background:linear-gradient(180deg,#f38c30,#e06f10);color:#160d02;font-family:inherit;font-weight:700;font-size:13px;letter-spacing:.12em;text-transform:uppercase;transition:filter .15s ease;}
  .btn:hover{filter:brightness(1.08);} .btn:disabled{opacity:.4;cursor:not-allowed;filter:none;}
  .btn.ghost{background:none;color:var(--text);border-color:var(--line2);} .btn.ghost:hover:not(:disabled){border-color:var(--text);}
  .actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:16px;}
  #status{font-size:12px;color:var(--dim);margin-top:12px;min-height:16px;}
  #status.ok{color:var(--green);} #status.bad{color:var(--red);}

  .hint{font-size:12px;color:var(--dim);line-height:1.75;}
  .hint code{background:var(--panel2);border:1px solid var(--line);border-radius:4px;padding:1px 6px;color:#c9c9cf;font-size:12px;}
  .hint b{color:var(--text);}
  .modetabs{display:flex;gap:8px;margin-bottom:16px;}
  .modetab{flex:1 1 0;padding:10px;border-radius:8px;cursor:pointer;text-align:center;
    font-family:inherit;font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;
    background:#141418;border:1px solid var(--line2);color:var(--dim);transition:all .12s;}
  .modetab.on{background:linear-gradient(180deg, color-mix(in srgb,var(--orange),white 12%), color-mix(in srgb,var(--orange),black 8%));border-color:var(--orange2);color:#160d02;}
  .modetab:disabled{opacity:.4;cursor:not-allowed;}
  .modepane{display:none;} .modepane.on{display:block;}
  #existSel{width:100%;padding:11px 13px;}
  #existInfo b{color:var(--orange2);}
  .empty{color:var(--dimmer);font-size:13px;padding:14px 4px;}
  .warn{background:#2a2417;border:1px solid #6b5a1e;border-radius:10px;padding:14px 16px;color:#e9d9a6;font-size:13px;line-height:1.6;margin-bottom:18px;}
  .gate{max-width:420px;}
  #app{display:none;}
</style>
</head>
<body>
<div class="wrap">

  <header>
    <div class="logo">STEMMA<span class="xx">XX</span>ER <span class="sub">ADD A SONG</span></div>
  </header>
  <div class="tag">Convert &amp; upload stems in one step &nbsp;·&nbsp; <a href="<?php echo esc_url(home_url('/stemmaxxer.html')); ?>">← back to the mixer</a></div>

  <?php if (!$smx_key_set): ?>
    <div class="warn"><b>Passkey not set yet.</b> This page is disabled until you set your secret.
    Edit <code>wp-content/stemmaxxer-key.php</code> on the server and change <code>CHANGE-ME</code> to your own passkey
    (this is the same passkey used by the Workbench Deploy button).</div>
  <?php endif; ?>

  <!-- Passkey gate -->
  <div class="card gate" id="gate">
    <h2>Passkey</h2>
    <p class="hint" style="margin-top:0;">Enter your STEMMAXXER passkey to unlock uploading. It's remembered for this browser session.</p>
    <input type="password" id="passkey" placeholder="passkey" autocomplete="current-password" <?php echo $smx_key_set ? '' : 'disabled'; ?>>
    <div class="actions"><button class="btn" id="unlock" <?php echo $smx_key_set ? '' : 'disabled'; ?>>Unlock</button></div>
    <div id="gateMsg" style="font-size:12px;color:var(--red);margin-top:10px;min-height:14px;"></div>
  </div>

  <!-- Converter + uploader (revealed after unlock) -->
  <div id="app">
    <div class="card">
      <h2><span class="n">1</span> · Song</h2>
      <div class="modetabs">
        <button type="button" class="modetab on" id="tabNew">New song</button>
        <button type="button" class="modetab" id="tabExist">Add stem to existing song</button>
        <button type="button" class="modetab" id="tabReplace">Replace existing song stems</button>
      </div>
      <div class="modepane on" id="paneNew">
        <div class="row2">
          <div><label class="fld" for="band">Band / Artist</label><input type="text" id="band" placeholder="e.g. Black Sabbath" autocomplete="off"></div>
          <div><label class="fld" for="song">Song title</label><input type="text" id="song" placeholder="e.g. Street Spirit (Fade Out)" autocomplete="off"></div>
        </div>
        <p class="hint" style="margin:12px 0 0;">Set the band &amp; song once — every file you drop below becomes a stem of this song. Type the title exactly how you want it shown; punctuation like <b>( )</b>, apostrophes, and <b>&amp;</b> are kept in the mixer even though the file name can&rsquo;t hold them.</p>
      </div>
      <div class="modepane" id="paneExist">
        <label class="fld" for="existSel">Song to add to</label>
        <select id="existSel"></select>
        <p class="hint" id="existInfo" style="margin:10px 0 0;">Pick a song, then drop in the stem(s) you want to add (e.g. a missing Click track). Only the new stems are filed — the song&rsquo;s existing stems stay exactly as they are.</p>
      </div>
      <div class="modepane" id="paneReplace">
        <label class="fld" for="replaceSel">Song to replace stems in</label>
        <select id="replaceSel"></select>
        <p class="hint" id="replaceInfo" style="margin:10px 0 0;">Pick a song, then drop your re-exported stems (e.g. a louder bounce of the whole song). Each dropped stem <b>replaces</b> that song&rsquo;s matching stem &mdash; at its exact existing file name, so nothing piles up. Stems you don&rsquo;t re-upload stay exactly as they are.</p>
      </div>
    </div>

    <div class="card">
      <h2><span class="n">2</span> · Stems</h2>
      <div id="drop">
        <div class="big">Drag your exported <strong>AIFF</strong> (or WAV) stems here</div>
        <div class="small">…or click to choose files. The instrument is read from Logic's track name automatically — fix any that are wrong.</div>
      </div>
      <input type="file" id="file" accept=".aif,.aiff,.wav,audio/aiff,audio/x-aiff,audio/wav" multiple hidden>
      <div id="listWrap" style="margin-top:16px;"></div>
      <div class="actions">
        <button class="btn" id="go" disabled>Convert &amp; add to STEMMAXXER</button>
        <button class="btn ghost" id="clear" disabled>Clear</button>
      </div>
      <div id="status"></div>
    </div>

    <div class="card">
      <h2>What happens</h2>
      <p class="hint">Each stem is converted to MP3 <b>right here in your browser</b> (the big AIFFs never get uploaded), then filed straight into
      WordPress. The song appears in the mixer immediately — no Media upload, no renaming.
      <br><br><b>New song</b> files each stem as <code>Band__Song__Instrument.mp3</code>; re-adding the same band+song replaces its old stems.
      <b>Add stem to existing song</b> lets you top up a song that&rsquo;s already in the library — pick it, drop in just the missing stem(s)
      (e.g. a Click), and only those are added; the song&rsquo;s other stems are untouched. Works for both older and newer songs.
      <b>Replace existing song stems</b> is for re-exports (e.g. a louder bounce) — pick the song, drop the re-exported stems, and each one
      overwrites that song&rsquo;s matching stem at its <b>exact existing file name</b> (older <code>.m4a</code> stems are superseded by the newer
      upload), so nothing piles up. Stems you don&rsquo;t re-upload stay put.
      Channel order is fixed: <b>Count In · Click · Drums · Guitar · Bass · Piano · Vocals · Other</b> (a stem named with &ldquo;click&rdquo; becomes the Click channel).</p>
    </div>
  </div>

</div>

<script src="<?php echo esc_url($smx_assets); ?>lame.min.js"></script>
<script>
(function(){
  "use strict";
  var SMX = {
    ajax: <?php echo json_encode($smx_ajax_url); ?>,
    nonce: <?php echo json_encode($smx_nonce); ?>,
    mixer: <?php echo json_encode(home_url('/stemmaxxer.html')); ?>
  };
  var EXISTING = <?php echo $smx_existing_json; ?> || [];
  var INSTRUMENTS = ['Count In','Click','Drums','Guitar','Bass','Piano','Vocals','Other'];
  var SYNONYMS = [
    ['count in','Count In'],['count','Count In'],
    ['click','Click'],['metronome','Click'],
    ['drum','Drums'],['kit','Drums'],['perc','Drums'],
    ['guitar','Guitar'],['gtr','Guitar'],['gita','Guitar'],
    ['bass','Bass'],
    ['piano','Piano'],['keys','Piano'],['key','Piano'],['synth','Piano'],['organ','Piano'],['rhodes','Piano'],
    ['vocal','Vocals'],['vox','Vocals'],['vocs','Vocals'],
    ['other','Other'],['fx','Other'],['misc','Other'],['aux','Other']
  ];
  var KBPS = 256, LAME_RATES = [8000,11025,12000,16000,22050,24000,32000,44100,48000];

  // ---- passkey gate ----
  var passkey = '';
  // Prefer a passkey handed over from the Workbench (localStorage, shared across tabs);
  // fall back to this tab's own sessionStorage. Either way, no re-entry needed.
  try { passkey = localStorage.getItem('smx-deploy-key') || sessionStorage.getItem('smx-deploy-key') || ''; } catch(e){}
  var gate = document.getElementById('gate'), app = document.getElementById('app');
  var passEl = document.getElementById('passkey'), gateMsg = document.getElementById('gateMsg');
  function unlock(){
    var v = passEl.value.trim(); if(!v){ return; }
    passkey = v; try{ sessionStorage.setItem('smx-deploy-key', v); localStorage.setItem('smx-deploy-key', v); }catch(e){}
    gate.style.display='none'; app.style.display='block';
  }
  document.getElementById('unlock').addEventListener('click', unlock);
  passEl.addEventListener('keydown', function(e){ if(e.key==='Enter') unlock(); });
  if (passkey){ gate.style.display='none'; app.style.display='block'; }

  // ---- element refs ----
  var bandEl=document.getElementById('band'), songEl=document.getElementById('song');
  var drop=document.getElementById('drop'), fileInput=document.getElementById('file');
  var listWrap=document.getElementById('listWrap'), statusEl=document.getElementById('status');
  var goBtn=document.getElementById('go'), clearBtn=document.getElementById('clear');
  var items=[];

  // ---- mode: new song · add stem to existing · replace existing song stems ----
  var mode='new';
  var tabNew=document.getElementById('tabNew'), tabExist=document.getElementById('tabExist'), tabReplace=document.getElementById('tabReplace');
  var paneNew=document.getElementById('paneNew'), paneExist=document.getElementById('paneExist'), paneReplace=document.getElementById('paneReplace');
  var existSel=document.getElementById('existSel'), existInfo=document.getElementById('existInfo');
  var replaceSel=document.getElementById('replaceSel'), replaceInfo=document.getElementById('replaceInfo');
  (function initExisting(){
    if(!EXISTING.length){
      tabExist.disabled=true; tabExist.title='No songs in the library yet';
      tabReplace.disabled=true; tabReplace.title='No songs in the library yet';
      return;
    }
    var opts=EXISTING.map(function(s,i){ return '<option value="'+i+'">'+escapeHtml(s.label)+'</option>'; }).join('');
    existSel.innerHTML=opts; replaceSel.innerHTML=opts;
  })();
  // The song currently selected in whichever "existing song" pane is active.
  function currentExisting(){
    if(!EXISTING.length) return null;
    if(mode==='exist')   return EXISTING[+existSel.value||0];
    if(mode==='replace') return EXISTING[+replaceSel.value||0];
    return null;
  }
  function updateExistInfo(){
    var s=currentExisting(); if(!s){ return; }
    var have=(s.have||[]).slice(); var haveLower=have.map(function(x){return x.toLowerCase();});
    var missing=INSTRUMENTS.filter(function(n){ return haveLower.indexOf(n.toLowerCase())<0; });
    existInfo.innerHTML = 'Currently has: <b>'+ (have.length?escapeHtml(have.join(' · ')):'—') +'</b>.'
      + (missing.length? ' You can add: '+escapeHtml(missing.join(' · '))+'.' : ' (Has every channel already.)')
      + '<br>Only the new stems you drop below are filed — existing stems stay put.';
  }
  function updateReplaceInfo(){
    var s=currentExisting(); if(!s){ return; }
    var have=(s.have||[]).slice();
    replaceInfo.innerHTML = 'This song has: <b>'+ (have.length?escapeHtml(have.join(' · ')):'—') +'</b>.'
      + ' Drop a re-exported stem for any of these and it <b>replaces</b> that stem at its exact existing file name'
      + (s.scheme==='legacy'?' (legacy naming &mdash; the real track number is kept)':'')
      + '.<br>Anything you don’t re-upload stays exactly as it is.';
  }
  function setMode(m){
    mode=m;
    tabNew.classList.toggle('on', m==='new'); tabExist.classList.toggle('on', m==='exist'); tabReplace.classList.toggle('on', m==='replace');
    paneNew.classList.toggle('on', m==='new'); paneExist.classList.toggle('on', m==='exist'); paneReplace.classList.toggle('on', m==='replace');
    if(m==='exist') updateExistInfo();
    if(m==='replace') updateReplaceInfo();
    render();
  }
  tabNew.addEventListener('click', function(){ setMode('new'); });
  tabExist.addEventListener('click', function(){ if(!tabExist.disabled) setMode('exist'); });
  tabReplace.addEventListener('click', function(){ if(!tabReplace.disabled) setMode('replace'); });
  existSel.addEventListener('change', function(){ updateExistInfo(); render(); });
  replaceSel.addEventListener('change', function(){ updateReplaceInfo(); render(); });

  function tokenizeField(s){ return (s||'').trim().replace(/&/g,' and ').replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,''); }
  function matchInstrument(str){ var n=(str||'').toLowerCase(); for(var i=0;i<SYNONYMS.length;i++){ if(n.indexOf(SYNONYMS[i][0])>=0) return SYNONYMS[i][1]; } return null; }
  function guessInstrument(name){
    var base=name.replace(/\.[^.]+$/,'');
    var groups=(base.match(/\(([^)]*)\)/g)||[]).map(function(g){return g.slice(1,-1);});
    for(var i=groups.length-1;i>=0;i--){ var hit=matchInstrument(groups[i]); if(hit) return hit; }
    return matchInstrument(base) || 'Other';
  }
  // Build the output filename so a stem joins the RIGHT song + scheme.
  function existingOutName(song, inst){
    var i=tokenizeField(inst)||'Other';
    if(song.scheme==='legacy'){
      var mm=(song.sample||'').match(/^(song\d+)-\d+-/i);
      var nn=mm?mm[1]:song.slug;
      return nn+'-90-'+i+'.mp3';                       // MM=90; channel comes from the StemName
    }
    var parts=(song.sample||'').split('__');           // [Band, Song, Inst.ext]
    if(parts.length>=3) return parts[0]+'__'+parts[1]+'__'+i+'.mp3';
    var sp=(song.slug||'').split('__');
    return (sp[0]||'Band')+'__'+(sp[1]||'Song')+'__'+i+'.mp3';
  }
  // Replace-mode target: overwrite the song's EXISTING same-instrument stem by reusing its
  // ACTUAL file name (from song.basenames — original casing, real legacy MM), with only the
  // extension forced to .mp3 (converter output is always mp3). If the existing stem is already
  // .mp3 the name matches exactly → clean server-side replace, no "-1" copies. If it's .m4a the
  // names differ (can't upload .m4a) so the newer mtime wins the scan dedup → exactly one stem
  // discovered, the stale .m4a left on disk (removing leftovers is out of scope). If the song
  // has no stem for this instrument, fall back to ADD semantics so the drop still lands.
  function replaceInfoFor(song, inst){
    var bn=(song.basenames||{})[String(inst||'').toLowerCase()];
    if(bn){
      var ext=((bn.match(/\.([^.]+)$/)||[])[1]||'').toLowerCase();
      return {name:bn.replace(/\.[^.]+$/, '.mp3'), replacing:true, exact:(ext==='mp3'), origExt:ext};
    }
    return {name:existingOutName(song, inst), replacing:false, exact:false, origExt:''};
  }
  function outNameFor(inst){
    if(mode==='exist'){ var s=currentExisting(); return s?existingOutName(s,inst):'—'; }
    if(mode==='replace'){ var r=currentExisting(); return r?replaceInfoFor(r,inst).name:'—'; }
    var b=tokenizeField(bandEl.value)||'Band', s2=tokenizeField(songEl.value)||'Song', i=tokenizeField(inst);
    return b+'__'+s2+'__'+i+'.mp3';
  }
  function escapeHtml(s){ return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }

  // ---- AIFF / WAV parsing ----
  function read80(dv,off){ var b0=dv.getUint8(off),b1=dv.getUint8(off+1),sign=(b0&0x80)?-1:1,expon=((b0&0x7f)<<8)|b1,hi=dv.getUint32(off+2),lo=dv.getUint32(off+6);
    if(expon===0&&hi===0&&lo===0)return 0; if(expon===0x7FFF)return sign*Infinity; var e=expon-16383; return sign*(hi*Math.pow(2,e-31)+lo*Math.pow(2,e-63)); }
  function fourcc(dv,o){ return String.fromCharCode(dv.getUint8(o),dv.getUint8(o+1),dv.getUint8(o+2),dv.getUint8(o+3)); }
  function parseAiff(buf){
    var dv=new DataView(buf); if(fourcc(dv,0)!=='FORM') throw new Error('not AIFF');
    var form=fourcc(dv,8); if(form!=='AIFF'&&form!=='AIFC') throw new Error('AIFF form '+form);
    var p=12,comm=null,ssndOff=-1;
    while(p+8<=dv.byteLength){ var id=fourcc(dv,p),size=dv.getUint32(p+4),body=p+8;
      if(id==='COMM'){ comm={numCh:dv.getInt16(body),numFrames:dv.getUint32(body+2),bits:dv.getInt16(body+6),sr:read80(dv,body+8)}; }
      else if(id==='SSND'){ var d=dv.getUint32(body); ssndOff=body+8+d; }
      p=body+size+(size&1); }
    if(!comm||ssndOff<0) throw new Error('AIFF missing COMM/SSND');
    var numCh=comm.numCh,numFrames=comm.numFrames,bits=comm.bits,bytes=bits/8,o=ssndOff,ch=[],c;
    for(c=0;c<numCh;c++) ch.push(new Float32Array(numFrames));
    for(var f=0;f<numFrames;f++){ for(c=0;c<numCh;c++){ var v;
      if(bits===16) v=dv.getInt16(o)/32768;
      else if(bits===24){ var x=(dv.getUint8(o)<<16)|(dv.getUint8(o+1)<<8)|dv.getUint8(o+2); if(x&0x800000)x-=0x1000000; v=x/8388608; }
      else if(bits===32) v=dv.getInt32(o)/2147483648;
      else if(bits===8) v=dv.getInt8(o)/128;
      else throw new Error('AIFF '+bits+'-bit'); ch[c][f]=v; o+=bytes; } }
    return {channels:ch,sampleRate:Math.round(comm.sr)};
  }
  function parseWav(buf){
    var dv=new DataView(buf); if(fourcc(dv,0)!=='RIFF'||fourcc(dv,8)!=='WAVE') throw new Error('not WAV');
    var p=12,fmt=null,dataOff=-1,dataLen=0;
    while(p+8<=dv.byteLength){ var id=fourcc(dv,p),size=dv.getUint32(p+4,true),body=p+8;
      if(id==='fmt ') fmt={format:dv.getUint16(body,true),numCh:dv.getUint16(body+2,true),sr:dv.getUint32(body+4,true),bits:dv.getUint16(body+14,true)};
      else if(id==='data'){ dataOff=body; dataLen=size; }
      p=body+size+(size&1); }
    if(!fmt||dataOff<0) throw new Error('WAV missing fmt/data');
    var numCh=fmt.numCh,bits=fmt.bits,bytes=bits/8,numFrames=Math.floor(dataLen/(bytes*numCh)),o=dataOff,ch=[],c;
    for(c=0;c<numCh;c++) ch.push(new Float32Array(numFrames));
    for(var f=0;f<numFrames;f++){ for(c=0;c<numCh;c++){ var v;
      if(fmt.format===3&&bits===32) v=dv.getFloat32(o,true);
      else if(bits===16) v=dv.getInt16(o,true)/32768;
      else if(bits===24){ var x=dv.getUint8(o)|(dv.getUint8(o+1)<<8)|(dv.getUint8(o+2)<<16); if(x&0x800000)x-=0x1000000; v=x/8388608; }
      else if(bits===32) v=dv.getInt32(o,true)/2147483648;
      else if(bits===8) v=(dv.getUint8(o)-128)/128;
      else throw new Error('WAV '+bits+'-bit'); ch[c][f]=v; o+=bytes; } }
    return {channels:ch,sampleRate:fmt.sr};
  }
  function resample(c,srIn,srOut){ if(srIn===srOut) return c; var r=srOut/srIn,n=Math.round(c.length*r),out=new Float32Array(n);
    for(var i=0;i<n;i++){ var t=i/r,i0=Math.floor(t),fr=t-i0,a=c[i0]||0,b=c[i0+1]||a; out[i]=a+(b-a)*fr; } return out; }
  function toI16(f){ var o=new Int16Array(f.length); for(var i=0;i<f.length;i++){ var s=f[i]; s=s<-1?-1:s>1?1:s; o[i]=s<0?s*32768:s*32767; } return o; }
  function encodeMp3(pr){
    var channels=pr.channels,sr=pr.sampleRate;
    if(LAME_RATES.indexOf(sr)===-1){ var t=sr>48000?48000:44100; channels=channels.map(function(c){return resample(c,sr,t);}); sr=t; }
    var nCh=Math.min(channels.length,2)||1, enc=new lamejs.Mp3Encoder(nCh,sr,KBPS), block=1152, data=[];
    if(nCh===2){ var L=toI16(channels[0]),R=toI16(channels[1]||channels[0]);
      for(var i=0;i<L.length;i+=block){ var b=enc.encodeBuffer(L.subarray(i,i+block),R.subarray(i,i+block)); if(b.length) data.push(new Uint8Array(b)); } }
    else { var M=toI16(channels[0]); for(var j=0;j<M.length;j+=block){ var b2=enc.encodeBuffer(M.subarray(j,j+block)); if(b2.length) data.push(new Uint8Array(b2)); } }
    var end=enc.flush(); if(end.length) data.push(new Uint8Array(end));
    return new Blob(data,{type:'audio/mpeg'});
  }

  // ---- list UI ----
  function render(){
    if(!items.length){ listWrap.innerHTML='<div class="empty">No stems yet.</div>'; sync(); return; }
    var h='<table><thead><tr><th>Source file</th><th>Instrument</th><th>Uploads as</th><th>Status</th><th></th></tr></thead><tbody>';
    items.forEach(function(it,idx){
      var opts=INSTRUMENTS.map(function(n){return '<option'+(n===it.instrument?' selected':'')+'>'+n+'</option>';}).join('');
      var cls=it.status==='done'?'done':(it.status==='converting'||it.status==='uploading')?'work':it.status==='error'?'err':'';
      var label=it.status==='done'?((it.replaced||it.replacing)?'Replaced':'Added'):it.status==='converting'?'Converting…':it.status==='uploading'?'Uploading…':it.status==='error'?(it.err||'Error'):'Ready';
      // In replace mode, show a per-row hint: which existing stem it overwrites (and, if the
      // existing file is a different extension, that we lean on the newest-mtime dedup instead).
      var outName=outNameFor(it.instrument), outNote='';
      if(mode==='replace'){ var rs=currentExisting(); if(rs){ var ri=replaceInfoFor(rs,it.instrument);
        outNote = ri.replacing ? (ri.exact?'' : '<span class="xnote">replaces .'+escapeHtml(ri.origExt)+' &middot; newest-mtime wins</span>')
                               : '<span class="xnote">no existing '+escapeHtml(it.instrument)+' &mdash; will be added</span>'; } }
      h+='<tr><td class="fname">'+escapeHtml(it.file.name)+'</td>'
        +'<td><select data-i="'+idx+'">'+opts+'</select></td>'
        +'<td class="out">'+escapeHtml(outName)+outNote+'</td>'
        +'<td><span class="st '+cls+'">'+escapeHtml(label)+'</span></td>'
        +'<td><button class="rm" data-rm="'+idx+'">✕</button></td></tr>';
    });
    h+='</tbody></table>'; listWrap.innerHTML=h;
    listWrap.querySelectorAll('select[data-i]').forEach(function(sel){ sel.addEventListener('change',function(e){ var it=items[+e.target.dataset.i]; it.instrument=e.target.value; it.status='ready'; render(); }); });
    listWrap.querySelectorAll('button[data-rm]').forEach(function(btn){ btn.addEventListener('click',function(e){ items.splice(+e.currentTarget.dataset.rm,1); render(); }); });
    sync();
  }
  function sync(){ goBtn.disabled=!items.length; clearBtn.disabled=!items.length; }
  bandEl.addEventListener('input',render); songEl.addEventListener('input',render);

  function addFiles(list){ for(var i=0;i<list.length;i++){ var f=list[i]; if(!/\.(aif|aiff|wav)$/i.test(f.name)) continue; items.push({file:f,instrument:guessInstrument(f.name),status:'ready',outName:null,blob:null,replaced:false,replacing:false}); } render(); }
  drop.addEventListener('click',function(){ fileInput.click(); });
  fileInput.addEventListener('change',function(e){ addFiles(e.target.files); fileInput.value=''; });
  ['dragenter','dragover'].forEach(function(ev){ drop.addEventListener(ev,function(e){ e.preventDefault(); drop.classList.add('hover'); }); });
  ['dragleave','drop'].forEach(function(ev){ drop.addEventListener(ev,function(e){ e.preventDefault(); drop.classList.remove('hover'); }); });
  drop.addEventListener('drop',function(e){ if(e.dataTransfer&&e.dataTransfer.files) addFiles(e.dataTransfer.files); });
  clearBtn.addEventListener('click',function(){ items=[]; statusEl.textContent=''; statusEl.className=''; render(); });

  function readBuf(file){ return new Promise(function(res,rej){ var r=new FileReader(); r.onload=function(){res(r.result);}; r.onerror=function(){rej(r.error);}; r.readAsArrayBuffer(file); }); }

  function uploadStem(it){
    var fd=new FormData();
    fd.append('action','smx_ingest'); fd.append('nonce',SMX.nonce); fd.append('passkey',passkey);
    fd.append('filename',it.outName); fd.append('file',it.blob,it.outName);
    // In "new song" mode, send the EXACT typed band/title so punctuation the
    // filename can't hold (parentheses, apostrophes, &) shows in the mixer.
    if(mode==='new'){ fd.append('song_artist', bandEl.value.trim()); fd.append('song_title', songEl.value.trim()); }
    return fetch(SMX.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(function(res){
      return res.json().catch(function(){ throw new Error('server returned non-JSON (HTTP '+res.status+')'); }).then(function(j){
        if(!j||!j.success){ var d=(j&&j.data)?j.data:('HTTP '+res.status); throw new Error(d); }
        return j.data;
      });
    });
  }

  goBtn.addEventListener('click',function(){
    if(!passkey){ return; }
    if(mode==='exist'||mode==='replace'){ if(!currentExisting()){ statusEl.className='bad'; statusEl.textContent='Pick a song first.'; return; } }
    else if(!bandEl.value.trim()||!songEl.value.trim()){ statusEl.className='bad'; statusEl.textContent='Enter the band and song first.'; return; }
    goBtn.disabled=true; statusEl.className=''; statusEl.textContent='';
    var idx=0, added=0, failed=false;
    function next(){
      if(idx>=items.length){
        statusEl.className=failed?'bad':'ok';
        statusEl.innerHTML = added+' of '+items.length+' stem(s) added.'+(added?' <a href="'+SMX.mixer+'" style="color:var(--orange2)">Open the mixer →</a>':'');
        sync(); return;
      }
      var it=items[idx];
      if(it.status==='done'){ idx++; return next(); }
      it.status='converting'; render();
      readBuf(it.file).then(function(buf){
        it.blob=encodeMp3(/\.wav$/i.test(it.file.name)?parseWav(buf):parseAiff(buf));
        it.outName=outNameFor(it.instrument);
        if(mode==='replace'){ var rs=currentExisting(); it.replacing=!!(rs&&replaceInfoFor(rs,it.instrument).replacing); }
        it.status='uploading'; render();
        return uploadStem(it);
      }).then(function(data){
        it.status='done'; it.replaced=!!(data&&data.replaced); added++; render();
        idx++; next();
      }).catch(function(err){
        var msg=String(err&&err.message||err);
        if(msg.indexOf('bad-key')>=0||msg==='locked'){ // passkey wrong → back to gate
          statusEl.className='bad'; statusEl.textContent = msg==='locked' ? 'Too many wrong passkey attempts — wait 10 minutes.' : 'Passkey rejected.';
          try{ sessionStorage.removeItem('smx-deploy-key'); localStorage.removeItem('smx-deploy-key'); }catch(e){}
          passkey=''; it.status='ready'; render(); app.style.display='none'; gate.style.display='block'; gateMsg.textContent='Passkey rejected — try again.'; passEl.value=''; passEl.focus();
          goBtn.disabled=false; return;
        }
        it.status='error'; it.err=friendly(msg); failed=true; render(); idx++; next();
      });
    }
    next();
  });

  function friendly(m){
    if(m.indexOf('bad-filename')>=0) return 'bad name';
    if(m.indexOf('not-mp3')>=0) return 'encode failed';
    if(m.indexOf('bad-size')>=0) return 'too big';
    if(m.indexOf('key-not-set')>=0) return 'passkey not set';
    if(m.indexOf('write-failed')>=0) return 'server write failed';
    if(m.indexOf('non-JSON')>=0) return 'host upload limit?';
    return m.slice(0,40);
  }

  render();
})();
</script>
</body>
</html>
