<?php
/**
 * Plugin Name:       STEMMAXXER
 * Description:       Multi-stem practice mixer. Serves the player at /stemmaxxer.html, auto-discovers songs from the media uploads folder (SongNN-MM-StemName.m4a), and provides an admin page for naming songs and setting an access password.
 * Version:           2.0.0-beta.11
 * Author:            Chris Jennings
 * Requires at least: 5.5
 * Requires PHP:      7.2
 */

if (!defined('ABSPATH')) exit;

define('SMX_VERSION', '2.0.0-beta.11');
define('SMX_QUERY_VAR', 'stemmaxxer_page');
define('SMX_OPTION_SONGS', 'stemmaxxer_songs');      // slug => ['artist'=>..., 'title'=>..., 'hidden'=>bool]
define('SMX_OPTION_SETTINGS', 'stemmaxxer_settings'); // ['password'=>..., 'logo_url'=>...]
define('SMX_TRANSIENT_SCAN', 'smx_songs_scan');
define('SMX_COOKIE', 'smx_auth');
define('SMX_OPTION_WORKBENCH', 'stemmaxxer_workbench'); // deployed (site-wide default) workbench settings
define('SMX_KEY_FILE', WP_CONTENT_DIR . '/stemmaxxer-key.php'); // deploy passkey — outside the plugin so updates never overwrite it

/* ============================================================
 * DEPLOY — publish workbench settings as the site-wide defaults.
 * Novascope-style: always available from the Workbench, gated by a
 * passkey stored in a server-side PHP file (no WordPress login).
 * ============================================================ */

function smx_ensure_key_file() {
    if (file_exists(SMX_KEY_FILE)) return;
    $tpl = "<?php\n"
         . "// STEMMAXXER Workbench deploy passkey.\n"
         . "// Change the value below to your own secret, then save.\n"
         . "// Anyone with this key can press DEPLOY in the player's Workbench\n"
         . "// (no WordPress login needed). Plugin updates never touch this file.\n"
         . "return 'CHANGE-ME';\n";
    @file_put_contents(SMX_KEY_FILE, $tpl);
}

function smx_get_deploy_key() {
    if (!file_exists(SMX_KEY_FILE)) smx_ensure_key_file();
    $k = @include SMX_KEY_FILE;
    return is_string($k) ? trim($k) : '';
}

function smx_sanitize_wb($raw) {
    $out = array();
    $num = function ($k, $min, $max) use ($raw, &$out) {
        if (isset($raw[$k]) && is_numeric($raw[$k])) $out[$k] = max($min, min($max, floatval($raw[$k])));
    };
    $num('defLevel', 50, 100);
    $num('featLevel', 50, 100);
    $num('duckLevel', 10, 90);
    $num('seg', 5, 16);
    $num('faderW', 24, 64);
    $num('z1', 5, 90);
    $num('z2', 10, 95);
    $num('z3', 15, 100);
    $num('logoW', 40, 100);
    $num('meterDb', 24, 72);
    $num('scrubH', 6, 40);
    $num('gripW', 8, 48);
    $num('nsL', 0, 80);
    $num('nsR', 0, 80);
    $num('nsGap', 10, 150);
    $num('nsH', 4, 60);
    $num('resW', 300, 560);
    $num('resGlow', 0, 100);
    $num('resScrim', 0, 85);
    if (isset($raw['faderStyle'])) $out['faderStyle'] = ($raw['faderStyle'] === 'solid') ? 'solid' : 'led';
    foreach (array('accent', 'scrubC', 'gripBg', 'gripLines', 'loopC', 'resBg', 'resBd') as $ck) {
        if (isset($raw[$ck]) && preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) $raw[$ck])) $out[$ck] = (string) $raw[$ck];
    }
    foreach (array('meters', 'peakHold') as $bk) {
        if (isset($raw[$bk])) $out[$bk] = (bool) $raw[$bk];
    }
    return $out;
}

function smx_handle_deploy() {
    check_ajax_referer('smx_deploy', 'nonce');

    // Brute-force lockout: 5 wrong keys per IP → 10-minute cooldown
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_deploy_fail_' . md5($ip);
    $fails = (int) get_transient($lock);
    if ($fails >= 5) wp_send_json_error('locked', 429);

    $key = smx_get_deploy_key();
    if ($key === '' || $key === 'CHANGE-ME') wp_send_json_error('key-not-set', 400);

    $pass = isset($_POST['passkey']) ? (string) wp_unslash($_POST['passkey']) : '';
    if (!hash_equals($key, $pass)) {
        set_transient($lock, $fails + 1, 10 * MINUTE_IN_SECONDS);
        wp_send_json_error('bad-key', 403);
    }
    delete_transient($lock);

    $raw = isset($_POST['settings']) ? json_decode(wp_unslash($_POST['settings']), true) : null;
    if (!is_array($raw)) wp_send_json_error('bad payload', 400);
    $clean = smx_sanitize_wb($raw);
    update_option(SMX_OPTION_WORKBENCH, $clean);
    wp_send_json_success($clean);
}
add_action('wp_ajax_smx_deploy_wb', 'smx_handle_deploy');
add_action('wp_ajax_nopriv_smx_deploy_wb', 'smx_handle_deploy'); // no WordPress login required

/* ============================================================
 * INGEST — receive one converted MP3 stem from the on-site "Add a song"
 * page and file it into the Media library, so the song appears in the
 * mixer instantly. Same passkey + per-IP lockout as Deploy. The heavy
 * AIFF→MP3 conversion happens in the browser; the server only receives
 * finished, validated MP3s (no ffmpeg required on the host).
 * ============================================================ */

// A valid stem file name — accepts BOTH schemes so a single stem can be added to
// an existing song of either kind:
//   NEW:    Band__Song__Instrument.mp3   (tokens are [A-Za-z0-9_])
//   LEGACY: SongNN-MM-StemName.mp3
function smx_valid_stem_name($name) {
    return (bool) preg_match('/^[A-Za-z0-9_]+__[A-Za-z0-9_]+__[A-Za-z0-9_]+\.mp3$/', $name)
        || (bool) preg_match('/^song\d+-\d+-[A-Za-z0-9_]+\.mp3$/i', $name);
}

// Looks like a real MP3? Accept an ID3 header or an MPEG audio frame sync.
function smx_looks_like_mp3($path) {
    $fh = @fopen($path, 'rb');
    if (!$fh) return false;
    $head = fread($fh, 3);
    fclose($fh);
    if (strlen($head) < 3) return false;
    if (substr($head, 0, 3) === 'ID3') return true;                 // ID3v2 tag
    $b0 = ord($head[0]); $b1 = ord($head[1]);
    return ($b0 === 0xFF && ($b1 & 0xE0) === 0xE0);                  // MPEG frame sync
}

// Delete any existing media attachment whose file is exactly this basename,
// so re-adding a song cleanly replaces its stems instead of piling up "-1" copies.
function smx_replace_existing_stem($filename) {
    global $wpdb;
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s",
            '%' . $wpdb->esc_like($filename)
        )
    );
    $removed = 0;
    foreach ($rows as $r) {
        if (basename($r->meta_value) === $filename) {
            wp_delete_attachment((int) $r->post_id, true);
            $removed++;
        }
    }
    return $removed;
}

// Save the human-typed band/title for a NEW-scheme stem's song, keyed by the
// same slug the scanner computes, so display names keep punctuation the file
// name strips. Preserves any other per-song admin fields (bpm/hidden/urls).
function smx_store_song_names($filename, $artist, $title) {
    if (!preg_match('/^([A-Za-z0-9_]+)__([A-Za-z0-9_]+)__[A-Za-z0-9_]+\.mp3$/', $filename, $mm)) return false;
    $slug   = sanitize_key(strtolower($mm[1]) . '__' . strtolower($mm[2]));
    $artist = sanitize_text_field($artist);
    $title  = sanitize_text_field($title);
    if ($slug === '' || ($artist === '' && $title === '')) return false;
    $songs = get_option(SMX_OPTION_SONGS, array());
    if (!is_array($songs)) $songs = array();
    $row = (isset($songs[$slug]) && is_array($songs[$slug])) ? $songs[$slug] : array();
    if ($artist !== '') $row['artist'] = $artist;
    if ($title  !== '') $row['title']  = $title;
    $songs[$slug] = $row;
    update_option(SMX_OPTION_SONGS, $songs);
    return $slug;
}

function smx_handle_ingest() {
    check_ajax_referer('smx_ingest', 'nonce');

    // Brute-force lockout shares the deploy counter (same passkey)
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_deploy_fail_' . md5($ip);
    $fails = (int) get_transient($lock);
    if ($fails >= 5) wp_send_json_error('locked', 429);

    $key = smx_get_deploy_key();
    if ($key === '' || $key === 'CHANGE-ME') wp_send_json_error('key-not-set', 400);

    $pass = isset($_POST['passkey']) ? (string) wp_unslash($_POST['passkey']) : '';
    if (!hash_equals($key, $pass)) {
        set_transient($lock, $fails + 1, 10 * MINUTE_IN_SECONDS);
        wp_send_json_error('bad-key', 403);
    }
    delete_transient($lock);

    if (!current_user_can('upload_files')) {
        // Passkey holders act as an uploader even without WP login; the checks
        // below (name pattern + MP3 sniff + size) constrain what can be written.
    }

    // Validate the target file name
    $filename = isset($_POST['filename']) ? sanitize_file_name(wp_unslash($_POST['filename'])) : '';
    if (!smx_valid_stem_name($filename)) wp_send_json_error('bad-filename', 400);

    // Validate the uploaded file
    if (empty($_FILES['file']) || !isset($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        wp_send_json_error('no-file', 400);
    }
    $tmp  = $_FILES['file']['tmp_name'];
    $size = (int) $_FILES['file']['size'];
    if ($size <= 0 || $size > 30 * 1024 * 1024) wp_send_json_error('bad-size', 400); // 30 MB cap per stem
    if (!smx_looks_like_mp3($tmp)) wp_send_json_error('not-mp3', 400);

    // Replace any existing stem of the same name, then write the new one
    $replaced = smx_replace_existing_stem($filename);

    $bits = file_get_contents($tmp);
    if ($bits === false) wp_send_json_error('read-failed', 500);
    $up = wp_upload_bits($filename, null, $bits);
    if (!empty($up['error'])) wp_send_json_error('write-failed: ' . $up['error'], 500);

    // Register as a Media attachment so it shows in the Library, deletes normally,
    // and fires add_attachment (which busts the song-scan cache).
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    $attach = array(
        'post_mime_type' => 'audio/mpeg',
        'post_title'     => preg_replace('/\.mp3$/', '', $filename),
        'post_content'   => '',
        'post_status'    => 'inherit',
    );
    $aid = wp_insert_attachment($attach, $up['file']);
    if (!is_wp_error($aid) && $aid) {
        $meta = wp_generate_attachment_metadata($aid, $up['file']);
        if ($meta) wp_update_attachment_metadata($aid, $meta);
    }
    // If the on-site "new song" form supplied the exact typed band/title, save
    // them as this song's display name — so punctuation a file name can't hold
    // (parentheses, apostrophes, &, …) still shows in the mixer + song dropdown.
    $p_artist = isset($_POST['song_artist']) ? (string) wp_unslash($_POST['song_artist']) : '';
    $p_title  = isset($_POST['song_title'])  ? (string) wp_unslash($_POST['song_title'])  : '';
    if ($p_artist !== '' || $p_title !== '') smx_store_song_names($filename, $p_artist, $p_title);

    delete_transient(SMX_TRANSIENT_SCAN);

    wp_send_json_success(array('url' => $up['url'], 'file' => $filename, 'replaced' => $replaced));
}
add_action('wp_ajax_smx_ingest', 'smx_handle_ingest');
add_action('wp_ajax_nopriv_smx_ingest', 'smx_handle_ingest'); // no WordPress login required (passkey-gated)

/* Lightweight passkey check — lets the Workbench validate the passkey the
 * moment you open the uploader, so a wrong key is caught immediately (not at
 * upload time). Same key + lockout as Deploy; no side effects. */
function smx_handle_check_key() {
    check_ajax_referer('smx_deploy', 'nonce');
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_deploy_fail_' . md5($ip);
    $fails = (int) get_transient($lock);
    if ($fails >= 5) wp_send_json_error('locked', 429);
    $key = smx_get_deploy_key();
    if ($key === '' || $key === 'CHANGE-ME') wp_send_json_error('key-not-set', 400);
    $pass = isset($_POST['passkey']) ? (string) wp_unslash($_POST['passkey']) : '';
    if (!hash_equals($key, $pass)) {
        set_transient($lock, $fails + 1, 10 * MINUTE_IN_SECONDS);
        wp_send_json_error('bad-key', 403);
    }
    delete_transient($lock);
    wp_send_json_success(true);
}
add_action('wp_ajax_smx_check_key', 'smx_handle_check_key');
add_action('wp_ajax_nopriv_smx_check_key', 'smx_handle_check_key');

/* ============================================================
 * SONG RESOURCES — an unlimited, labeled list of links per song (tabs, chords,
 * video lessons, etc.). Chris manages his own in Settings → STEMMAXXER; band
 * members can add their own from the mixer, authenticated by the band gate
 * cookie (no extra password). Band-added items carry a per-device delete token
 * so only the adding browser (or Chris, in admin) can remove them.
 * ============================================================ */

function smx_resource_types() { return array('tab', 'chords', 'video', 'audio', 'link'); }

function smx_new_res_id() { return 'r' . substr(md5(uniqid('', true)), 0, 12); }

function smx_guess_res_type($url) {
    $u = strtolower((string) $url);
    if (strpos($u, 'youtube.com') !== false || strpos($u, 'youtu.be') !== false || strpos($u, 'vimeo.com') !== false) return 'video';
    if (strpos($u, 'songsterr') !== false) return 'tab';
    if (strpos($u, 'ultimate-guitar') !== false || strpos($u, 'chordie') !== false || strpos($u, 'e-chords') !== false) return 'chords';
    return 'link';
}

// http/https only; returns '' if the URL is unusable.
function smx_clean_res_url($url) {
    $url = esc_url_raw(trim((string) $url), array('http', 'https'));
    return $url ? $url : '';
}

// Optional one-line description/note for a resource. Plain text, capped at 160.
function smx_clean_res_desc($desc) {
    $desc = sanitize_text_field((string) $desc);
    return function_exists('mb_substr') ? mb_substr($desc, 0, 160) : substr($desc, 0, 160);
}

// The song's resource list: persisted resources if present, else migrated from
// the legacy chart_url / lesson_url pair so nothing already set is lost.
function smx_song_resources($meta) {
    if (isset($meta['resources']) && is_array($meta['resources'])) return $meta['resources'];
    $res = array();
    if (!empty($meta['chart_url']))  $res[] = array('id' => 'legacy_chart',  'type' => 'tab',   'label' => 'Charts', 'url' => $meta['chart_url'],  'src' => 'admin');
    if (!empty($meta['lesson_url'])) $res[] = array('id' => 'legacy_lesson', 'type' => 'video', 'label' => 'Lesson', 'url' => $meta['lesson_url'], 'src' => 'admin');
    return $res;
}

// Public shape for the player payload — never expose the delete token `k`.
function smx_res_public($res) {
    $out = array();
    foreach ((array) $res as $r) {
        if (empty($r['url'])) continue;
        $out[] = array(
            'id'    => isset($r['id']) ? $r['id'] : smx_new_res_id(),
            'type'  => (isset($r['type']) && in_array($r['type'], smx_resource_types(), true)) ? $r['type'] : 'link',
            'label' => isset($r['label']) ? $r['label'] : '',
            'desc'  => isset($r['desc']) ? (string) $r['desc'] : '',
            'url'   => $r['url'],
            'src'   => (isset($r['src']) && $r['src'] === 'band') ? 'band' : 'admin',
        );
    }
    return $out;
}

// Is this request a logged-in band member (or the WP admin)? Gate-cookie based —
// no extra password to type. Returns false when no band password is even set.
function smx_band_authed() {
    if (current_user_can('manage_options')) return true;
    $settings = get_option(SMX_OPTION_SETTINGS, array());
    $pw = isset($settings['password']) ? (string) $settings['password'] : '';
    if ($pw === '') return false;
    $expected = hash_hmac('sha256', $pw, wp_salt('auth'));
    $cookie   = isset($_COOKIE[SMX_COOKIE]) ? (string) $_COOKIE[SMX_COOKIE] : '';
    return hash_equals($expected, $cookie);
}

// <option> list for the admin resource-type picker.
// Canonical value => label map for the resource-type picker (admin + JS share this).
function smx_res_type_labels() {
    return array('tab' => 'Tab / Chart', 'chords' => 'Chords', 'video' => 'Video lesson', 'audio' => 'Audio ref', 'link' => 'Other link');
}

function smx_admin_res_type_options($sel) {
    $o = '';
    foreach (smx_res_type_labels() as $v => $lbl) { $o .= '<option value="' . esc_attr($v) . '"' . selected($sel, $v, false) . '>' . esc_html($lbl) . '</option>'; }
    return $o;
}

// One editor row (Settings → STEMMAXXER song table).
function smx_admin_res_row_html($slug, $idx, $res) {
    $type  = isset($res['type'])  ? $res['type']  : 'link';
    $label = isset($res['label']) ? $res['label'] : '';
    $desc  = isset($res['desc'])  ? $res['desc']  : '';
    $url   = isset($res['url'])   ? $res['url']   : '';
    $id    = isset($res['id'])    ? $res['id']    : '';
    $band  = (isset($res['src']) && $res['src'] === 'band');
    $base  = 'smx_song[' . esc_attr($slug) . '][resources][' . intval($idx) . ']';
    ob_start(); ?>
    <div class="smx-res-row">
      <input type="hidden" name="<?php echo $base; ?>[id]" value="<?php echo esc_attr($id); ?>">
      <select name="<?php echo $base; ?>[type]"><?php echo smx_admin_res_type_options($type); ?></select>
      <input type="text" class="smx-res-label" name="<?php echo $base; ?>[label]" value="<?php echo esc_attr($label); ?>" placeholder="Label (e.g. Guitar lesson)" maxlength="80">
      <input type="url" name="<?php echo $base; ?>[url]" value="<?php echo esc_attr($url); ?>" placeholder="https://…">
      <?php if ($band): ?><span class="smx-res-band" title="Added by a band member from the mixer">band</span><?php endif; ?>
      <button type="button" class="button-link smx-res-rm" title="Remove this resource" aria-label="Remove">&times;</button>
      <input type="text" class="smx-res-desc" name="<?php echo $base; ?>[desc]" value="<?php echo esc_attr($desc); ?>" placeholder="Description (optional) — e.g. note-for-note guitar, slow then full speed" maxlength="160">
    </div>
    <?php return ob_get_clean();
}

// The whole resources cell for one song: existing rows + an "+ Add" button.
function smx_admin_render_resources_cell($slug, $resources) {
    $resources = is_array($resources) ? $resources : array();
    echo '<div class="smx-res-cell" data-slug="' . esc_attr($slug) . '" data-n="' . count($resources) . '">';
    echo '<div class="smx-res-rows">';
    $i = 0;
    foreach ($resources as $res) { echo smx_admin_res_row_html($slug, $i, $res); $i++; }
    echo '</div>';
    echo '<button type="button" class="button smx-res-add">+ Add resource</button>';
    echo '</div>';
}

// Rebuild a song's resource list from the admin editor's posted rows, preserving
// band items' delete token (`k`) and `src` by matching on the row's hidden id.
// Rows with a blank URL (or a checked "remove") are dropped.
function smx_admin_merge_resources($slug, $rows, $prev) {
    $prevMeta = (isset($prev[$slug]) && is_array($prev[$slug])) ? $prev[$slug] : array();
    $prevRes  = smx_song_resources($prevMeta); // migrates legacy chart/lesson if not yet stored
    $prevById = array();
    foreach ($prevRes as $pr) { if (isset($pr['id'])) $prevById[$pr['id']] = $pr; }

    $out = array();
    if (is_array($rows)) {
        foreach ($rows as $rr) {
            if (!is_array($rr)) continue;
            if (!empty($rr['remove'])) continue;
            $url = smx_clean_res_url(isset($rr['url']) ? $rr['url'] : '');
            if ($url === '') continue; // blank row = nothing to save / cleared = removed
            $type = isset($rr['type']) ? sanitize_key($rr['type']) : 'link';
            if (!in_array($type, smx_resource_types(), true)) $type = smx_guess_res_type($url);
            $label = sanitize_text_field(isset($rr['label']) ? $rr['label'] : '');
            $label = function_exists('mb_substr') ? mb_substr($label, 0, 80) : substr($label, 0, 80);
            if ($label === '') { $h = wp_parse_url($url, PHP_URL_HOST); $label = $h ? preg_replace('/^www\./', '', $h) : 'Link'; }
            $desc = smx_clean_res_desc(isset($rr['desc']) ? $rr['desc'] : '');
            $id = isset($rr['id']) ? preg_replace('/[^A-Za-z0-9_]/', '', (string) $rr['id']) : '';
            $entry = array('id' => ($id !== '' ? $id : smx_new_res_id()), 'type' => $type, 'label' => $label, 'desc' => $desc, 'url' => $url, 'src' => 'admin');
            // If this id was a band add, keep it band-owned and preserve its token.
            if ($id !== '' && isset($prevById[$id]) && isset($prevById[$id]['src']) && $prevById[$id]['src'] === 'band') {
                $entry['src'] = 'band';
                if (isset($prevById[$id]['k'])) $entry['k'] = $prevById[$id]['k'];
            }
            if (count($out) >= 20) break; // hard cap
            $out[] = $entry;
        }
    }
    return $out;
}

// Band member adds one resource to a song (mixer → Resources → + add).
function smx_handle_res_add() {
    check_ajax_referer('smx_res', 'nonce');
    if (!smx_band_authed()) wp_send_json_error('not-authed', 403);
    // Light per-IP rate limit so a shared password can't be used to spam.
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_res_flood_' . md5($ip);
    $fails = (int) get_transient($lock);
    if ($fails >= 20) wp_send_json_error('slow-down', 429);
    set_transient($lock, $fails + 1, 5 * MINUTE_IN_SECONDS);

    $slug = isset($_POST['slug']) ? sanitize_key($_POST['slug']) : '';
    if ($slug === '') wp_send_json_error('bad-slug', 400);
    $url = smx_clean_res_url(isset($_POST['url']) ? wp_unslash($_POST['url']) : '');
    if ($url === '') wp_send_json_error('bad-url', 400);
    $label = sanitize_text_field(isset($_POST['label']) ? wp_unslash($_POST['label']) : '');
    if (function_exists('mb_substr')) $label = mb_substr($label, 0, 80); else $label = substr($label, 0, 80);
    $desc = smx_clean_res_desc(isset($_POST['desc']) ? wp_unslash($_POST['desc']) : '');
    $type = isset($_POST['type']) ? sanitize_key($_POST['type']) : '';
    if (!in_array($type, smx_resource_types(), true)) $type = smx_guess_res_type($url);
    if ($label === '') { $h = wp_parse_url($url, PHP_URL_HOST); $label = $h ? preg_replace('/^www\./', '', $h) : 'Link'; }

    $names = get_option(SMX_OPTION_SONGS, array());
    if (!is_array($names)) $names = array();
    $meta = (isset($names[$slug]) && is_array($names[$slug])) ? $names[$slug] : array();
    $res  = smx_song_resources($meta); // migrate legacy first so ids stay stable
    if (count($res) >= 20) wp_send_json_error('too-many', 400);

    $secret = wp_generate_password(24, false, false);
    $id     = smx_new_res_id();
    $res[]  = array('id' => $id, 'type' => $type, 'label' => $label, 'desc' => $desc, 'url' => $url, 'src' => 'band', 'k' => wp_hash($secret));
    $meta['resources'] = $res;
    $names[$slug] = $meta;
    update_option(SMX_OPTION_SONGS, $names);
    delete_transient(SMX_TRANSIENT_SCAN);

    wp_send_json_success(array('id' => $id, 'secret' => $secret, 'resources' => smx_res_public($res)));
}
add_action('wp_ajax_smx_res_add', 'smx_handle_res_add');
add_action('wp_ajax_nopriv_smx_res_add', 'smx_handle_res_add');

// Remove a band-added resource — only the browser that added it (matching token)
// or the WP admin can. Chris removes anything from Settings → STEMMAXXER.
function smx_handle_res_del() {
    check_ajax_referer('smx_res', 'nonce');
    if (!smx_band_authed()) wp_send_json_error('not-authed', 403);
    $slug   = isset($_POST['slug']) ? sanitize_key($_POST['slug']) : '';
    $id     = isset($_POST['id']) ? preg_replace('/[^A-Za-z0-9_]/', '', (string) wp_unslash($_POST['id'])) : '';
    $secret = isset($_POST['secret']) ? (string) wp_unslash($_POST['secret']) : '';
    $isAdmin = current_user_can('manage_options');
    $names = get_option(SMX_OPTION_SONGS, array());
    if (!is_array($names) || !isset($names[$slug]['resources']) || !is_array($names[$slug]['resources'])) wp_send_json_error('not-found', 404);
    $out = array(); $removed = false;
    foreach ($names[$slug]['resources'] as $r) {
        $isBand = (isset($r['src']) && $r['src'] === 'band');
        $ownsIt = $isBand && isset($r['k']) && $secret !== '' && hash_equals((string) $r['k'], wp_hash($secret));
        if ($r['id'] === $id && ($ownsIt || ($isAdmin && $isBand))) { $removed = true; continue; }
        $out[] = $r;
    }
    if (!$removed) wp_send_json_error('denied', 403);
    $names[$slug]['resources'] = $out;
    update_option(SMX_OPTION_SONGS, $names);
    delete_transient(SMX_TRANSIENT_SCAN);
    wp_send_json_success(array('resources' => smx_res_public($out)));
}
add_action('wp_ajax_smx_res_del', 'smx_handle_res_del');
add_action('wp_ajax_nopriv_smx_res_del', 'smx_handle_res_del');

// Edit a resource from the mixer. Any band member (gate-authed) may edit any
// resource that was ADDED VIA THE MIXER (src=band); items Chris added in
// Settings → STEMMAXXER (src=admin) are locked to admins. Preserves id/src/token.
function smx_handle_res_edit() {
    check_ajax_referer('smx_res', 'nonce');
    if (!smx_band_authed()) wp_send_json_error('not-authed', 403);
    // Light per-IP rate limit (shares the add flood bucket).
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_res_flood_' . md5($ip);
    $n = (int) get_transient($lock);
    if ($n >= 20) wp_send_json_error('slow-down', 429);
    set_transient($lock, $n + 1, 5 * MINUTE_IN_SECONDS);

    $slug = isset($_POST['slug']) ? sanitize_key($_POST['slug']) : '';
    $id   = isset($_POST['id']) ? preg_replace('/[^A-Za-z0-9_]/', '', (string) wp_unslash($_POST['id'])) : '';
    if ($slug === '' || $id === '') wp_send_json_error('bad-req', 400);

    $names = get_option(SMX_OPTION_SONGS, array());
    if (!is_array($names) || !isset($names[$slug]['resources']) || !is_array($names[$slug]['resources'])) wp_send_json_error('not-found', 404);

    $isAdmin = current_user_can('manage_options');
    $found = false;
    foreach ($names[$slug]['resources'] as &$r) {
        if (!isset($r['id']) || $r['id'] !== $id) continue;
        $found = true;
        $isBand = (isset($r['src']) && $r['src'] === 'band');
        // Bandmates may only edit mixer-added (band) items; admin items need admin.
        if (!$isBand && !$isAdmin) wp_send_json_error('locked', 403);

        $url = smx_clean_res_url(isset($_POST['url']) ? wp_unslash($_POST['url']) : '');
        if ($url === '') $url = isset($r['url']) ? $r['url'] : ''; // blank = keep existing link
        if ($url === '') wp_send_json_error('bad-url', 400);

        $label = sanitize_text_field(isset($_POST['label']) ? wp_unslash($_POST['label']) : '');
        $label = function_exists('mb_substr') ? mb_substr($label, 0, 80) : substr($label, 0, 80);
        if ($label === '') { $h = wp_parse_url($url, PHP_URL_HOST); $label = $h ? preg_replace('/^www\./', '', $h) : 'Link'; }

        $desc = smx_clean_res_desc(isset($_POST['desc']) ? wp_unslash($_POST['desc']) : '');

        $type = isset($_POST['type']) ? sanitize_key($_POST['type']) : '';
        if (!in_array($type, smx_resource_types(), true)) $type = smx_guess_res_type($url);

        $r['url'] = $url; $r['label'] = $label; $r['desc'] = $desc; $r['type'] = $type;
        break;
    }
    unset($r);
    if (!$found) wp_send_json_error('not-found', 404);

    update_option(SMX_OPTION_SONGS, $names);
    delete_transient(SMX_TRANSIENT_SCAN);
    wp_send_json_success(array('resources' => smx_res_public($names[$slug]['resources'])));
}
add_action('wp_ajax_smx_res_edit', 'smx_handle_res_edit');
add_action('wp_ajax_nopriv_smx_res_edit', 'smx_handle_res_edit');

/* ============================================================
 * FEEDBACK — bug reports / feature requests from the footer.
 * Emails Chris; the message comes "from STEMMAXXER" (display name) on the
 * site's own domain (SPF-safe), with the reporter's address as Reply-To.
 * ============================================================ */
function smx_feedback_recipient() { return apply_filters('smx_feedback_email', 'chris@kitemath.com'); }

function smx_handle_feedback() {
    check_ajax_referer('smx_fb', 'nonce');
    // Rate limit per IP so the shared page can't be used to flood the inbox.
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_fb_flood_' . md5($ip);
    $n = (int) get_transient($lock);
    if ($n >= 5) wp_send_json_error('slow-down', 429);
    set_transient($lock, $n + 1, 15 * MINUTE_IN_SECONDS);

    $kind = (isset($_POST['kind']) && $_POST['kind'] === 'feature') ? 'feature' : 'bug';
    $msg  = isset($_POST['message']) ? sanitize_textarea_field((string) wp_unslash($_POST['message'])) : '';
    $msg  = function_exists('mb_substr') ? mb_substr($msg, 0, 4000) : substr($msg, 0, 4000);
    if (trim($msg) === '') wp_send_json_error('empty', 400);

    $from_email = isset($_POST['from']) ? sanitize_email((string) wp_unslash($_POST['from'])) : '';
    $ctx  = isset($_POST['context']) ? sanitize_text_field((string) wp_unslash($_POST['context'])) : '';
    $ua   = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field((string) $_SERVER['HTTP_USER_AGENT']) : '';

    $label   = ($kind === 'feature') ? 'Feature request' : 'Bug report';
    $subject = 'STEMMAXXER ' . $label;

    // From on the site's own domain (avoids SPF/DMARC failures); display name = STEMMAXXER.
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    $host = $host ? preg_replace('/^www\./', '', $host) : 'localhost';
    $headers = array('From: STEMMAXXER <wordpress@' . $host . '>', 'Content-Type: text/plain; charset=UTF-8');
    if ($from_email !== '' && is_email($from_email)) $headers[] = 'Reply-To: ' . $from_email;

    $body  = $label . " sent from STEMMAXXER\n\n";
    $body .= trim($msg) . "\n\n----\n";
    $body .= 'From: ' . ($from_email !== '' ? $from_email : '(not provided)') . "\n";
    if ($ctx !== '') $body .= 'Song / context: ' . $ctx . "\n";
    $body .= 'Page: ' . home_url('/stemmaxxer.html') . "\n";
    if ($ua !== '')  $body .= 'Browser: ' . $ua . "\n";
    $body .= 'Time: ' . current_time('mysql') . "\n";

    $ok = wp_mail(smx_feedback_recipient(), $subject, $body, $headers);
    if (!$ok) wp_send_json_error('send-failed', 500);
    wp_send_json_success(array('kind' => $kind));
}
add_action('wp_ajax_smx_feedback', 'smx_handle_feedback');
add_action('wp_ajax_nopriv_smx_feedback', 'smx_handle_feedback');

/* ============================================================
 * ACTIVATION — rewrite rule + seed song names for the existing library
 * ============================================================ */

function smx_add_rewrite() {
    add_rewrite_rule('^stemmaxxer\.html$', 'index.php?' . SMX_QUERY_VAR . '=1', 'top');
    add_rewrite_rule('^stemmaxxer-add\.html$', 'index.php?' . SMX_QUERY_VAR . '=add', 'top');
}
add_action('init', 'smx_add_rewrite');

// Self-healing rewrite rules: whenever the plugin version changes (i.e. after an
// update, which does NOT fire the activation hook), flush the rules once on the
// next page load. This removes the manual "Settings → Permalinks → Save" step.
add_action('init', function () {
    if (get_option('smx_rw_version') !== SMX_VERSION) {
        smx_add_rewrite();
        flush_rewrite_rules(false); // soft flush — updates the rules option, no .htaccess write needed
        update_option('smx_rw_version', SMX_VERSION);
        // NOTE (v1.14.10): published beta features now PERSIST across updates, so a
        // "Publish to band" actually sticks — no more re-publishing after every build.
        // Fully-vetted features are made permanent instead by "graduating" them
        // (removed from BETA_FEATURES + bf-<key> class dropped) so they show for
        // everyone regardless of the published set. If a still-beta feature's code
        // changes in a way that shouldn't reach the band yet, un-publish it in the
        // Workbench (or bump its key) for that build.
        delete_option('smx_preview_live'); // retire the old all-or-nothing flag (one-time cleanup)
    }
}, 11);

/* Read the set of beta features currently published to the band.
 * Stored as a comma-separated list of feature keys in one option. */
function smx_get_published_features() {
    $raw = (string) get_option('smx_published_features', '');
    if ($raw === '') return array();
    $keys = array_map('sanitize_key', explode(',', $raw));
    return array_values(array_unique(array_filter($keys)));
}

/* Publish (or un-publish) ONE beta/preview feature to the whole band.
 * Each feature is toggled independently by its key, so a finished feature can go
 * live while another is still being polished. Passkey-gated (same key + lockout
 * as Deploy). Chris flips these from the Workbench once he's vetted each one. */
function smx_handle_preview_publish() {
    check_ajax_referer('smx_deploy', 'nonce');
    $ip = isset($_SERVER['REMOTE_ADDR']) ? preg_replace('/[^0-9a-fA-F:.]/', '', (string) $_SERVER['REMOTE_ADDR']) : 'unknown';
    $lock = 'smx_deploy_fail_' . md5($ip);
    $fails = (int) get_transient($lock);
    if ($fails >= 5) wp_send_json_error('locked', 429);
    $key = smx_get_deploy_key();
    if ($key === '' || $key === 'CHANGE-ME') wp_send_json_error('key-not-set', 400);
    $pass = isset($_POST['passkey']) ? (string) wp_unslash($_POST['passkey']) : '';
    if (!hash_equals($key, $pass)) {
        set_transient($lock, $fails + 1, 10 * MINUTE_IN_SECONDS);
        wp_send_json_error('bad-key', 403);
    }
    delete_transient($lock);
    $feature = isset($_POST['feature']) ? sanitize_key((string) wp_unslash($_POST['feature'])) : '';
    if ($feature === '') wp_send_json_error('no-feature', 400);
    $live = !empty($_POST['live']);
    $set = smx_get_published_features();
    if ($live) {
        if (!in_array($feature, $set, true)) $set[] = $feature;
    } else {
        $set = array_values(array_diff($set, array($feature)));
    }
    update_option('smx_published_features', implode(',', $set));
    wp_send_json_success(array('features' => array_values($set)));
}
add_action('wp_ajax_smx_preview_publish', 'smx_handle_preview_publish');
add_action('wp_ajax_nopriv_smx_preview_publish', 'smx_handle_preview_publish');

function smx_query_vars($vars) { $vars[] = SMX_QUERY_VAR; return $vars; }
add_filter('query_vars', 'smx_query_vars');

register_activation_hook(__FILE__, function () {
    smx_add_rewrite();
    flush_rewrite_rules();
    smx_ensure_key_file();

    // Seed artist/title names for the 12 existing songs (only if not already set)
    if (get_option(SMX_OPTION_SONGS) === false) {
        add_option(SMX_OPTION_SONGS, array(
            'song01' => array('artist' => 'Metric',                'title' => 'Black Sheep',               'hidden' => false),
            'song02' => array('artist' => 'Local H',               'title' => 'Bound For The Floor',       'hidden' => false),
            'song03' => array('artist' => 'Smashing Pumpkins',     'title' => 'Cherub Rock',               'hidden' => false),
            'song04' => array('artist' => 'The Pixies',            'title' => 'Gigantic',                  'hidden' => false),
            'song05' => array('artist' => 'The Hives',             'title' => 'Hate To Say I Told You So', 'hidden' => false),
            'song06' => array('artist' => 'The Jesus & Mary Chain','title' => 'Head On',                   'hidden' => false),
            'song07' => array('artist' => 'The Ramones',           'title' => 'I Wanna Be Sedated',        'hidden' => false),
            'song08' => array('artist' => 'Black Sabbath',         'title' => 'Iron Man',                  'hidden' => false),
            'song09' => array('artist' => 'Metallica',             'title' => 'Seek & Destroy',            'hidden' => false),
            'song10' => array('artist' => 'Ecca Vandal',           'title' => 'MOLLY',                     'hidden' => false),
            'song11' => array('artist' => 'The Cult',              'title' => 'She Sells Sanctuary',       'hidden' => false),
            'song12' => array('artist' => 'Echo & The Bunnymen',   'title' => 'The Killing Moon',          'hidden' => false),
        ));
    }
    if (get_option(SMX_OPTION_SETTINGS) === false) {
        add_option(SMX_OPTION_SETTINGS, array('password' => '', 'logo_url' => ''));
    }
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
    delete_transient(SMX_TRANSIENT_SCAN);
});

/* ============================================================
 * SONG DISCOVERY — scan the uploads folder for stem files
 * Pattern: SongNN-MM-StemName.(m4a|mp3|wav|ogg)
 * ============================================================ */

/**
 * The mixer's fixed channel order (left → right). Every song shows only the
 * instruments it actually has, always in this order. Matching is by the
 * instrument name at the end of the file name — no track numbering needed.
 */
function smx_canonical_instruments() {
    return array('count in', 'click', 'drums', 'guitar', 'bass', 'piano', 'vocals', 'other');
}
function smx_instrument_rank($name) {
    $i = array_search(strtolower(trim($name)), smx_canonical_instruments(), true);
    return ($i === false) ? 100 : $i;   // unknown instruments sort after "Other"
}
/** token like "Black_Sabbath" → "Black Sabbath" */
function smx_prettify_token($tok) {
    return trim(preg_replace('/\s+/', ' ', str_replace('_', ' ', $tok)));
}

function smx_scan_uploads($force = false) {
    if (!$force) {
        $cached = get_transient(SMX_TRANSIENT_SCAN);
        if ($cached !== false) return $cached;
    }

    $up       = wp_get_upload_dir();
    $base_dir = $up['basedir'];
    $base_url = $up['baseurl'];
    $raw      = array();   // slug => song record being assembled
    $ignored  = array();

    if (is_dir($base_dir)) {
        $iter = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($base_dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($iter as $file) {
            if (!$file->isFile()) continue;
            $fname = $file->getFilename();
            $rel   = str_replace('\\', '/', substr($file->getPathname(), strlen($base_dir)));
            $url   = $base_url . $rel;
            $mtime = $file->getMTime();

            // NEW scheme:  Band__Song__Instrument.ext  (from the Stem Converter)
            if (preg_match('/^([A-Za-z0-9_]+?)__([A-Za-z0-9_]+?)__([A-Za-z0-9_]+?)\.(m4a|mp4|mp3|wav|ogg)$/i', $fname, $m)) {
                $band = smx_prettify_token($m[1]);
                $song = smx_prettify_token($m[2]);
                $inst = smx_prettify_token($m[3]);
                $slug = sanitize_key(strtolower($m[1]) . '__' . strtolower($m[2]));
                $ikey = strtolower($inst);
                if (!isset($raw[$slug])) $raw[$slug] = array('slug' => $slug, 'scheme' => 'named', 'd_artist' => $band, 'd_title' => $song, 'stems' => array());
                // Duplicate instrument (re-upload in another month folder): newest file wins
                if (isset($raw[$slug]['stems'][$ikey]) && $raw[$slug]['stems'][$ikey]['mtime'] >= $mtime) continue;
                $raw[$slug]['stems'][$ikey] = array('name' => $inst, 'url' => $url, 'mtime' => $mtime);
                continue;
            }

            // LEGACY scheme:  SongNN-MM-StemName.ext
            if (preg_match('/^(song\d+)-(\d+)-([A-Za-z0-9_]+)\.(m4a|mp4|mp3|wav|ogg)$/i', $fname, $m)) {
                $slug = strtolower($m[1]);
                $name = smx_prettify_token($m[3]);
                $ikey = strtolower($name);
                if (!isset($raw[$slug])) $raw[$slug] = array('slug' => $slug, 'scheme' => 'legacy', 'd_artist' => '', 'd_title' => '', 'stems' => array());
                if (isset($raw[$slug]['stems'][$ikey]) && $raw[$slug]['stems'][$ikey]['mtime'] >= $mtime) continue;
                $raw[$slug]['stems'][$ikey] = array('name' => $name, 'url' => $url, 'mtime' => $mtime);
                continue;
            }

            // Looks like one of ours but doesn't cleanly match (usually a WordPress "-1"
            // collision rename) — surface it in admin so the file can be fixed.
            if (preg_match('/\.(m4a|mp4|mp3|wav|ogg)$/i', $fname) && (strpos($fname, '__') !== false || preg_match('/^song\d+/i', $fname))) {
                $ignored[] = $fname;
            }
        }
    }

    // Finalize: order each song's stems by the fixed instrument order
    $out = array();
    foreach ($raw as $rec) {
        $stems = array_values($rec['stems']);
        usort($stems, function ($a, $b) {
            $ra = smx_instrument_rank($a['name']);
            $rb = smx_instrument_rank($b['name']);
            if ($ra !== $rb) return $ra - $rb;
            return strcmp(strtolower($a['name']), strtolower($b['name']));
        });
        $list = array();
        foreach ($stems as $s) $list[] = array('name' => $s['name'], 'url' => $s['url']);
        $out[] = array('slug' => $rec['slug'], 'scheme' => $rec['scheme'], 'd_artist' => $rec['d_artist'], 'd_title' => $rec['d_title'], 'stems' => $list);
    }

    $result = array('songs' => $out, 'ignored' => $ignored, 'scanned_at' => time());
    set_transient(SMX_TRANSIENT_SCAN, $result, 10 * MINUTE_IN_SECONDS);
    return $result;
}

// New uploads/deletions should invalidate the cache immediately
add_action('add_attachment',    function () { delete_transient(SMX_TRANSIENT_SCAN); });
add_action('delete_attachment', function () { delete_transient(SMX_TRANSIENT_SCAN); });

/**
 * Merge scan results with the saved artist/title names.
 * Returns the array the player consumes.
 */
function smx_get_player_songs() {
    $scan  = smx_scan_uploads();
    $names = get_option(SMX_OPTION_SONGS, array());
    $songs = array();

    foreach ($scan['songs'] as $s) {
        $slug = $s['slug'];
        $meta = isset($names[$slug]) ? $names[$slug] : array('artist' => '', 'title' => '', 'hidden' => false);
        if (!empty($meta['hidden'])) continue;
        if (empty($s['stems'])) continue;

        // Display band/song: an admin override wins; otherwise the name derived
        // from the file name (new scheme) or the SONGNN placeholder (legacy).
        $artist = trim(isset($meta['artist']) ? $meta['artist'] : '');
        if ($artist === '') $artist = $s['d_artist'];

        $title = trim(isset($meta['title']) ? $meta['title'] : '');
        if ($title === '') $title = ($s['d_title'] !== '') ? $s['d_title'] : strtoupper($slug);

        // Per-song links (admin + band adds), migrated from the old chart/lesson pair.
        $resources = smx_res_public(smx_song_resources($meta));

        // The non-beta Charts / Lesson buttons derive from resources when present,
        // so they keep working even after a song's links move into the new list.
        $chart  = isset($meta['chart_url'])  ? $meta['chart_url']  : '';
        $lesson = isset($meta['lesson_url']) ? $meta['lesson_url'] : '';
        foreach ($resources as $r) {
            if ($chart === ''  && ($r['type'] === 'tab' || $r['type'] === 'chords')) $chart  = $r['url'];
            if ($lesson === '' && $r['type'] === 'video') $lesson = $r['url'];
        }

        $songs[] = array(
            'slug'    => $slug,
            'artist'  => $artist,
            'title'   => $title,
            'bpm'     => (isset($meta['bpm']) && is_numeric($meta['bpm']) && $meta['bpm'] > 0) ? floatval($meta['bpm']) : null,
            'chart'   => $chart,
            'lesson'  => $lesson,
            'resources' => $resources,
            'stems'   => $s['stems'],
        );
    }

    // Alphabetical by band, then song — this is the dropdown order the band sees.
    usort($songs, function ($a, $b) {
        $ka = strtolower(trim($a['artist'] . ' ' . $a['title']));
        $kb = strtolower(trim($b['artist'] . ' ' . $b['title']));
        return strcmp($ka, $kb);
    });
    return $songs;
}

/* ============================================================
 * FRONT END — serve the player at /stemmaxxer.html
 * ============================================================ */

/* ============================================================
 * TRAFFIC — a light per-day hit counter for the player page, so Chris can spot
 * if the private link has spread beyond the band (a sudden spike). Stored in a
 * single non-autoloaded option, pruned to the last ~60 days. Not analytics —
 * just a rough "is this getting way more traffic than a few people practicing?"
 * ============================================================ */

function smx_log_hit() {
    // Skip obvious bots/monitors so the number reflects real people.
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
    if ($ua !== '' && preg_match('/bot|crawl|spider|slurp|bing|yandex|monitor|facebookexternalhit|headless|preview|lighthouse|pingdom|uptime/i', $ua)) return;
    $day   = current_time('Y-m-d');
    $stats = get_option('smx_stats', array());
    if (!is_array($stats)) $stats = array();
    $stats[$day] = (isset($stats[$day]) ? (int) $stats[$day] : 0) + 1;
    if (count($stats) > 75) { ksort($stats); $stats = array_slice($stats, -60, null, true); }
    update_option('smx_stats', $stats, false); // no autoload
}

// Last $days of daily counts (oldest→today) + total, for the Workbench Traffic tab.
function smx_stats_series($days = 30) {
    $stats = get_option('smx_stats', array());
    if (!is_array($stats)) $stats = array();
    $out = array(); $total = 0;
    $todayTs = strtotime(current_time('Y-m-d'));
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = gmdate('Y-m-d', $todayTs - $i * DAY_IN_SECONDS);
        $n = isset($stats[$d]) ? (int) $stats[$d] : 0;
        $out[] = array('d' => $d, 'n' => $n);
        $total += $n;
    }
    return array('days' => $out, 'total' => $total);
}

function smx_render_player_page() {
    $settings = get_option(SMX_OPTION_SETTINGS, array('password' => '', 'logo_url' => ''));
    $password = isset($settings['password']) ? (string) $settings['password'] : '';

    // ---- Password gate (only if a password is set) ----
    if ($password !== '') {
        $expected = hash_hmac('sha256', $password, wp_salt('auth'));

        if (isset($_POST['smx_pass'])) {
            if (hash_equals($password, (string) wp_unslash($_POST['smx_pass']))) {
                setcookie(SMX_COOKIE, $expected, time() + 30 * DAY_IN_SECONDS, '/', '', is_ssl(), true);
                wp_safe_redirect(home_url('/stemmaxxer.html'));
                exit;
            }
            smx_render_gate(true);
            exit;
        }

        $cookie = isset($_COOKIE[SMX_COOKIE]) ? (string) $_COOKIE[SMX_COOKIE] : '';
        if (!hash_equals($expected, $cookie)) {
            smx_render_gate(false);
            exit;
        }
    }

    smx_log_hit(); // count this page load (bots skipped) — for the Workbench Traffic tab

    // ---- Render the player ----
    $smx_songs_json = wp_json_encode(smx_get_player_songs());
    $smx_stats_json = wp_json_encode(smx_stats_series(30));
    $smx_logo_url   = (isset($settings['logo_url']) && $settings['logo_url'] !== '')
        ? esc_url($settings['logo_url'])
        : plugins_url('assets/logo.png', __FILE__); // bundled STEMMAXXER logo by default
    // Square album-cover art for the iOS/Android lock-screen "Now Playing" widget
    // (Media Session API). Bundled, always the STEMMAXXER cover — replaces the
    // low-res site favicon that the OS falls back to otherwise.
    $smx_cover_url     = plugins_url('assets/cover.png', __FILE__);
    $smx_cover_512_url = plugins_url('assets/cover-512.png', __FILE__);
    $smx_version    = SMX_VERSION;
    $smx_add_url    = home_url('/stemmaxxer-add.html'); // on-site "Add a Song" uploader
    $smx_published_json = wp_json_encode(smx_get_published_features()); // beta features published to the band, by key

    // Deployed (site-wide) workbench defaults + deploy endpoint (passkey-gated, no login needed)
    $wb_live            = get_option(SMX_OPTION_WORKBENCH, array());
    $smx_wb_live_json   = wp_json_encode(is_array($wb_live) ? (object) $wb_live : new stdClass());
    $smx_ajax_url_json  = wp_json_encode(admin_url('admin-ajax.php'));
    $smx_nonce_json     = wp_json_encode(wp_create_nonce('smx_deploy'));
    $dkey               = smx_get_deploy_key();
    $smx_key_set_json   = ($dkey !== '' && $dkey !== 'CHANGE-ME') ? 'true' : 'false'; // is the Workbench passkey-gated?

    // Song-resources (per-song links) — nonce for band add/remove + whether this
    // visitor is band-authed (logged-in admin, or passed the gate so has the cookie).
    $smx_res_nonce_json = wp_json_encode(wp_create_nonce('smx_res'));
    $smx_band_auth_json = smx_band_authed() ? 'true' : 'false';

    // Feedback (footer bug report / feature request) nonce.
    $smx_fb_nonce_json  = wp_json_encode(wp_create_nonce('smx_fb'));

    header('X-Robots-Tag: noindex, nofollow', true);
    status_header(200);
    nocache_headers();
    include __DIR__ . '/templates/player.php';
    exit;
}

function smx_render_gate($failed) {
    header('X-Robots-Tag: noindex, nofollow', true);
    status_header(200);
    nocache_headers();
    $smx_failed = $failed;
    include __DIR__ . '/templates/gate.php';
}

add_action('template_redirect', function () {
    $pv = get_query_var(SMX_QUERY_VAR);
    if ($pv === 'add') { smx_render_add_page(); }
    else if ($pv)      { smx_render_player_page(); }
});

// Safety net: resolve the pretty URLs directly from the request path, without
// depending on the rewrite rules being flushed. This means the player and the
// uploader work immediately on install AND after every update — no "Save
// Permalinks" step ever. The /?stemmaxxer=1 and /?stemmaxxer_add=1 query forms
// also always work.
add_action('parse_request', function ($wp) {
    if (isset($_GET['stemmaxxer_add'])) { smx_render_add_page(); }
    if (isset($_GET['stemmaxxer']))     { smx_render_player_page(); }

    // Path relative to the site root (WP already strips the home path into ->request)
    $req = isset($wp->request) ? (string) $wp->request : '';
    if ($req === '') {
        $path = wp_parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
        $home = wp_parse_url(home_url('/'), PHP_URL_PATH);
        $req  = preg_replace('#^' . preg_quote((string) $home, '#') . '#', '', (string) $path);
    }
    $req = strtolower(trim((string) $req, '/'));
    if ($req === 'stemmaxxer.html')     { smx_render_player_page(); }
    if ($req === 'stemmaxxer-add.html') { smx_render_add_page(); }
});

function smx_render_add_page() {
    $key = smx_get_deploy_key();
    $smx_key_set  = ($key !== '' && $key !== 'CHANGE-ME');
    $smx_assets   = plugins_url('assets/', __FILE__);
    $smx_ajax_url = admin_url('admin-ajax.php');
    $smx_nonce    = wp_create_nonce('smx_ingest');
    $smx_version  = SMX_VERSION;

    // Existing songs, so a single stem (e.g. a missing Click) can be added to one
    // of them. Each carries a `sample` filename (original casing) that the page
    // uses to build the new stem's name so it joins that exact song + scheme.
    $scan    = smx_scan_uploads();
    $names   = get_option(SMX_OPTION_SONGS, array());
    $existing = array();
    foreach ($scan['songs'] as $s) {
        if (empty($s['stems'])) continue;
        $slug  = $s['slug'];
        $meta  = isset($names[$slug]) ? $names[$slug] : array();
        $artist = (isset($meta['artist']) && $meta['artist'] !== '') ? $meta['artist'] : $s['d_artist'];
        $title  = (isset($meta['title'])  && $meta['title']  !== '') ? $meta['title']  : ($s['d_title'] !== '' ? $s['d_title'] : strtoupper($slug));
        $label  = trim(($artist !== '' ? $artist . ' — ' : '') . $title);
        $sample = basename(parse_url($s['stems'][0]['url'], PHP_URL_PATH));
        $have   = array();
        foreach ($s['stems'] as $st) $have[] = $st['name'];
        $existing[] = array('slug' => $slug, 'label' => $label, 'scheme' => $s['scheme'], 'sample' => $sample, 'have' => $have);
    }
    usort($existing, function ($a, $b) { return strcasecmp($a['label'], $b['label']); });
    $smx_existing_json = wp_json_encode($existing);

    header('X-Robots-Tag: noindex, nofollow', true);
    status_header(200);
    nocache_headers();
    include __DIR__ . '/templates/add.php';
    exit;
}

/* ============================================================
 * ADMIN — Settings → STEMMAXXER
 * ============================================================ */

add_action('admin_menu', function () {
    add_options_page('STEMMAXXER', 'STEMMAXXER', 'manage_options', 'stemmaxxer', 'smx_admin_page');
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=stemmaxxer')) . '">Settings</a>');
    return $links;
});

function smx_admin_page() {
    if (!current_user_can('manage_options')) return;

    $notice = '';

    // Handle save
    if (isset($_POST['smx_admin_nonce']) && wp_verify_nonce($_POST['smx_admin_nonce'], 'smx_admin_save')) {

        if (isset($_POST['smx_action']) && $_POST['smx_action'] === 'rescan') {
            smx_scan_uploads(true);
            $notice = 'Library rescanned.';
        } else {
            // Save song names. IMPORTANT: resources are MERGED, not rebuilt —
            // band-added items carry a per-device delete token (`k`) that the
            // admin form never sees, so we preserve `k`/`src` by matching id
            // against what's already stored.
            $prev  = get_option(SMX_OPTION_SONGS, array());
            if (!is_array($prev)) $prev = array();
            $names = array();
            if (isset($_POST['smx_song']) && is_array($_POST['smx_song'])) {
                foreach (wp_unslash($_POST['smx_song']) as $slug => $row) {
                    $slug = sanitize_key($slug);
                    $names[$slug] = array(
                        'artist'    => sanitize_text_field(isset($row['artist']) ? $row['artist'] : ''),
                        'title'     => sanitize_text_field(isset($row['title'])  ? $row['title']  : ''),
                        'bpm'       => (isset($row['bpm']) && is_numeric($row['bpm']) && floatval($row['bpm']) > 0) ? floatval($row['bpm']) : '',
                        'hidden'    => !empty($row['hidden']),
                        'resources' => smx_admin_merge_resources($slug, isset($row['resources']) ? $row['resources'] : array(), $prev),
                    );
                }
            }
            update_option(SMX_OPTION_SONGS, $names);

            // Save settings
            $settings = get_option(SMX_OPTION_SETTINGS, array());
            $settings['password'] = sanitize_text_field(wp_unslash(isset($_POST['smx_password']) ? $_POST['smx_password'] : ''));
            $settings['logo_url'] = esc_url_raw(wp_unslash(isset($_POST['smx_logo_url']) ? $_POST['smx_logo_url'] : ''));
            update_option(SMX_OPTION_SETTINGS, $settings);

            $notice = 'Saved.';
        }
    }

    $scan     = smx_scan_uploads();
    $names    = get_option(SMX_OPTION_SONGS, array());
    $settings = get_option(SMX_OPTION_SETTINGS, array('password' => '', 'logo_url' => ''));
    $player_url = home_url('/stemmaxxer.html');
    ?>
    <div class="wrap">
      <h1>STEMMAXXER <small style="font-size:12px;color:#888;">v<?php echo esc_html(SMX_VERSION); ?></small></h1>

      <?php if ($notice): ?>
        <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
      <?php endif; ?>

      <?php if (empty($settings['password'])): ?>
        <div class="notice notice-warning"><p><strong>No access password is set.</strong> The player at
        <a href="<?php echo esc_url($player_url); ?>" target="_blank"><?php echo esc_html($player_url); ?></a>
        is currently open to anyone with the URL. Set a password below to keep it private to the band.</p></div>
      <?php endif; ?>

      <p>
        Player URL: <a href="<?php echo esc_url($player_url); ?>" target="_blank"><code><?php echo esc_html($player_url); ?></code></a>
        &nbsp;·&nbsp; Songs detected: <strong><?php echo count($scan['songs']); ?></strong>
      </p>

      <h2 class="title">How to add a song (no code, no lists, no numbering)</h2>
      <ol style="max-width:780px;">
        <li>Export the stems from Logic, then run them through the <strong>STEMMAXXER Stem Converter</strong>. It names each file
            <code><strong>Band</strong>__<strong>Song</strong>__<strong>Instrument</strong>.mp3</code>
            &mdash; e.g. <code>Black_Sabbath__Iron_Man__Drums.mp3</code>.</li>
        <li>Upload them to <strong>Media &rarr; Add New</strong> like normal.</li>
        <li>That's it. Every file sharing the same <code>Band__Song</code> becomes one song; each stem drops onto its instrument channel
            automatically (in the order <em>Count In · Click · Drums · Guitar · Bass · Piano · Vocals · Other</em>), and songs are listed
            alphabetically by band then title. Band &amp; title come straight from the file name &mdash; only edit below if you want to
            tidy them (e.g. restore an &ldquo;&amp;&rdquo;).</li>
      </ol>
      <p style="max-width:780px;color:#666;"><em>The older <code>SongNN-MM-StemName</code> files still work too, so your existing songs
      keep playing untouched &mdash; new and old appear together in one alphabetical list. If you re-upload a file with the same name,
      WordPress renames it (e.g. <code>&hellip;__Drums-1.mp3</code>) and the player ignores it &mdash; delete the old file first, then re-upload.</em></p>

      <form method="post">
        <?php wp_nonce_field('smx_admin_save', 'smx_admin_nonce'); ?>

        <h2 class="title">Songs</h2>
        <p style="max-width:780px;color:#666;margin-top:-4px;">Listed alphabetically by band then title (the order the band sees). Artist/Title
        are pre-filled from the file name for new-scheme songs &mdash; leave them and they just work, or type to override.</p>
        <p style="max-width:820px;color:#666;margin-top:-4px;"><strong>Resources</strong> are optional per-song links &mdash; tabs, chords, video lessons, a reference mix, anything. Pick a type (sets the icon), give it a short label, paste the URL, and it appears under that song&rsquo;s <em>Resources</em> button in the mixer. Add as many as you like (up to 20). Bandmates can also add their own from the mixer once they&rsquo;ve entered the access password; those show a <em>band</em> tag here and you can edit or remove any of them. Your old Chart&nbsp;/&nbsp;Lesson links are migrated in as the first resources automatically.</p>
        <table class="widefat striped" style="max-width:1240px;">
          <thead>
            <tr><th style="width:96px;">Song&nbsp;ID</th><th style="width:44px;">Stems</th><th style="width:150px;">Artist</th><th style="width:150px;">Title</th><th style="width:62px;">BPM</th><th style="width:44px;">Hide</th><th>Resources</th></tr>
          </thead>
          <tbody>
          <?php if (empty($scan['songs'])): ?>
            <tr><td colspan="7">No stem files found yet. Upload files named <code>Band__Song__Instrument.mp3</code> (from the Stem Converter) to Media.</td></tr>
          <?php else:
            // Show the admin table in the same alphabetical order as the player
            $rows = $scan['songs'];
            usort($rows, function ($a, $b) use ($names) {
                $an = isset($names[$a['slug']]) ? $names[$a['slug']] : array();
                $bn = isset($names[$b['slug']]) ? $names[$b['slug']] : array();
                $ax = trim((!empty($an['artist']) ? $an['artist'] : $a['d_artist']) . ' ' . (!empty($an['title']) ? $an['title'] : ($a['d_title'] !== '' ? $a['d_title'] : $a['slug'])));
                $bx = trim((!empty($bn['artist']) ? $bn['artist'] : $b['d_artist']) . ' ' . (!empty($bn['title']) ? $bn['title'] : ($b['d_title'] !== '' ? $b['d_title'] : $b['slug'])));
                return strcmp(strtolower($ax), strtolower($bx));
            });
            foreach ($rows as $s):
              $slug = $s['slug'];
              $meta = isset($names[$slug]) ? $names[$slug] : array('artist'=>'','title'=>'','bpm'=>'','hidden'=>false);
              $id_label = ($s['scheme'] === 'legacy') ? strtoupper($slug) : 'NEW';
          ?>
            <tr>
              <td><code style="font-size:11px;"><?php echo esc_html($id_label); ?></code></td>
              <td><?php echo count($s['stems']); ?></td>
              <td><input type="text" name="smx_song[<?php echo esc_attr($slug); ?>][artist]" value="<?php echo esc_attr(isset($meta['artist']) ? $meta['artist'] : ''); ?>" class="regular-text" style="width:100%;" placeholder="<?php echo esc_attr($s['d_artist'] !== '' ? $s['d_artist'] : 'Artist'); ?>"></td>
              <td><input type="text" name="smx_song[<?php echo esc_attr($slug); ?>][title]"  value="<?php echo esc_attr(isset($meta['title']) ? $meta['title'] : ''); ?>"  class="regular-text" style="width:100%;" placeholder="<?php echo esc_attr($s['d_title'] !== '' ? $s['d_title'] : 'Song title'); ?>"></td>
              <td><input type="number" step="0.1" min="0" name="smx_song[<?php echo esc_attr($slug); ?>][bpm]" value="<?php echo esc_attr(isset($meta['bpm']) ? $meta['bpm'] : ''); ?>" style="width:70px;" placeholder="auto"></td>
              <td style="text-align:center;"><input type="checkbox" name="smx_song[<?php echo esc_attr($slug); ?>][hidden]" <?php checked(!empty($meta['hidden'])); ?>></td>
              <td><?php smx_admin_render_resources_cell($slug, smx_song_resources($meta)); ?></td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>

        <style>
          .smx-res-cell{display:flex;flex-direction:column;gap:6px;}
          .smx-res-rows{display:flex;flex-direction:column;gap:6px;}
          .smx-res-row{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
          .smx-res-row select{min-width:118px;}
          .smx-res-row input.smx-res-label{flex:1 1 34%;min-width:120px;}
          .smx-res-row input[type=url]{flex:1 1 46%;min-width:150px;}
          .smx-res-desc{flex:1 1 100%;font-size:12px;color:#333;}
          .smx-res-band{font-size:10px;font-weight:600;letter-spacing:.04em;text-transform:uppercase;color:#8a5a00;background:#fff3d6;border:1px solid #f0c96b;border-radius:4px;padding:1px 5px;white-space:nowrap;}
          .smx-res-rm{color:#a00 !important;text-decoration:none !important;font-size:20px;line-height:1;padding:0 4px;}
          .smx-res-rm:hover{color:#d00 !important;}
          .smx-res-add{width:max-content;}
        </style>
        <script>
        (function(){
          // Build <option>s in JS from a JSON list. (Do NOT esc_js() option HTML — that
          // escapes the tags, so injecting it via innerHTML yields an empty dropdown.)
          var SMX_RES_TYPES = <?php echo wp_json_encode(array_map(function($v, $l){ return array($v, $l); }, array_keys(smx_res_type_labels()), array_values(smx_res_type_labels()))); ?>;
          function typeOpts(sel){
            var o = '';
            for (var i = 0; i < SMX_RES_TYPES.length; i++) {
              var v = SMX_RES_TYPES[i][0], l = SMX_RES_TYPES[i][1];
              o += '<option value="' + v + '"' + (v === (sel || 'link') ? ' selected' : '') + '>' + l + '</option>';
            }
            return o;
          }
          function rowHtml(slug, i){
            var b = 'smx_song[' + slug + '][resources][' + i + ']';
            return '<div class="smx-res-row">'
              + '<input type="hidden" name="' + b + '[id]" value="">'
              + '<select name="' + b + '[type]">' + typeOpts() + '</select>'
              + '<input type="text" class="smx-res-label" name="' + b + '[label]" placeholder="Label (e.g. Guitar lesson)" maxlength="80">'
              + '<input type="url" name="' + b + '[url]" placeholder="https://…">'
              + '<button type="button" class="button-link smx-res-rm" title="Remove this resource" aria-label="Remove">&times;</button>'
              + '<input type="text" class="smx-res-desc" name="' + b + '[desc]" placeholder="Description (optional) — e.g. note-for-note guitar, slow then full speed" maxlength="160">'
              + '</div>';
          }
          document.addEventListener('click', function(e){
            var add = e.target.closest ? e.target.closest('.smx-res-add') : null;
            if (add){
              e.preventDefault();
              var cell = add.closest('.smx-res-cell');
              var n = parseInt(cell.getAttribute('data-n') || '0', 10) || 0;
              cell.setAttribute('data-n', n + 1);
              var rows = cell.querySelector('.smx-res-rows');
              rows.insertAdjacentHTML('beforeend', rowHtml(cell.getAttribute('data-slug'), n));
              var last = rows.lastElementChild ? rows.lastElementChild.querySelector('input[type=url]') : null;
              if (last) last.focus();
              return;
            }
            var rm = e.target.closest ? e.target.closest('.smx-res-rm') : null;
            if (rm){ e.preventDefault(); var row = rm.closest('.smx-res-row'); if (row) row.parentNode.removeChild(row); }
          });
        })();
        </script>

        <?php if (!empty($scan['ignored'])): ?>
          <p style="color:#996800;max-width:780px;"><strong>Ignored files</strong> (look like ours but don't cleanly match
          <code>Band__Song__Instrument.ext</code> or <code>SongNN-MM-StemName.ext</code> &mdash; usually WordPress collision renames):<br>
          <code><?php echo esc_html(implode('</code>, <code>', array_map('esc_html', $scan['ignored']))); ?></code></p>
        <?php endif; ?>

        <h2 class="title">Player settings</h2>
        <table class="form-table" style="max-width:900px;">
          <tr>
            <th scope="row"><label for="smx_password">Access password</label></th>
            <td>
              <input type="text" id="smx_password" name="smx_password" value="<?php echo esc_attr($settings['password']); ?>" class="regular-text" autocomplete="off">
              <p class="description">Anyone opening the player must enter this once (remembered for 30 days). Leave blank to disable the gate (not recommended).</p>
            </td>
          </tr>
          <tr>
            <th scope="row"><label for="smx_logo_url">Logo image URL</label></th>
            <td>
              <input type="url" id="smx_logo_url" name="smx_logo_url" value="<?php echo esc_attr($settings['logo_url']); ?>" class="regular-text" placeholder="https://mmn.rocks/wp-content/uploads/.../stemmaxxer-logo.png">
              <p class="description">Optional. The STEMMAXXER logo shipped with the plugin is used by default. To use a different image, upload it to Media and paste its URL here.</p>
            </td>
          </tr>
        </table>

        <p class="submit">
          <button type="submit" class="button button-primary">Save changes</button>
        </p>
      </form>

      <form method="post" style="margin-top:-8px;">
        <?php wp_nonce_field('smx_admin_save', 'smx_admin_nonce'); ?>
        <input type="hidden" name="smx_action" value="rescan">
        <button type="submit" class="button">Rescan library now</button>
        <span style="color:#666;margin-left:8px;">(happens automatically on upload; this is just a manual refresh)</span>
      </form>

      <h2 class="title" style="margin-top:28px;">Deploy passkey</h2>
      <p style="max-width:760px;">The Workbench DEPLOY button (in the player) asks for a passkey instead of a WordPress login.
      It lives in <code><?php echo esc_html(SMX_KEY_FILE); ?></code> — edit that file via your host's file manager or FTP
      and change <code>CHANGE-ME</code> to your secret. Plugin updates never touch it.
      <?php $k = smx_get_deploy_key(); if ($k === '' || $k === 'CHANGE-ME'): ?>
        <strong style="color:#b32d2e;">Currently not set — deploys are disabled until you change it.</strong>
      <?php else: ?>
        <span style="color:#008a20;">Passkey is set.</span>
      <?php endif; ?></p>

      <h2 class="title" style="margin-top:28px;">Updating this plugin</h2>
      <p style="max-width:760px;">When there's a new version: <strong>Plugins &rarr; Add New &rarr; Upload Plugin</strong>, choose the new
      <code>stemmaxxer.zip</code>, and WordPress will offer <em>"Replace current with uploaded"</em>. Your songs, names, and password are stored
      in the database and survive updates.</p>
    </div>
    <?php
}
