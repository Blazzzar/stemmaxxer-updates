=== STEMMAXXER ===
Contributors: chrisjennings
Requires at least: 5.5
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 2.0.0-beta.13

Multi-stem practice mixer for the band. Serves the player at /stemmaxxer.html and
auto-discovers songs from the media uploads folder.

== Install ==
1. Plugins → Add New → Upload Plugin → choose stemmaxxer.zip → Install Now → Activate.
2. Go to Settings → STEMMAXXER and set the access password.
3. Open https://mmn.rocks/stemmaxxer.html — done.

(No "Save Permalinks" step needed — the player and uploader addresses resolve on
their own, on install and after every update.)

== Update ==
STEMMAXXER updates itself from its own GitHub release channel (since 2.0.0-beta.12).
When a new build is published, the normal WordPress "update available" row appears
under the plugin — click "update now" and you're done. To see a fresh publish
immediately instead of waiting for WordPress's periodic check, use the
"Check for updates" link in the plugin's row on the Plugins screen.

The plugin row also offers:
- "Switch to beta/stable channel" — beta receives every new build (this site's
  default during the 2.0 beta cycle); stable receives promoted releases only.
- "Roll back to X" — one click reinstalls the previous retained release through
  WordPress's normal upgrade flow, if an update ever misbehaves.

Song names, password, and settings live in the database and survive updates.

Manual fallback (always works): Plugins → Add New → Upload Plugin → choose the new
stemmaxxer zip → "Replace current with uploaded."

== Adding a song (no code, no numbering) ==
1. Export the stems from Logic, then run them through the STEMMAXXER Stem
   Converter (stemmaxxer-converter.html). It names each file:
     Band__Song__Instrument.mp3
   e.g.  Black_Sabbath__Iron_Man__Drums.mp3
         Black_Sabbath__Iron_Man__Guitar.mp3
   (double underscore between the three parts; single underscore for spaces).
2. Upload them via Media → Add New.
3. The song appears automatically. Every file sharing the same Band__Song
   becomes one song; each stem lands on its instrument channel by name, in
   the fixed order Count In · Click · Drums · Guitar · Bass · Piano · Vocals · Other.
   Band and title come straight from the file name — only edit them under
   Settings → STEMMAXXER if you want to tidy one up (e.g. restore an "&").

Notes:
- Songs are listed alphabetically by band, then title.
- Supported extensions: m4a, mp4, mp3, wav, ogg.
- The older SongNN-MM-StemName files still work, so existing songs keep
  playing — old and new appear together in one alphabetical list.
- Re-uploading a file with the same name makes WordPress rename it
  (…__Drums-1.mp3) and the player ignores it. Delete the old file first,
  then upload the replacement.
- A feature "+" button sits in each channel's header (every stem except
  Count In). Its keyboard shortcut is the stem's first letter.

== Adding a song on the live site (fastest — no downloads) ==
1. Go to  https://mmn.rocks/stemmaxxer-add.html  and enter your passkey
   (the same one the Workbench Deploy uses; stored in wp-content/stemmaxxer-key.php).
2. Type the band and song, then drag your Logic AIFF/WAV exports onto the page.
   The instrument for each stem is read from Logic's track name automatically.
3. Click "Convert & add to STEMMAXXER." Each stem is converted to MP3 in your
   browser and filed straight into the Media library. The song appears in the
   mixer immediately. Re-adding the same band+song replaces its old stems.

== Changelog ==
= 2.0.0-beta.11 =
* Lock screen: when a song is playing and the phone locks or shows the Now-Playing
  widget, the artwork is now the STEMMAXXER album cover (was the low-res site icon),
  with the song's title and artist. The widget's play/pause, skip, and scrub controls
  are wired to the player. iOS + Android (Media Session API).
= 2.0.0-beta.10 =
* Mobile: added Restart (jump to start and keep playing) and Reset (stop, clear
  mute/solo/feature, faders to default, clear loop) buttons to the transport, matching
  the desktop.
= 2.0.0-beta.9 =
* Mobile: track names are left-justified; and a LOADING screen now blocks playback until
  a newly-selected song is fully loaded (fixes stems playing out of sync if you hit play
  right after switching songs).
* Desktop: track names (DRUMS, GUITAR…) are now the same size as the channel numbers.
* Desktop: new Workbench "Fader width" control widens the LED/slider track and handle;
  deployable to the band like the other fader-look settings.
= 2.0.0-beta.8 =
* Mobile view now shows the version number next to the STEMMAXXER LITE logo.
= 2.0.0-beta.7 =
* Mobile track header redesigned: the +/− focus control and the M/S buttons are now
  full-height edge tabs fused to the strip frame (no nested squares), with the track
  name centered between them. Whatever's active tints the whole frame — focus (orange)
  wins, else solo (yellow), else mute; a focused strip keeps its orange frame and shows
  solo/mute as a detached inset pill. Off-state M/S now carry a subtle color wash.
* Mute is now BLUE instead of red — everywhere, desktop mixer included.
= 2.0.0-beta.6 =
* The Workbench "Fader Style" setting (LED Ladder vs Solid Fill) now also drives the
  mobile view — deploy Solid Fill and the mobile faders match, using the same zone
  colors and thresholds as the desktop mixer.
= 2.0.0-beta.5 =
* More reliable song loading (helps the intermittent "not every stem loaded" glitch,
  especially on mobile/Firefox): each stem now retries a few times with a short backoff
  instead of giving up on the first hiccup, and stems load a few at a time rather than
  all at once. On mobile, a stem that still fails shows a "FILE ERROR — RETRY" button so
  you can reload just that part without refreshing the whole page.
= 2.0.0-beta.4 =
* LITE mobile: double-tap the speed % to snap back to 100%; the loop A/B/⟳/✕ controls
  are now one centered cluster under the playback bar; the playback bar gets the same
  timeline tick markers as desktop; and the volume handle can no longer slip behind the
  mute/solo buttons at full level.
* Desktop: the "Learn" button is now "RTFM" with a field-manual icon.
= 2.0.0-beta.3 =
* LITE mobile A/B section looping: tap A to set the loop start at the playhead, B for
  the end — a shaded region with draggable A/B flags appears on the playback bar, and
  the ⟳ LOOP button repeats just that section (no A/B = whole song). ✕ clears it. The
  loop controls sit right under the playback bar.
= 2.0.0-beta.2 =
* LITE mobile refinements: every channel now shows a visible orange + button (tap to
  FOCUS that part; it flips to −). Speed is now [ − ] SPEED nn% [ + ] — minus slows,
  plus speeds up, and + greys out at 100%. Channels renumber so Drums = 1 (Count In
  is a chip, not a strip). New chunky slider handle with a dark outline + orange
  center line that stays visible over any LED color, and the meter never rises past
  the handle. (Desktop Count-In-to-transport + split fader are the next update.)
= 2.0.0-beta.1 =
* NEW — STEMMAXXER LITE (beta): a mobile mixer for phones. On screens under 900px the
  new CONSOLE view replaces the "open on desktop" screen with big touch faders,
  mute/solo, tap-a-stem-name to FOCUS it (that part up, the rest ducked), a loop
  toggle, speed, and count-in/click chips — all driving the same engine as the
  desktop mixer. Gated behind the "Mobile view (LITE)" preview feature: turn on
  device preview (or add ?lite=1 to the URL on your phone) to try it, then Publish
  to the band when you are happy. PADS view + skin picker are next. Starts the 2.0 line.
= 1.14.35 =
* The mobile "Optimized for desktop" screen now offers a "Use it here anyway"
  button, so you can open the full mixer on a phone when you need to (for example
  to test on an iPhone). Your choice is remembered on that device. The dedicated
  mobile view (STEMMAXXER LITE) is coming in v2.0.
= 1.14.34 =
* iPhone fix: the mixer now plays even when the phone is in Silent Mode. iOS used
  to mute this kind of multi-track audio whenever the ring/silent switch was on
  (ordinary videos were unaffected). The player now declares itself as media
  playback (Audio Session API) and keeps a silent loop running as a fallback,
  both starting on your first tap. No more "flip the switch" workflow note.
= 1.14.33 =
* Fix: in Settings → STEMMAXXER, clicking "+ Add resource" produced a resource-type
  dropdown with no options in it. New rows now show the full type list (Tab / Chart,
  Chords, Video lesson, Audio ref, Other link) like the existing rows.
= 1.14.32 =
* NEW "Changelog" tab in the Workbench (Shift+W) — a high-level summary of every
  STEMMAXXER update, newest first, with the current build highlighted.
= 1.14.31 =
* Footer tidy: the tagline and the "Report a bug / Request a feature" links now sit
  together on one line under the version number, instead of on two separate lines.
= 1.14.30 =
* Bandmates can now EDIT resources from the mixer, not just add/remove. Any resource a
  bandmate added via the mixer shows a pencil — click it to change the label, description,
  link, or type inline. Links you added in Settings → STEMMAXXER stay locked to you (no
  pencil for bandmates); you can still edit everything from Settings.
= 1.14.29 =
* NEW "Report a bug" and "Request a feature" links in the footer — bandmates click one,
  write a short note (and optionally their email so you can reply), and it's emailed
  straight to you (chris@kitemath.com). The message comes from STEMMAXXER, with the
  reporter's address as Reply-To, and includes which song they were on for context.
= 1.14.28 =
* Fix: while adding a resource with the banner song-selector active, you couldn't type in
  the Label or Description fields — the first letter jumped to the song list (typeahead)
  instead. The song-picker's keyboard handling now ignores keystrokes coming from the
  Resources form fields, so you can type normally.
= 1.14.27 =
* The small footer line under the mixer is easier to read: it's now a two-line stack —
  "STEMMAXXER" (in the accent color) and the version on top, the "Multi-Stem Practice
  Mixer · Private band practice tool" tagline on a brighter, less-spaced-out line below —
  instead of one cramped, dim, wide-tracked all-caps line.
= 1.14.26 =
* NEW optional description under each resource link — a short note shown as a subtitle
  beneath the link, so several links of the same kind are easy to tell apart (e.g. three
  video lessons: "note-for-note from Mr. Tabs", "the second guitar part", "drum lesson").
  There's a Description field in both the band "+ Add" form and your admin editor
  (Settings → STEMMAXXER); it's optional — links without one look exactly as before.
= 1.14.25 =
* Resources dropdown is easier to read and clearly separated from the mixer: the open
  list is now wider, sits on a lighter panel with an orange frame + soft glow, and dims
  the mixer behind it (a backdrop scrim) while it's open. Click the dimmed area to close.
* NEW Workbench "Resources panel" controls to tune all of that: panel width, panel
  background color, frame & glow color, glow strength, and background-dim amount. They
  deploy to the band like the other Workbench settings.
= 1.14.24 =
* Fix: when a bandmate adds a resource from the mixer, the Add form now shows all
  three fields — link, label, and TYPE — each on its own line. They were collapsing
  onto one line (the label and type box slid off to the side) after Resources moved
  into the banner, so bandmates could only see the link box and every add was silently
  filed as "Tab / Chart." Bandmates can now label the resource type themselves, just
  like you can in Settings → STEMMAXXER.
* The type picker now defaults to "auto-detect from link" — leave it and the type is
  guessed from the URL (YouTube→Video, Songsterr→Tab, Ultimate-Guitar→Chords, …), or
  pick a specific type to override.
= 1.14.23 =
* Reworked how the Resources dropdown sits next to the song banner so the two no
  longer read as a confusing "dropdown inside a dropdown." The song-selector banner
  and the Resources panel are now two flush segments of one bar: the selector is
  rounded on the left and squared on the right, Resources is squared on the left and
  rounded on the right, and both are the exact same height. Each half keeps its own
  arrow, so it's clear which opens the song list and which opens the links. The
  Resources dropdown opens anchored to its right edge and stays on screen.
= 1.14.22 =
* MOVED the per-song "Resources" dropdown UP into the song banner — it now sits as
  its own bordered box just to the right of the song title (where the EQ animation
  used to be), instead of down in the transport where it was crowding the A/B loop
  buttons. It's a clearly separate dropdown but stays tied to the currently selected
  song; clicking it never opens the song picker. The master volume slider expands to
  fill the space it left behind. Banner-selector mode: title keeps its width, the
  Resources box follows it, and the song-picker caret moves to the far right.

= 1.14.21 =
* NEW per-song "Resources" (beta feature) — each song can now carry as many labeled
  links as you like (tabs, chords, guitar/drum video lessons, a reference mix). In
  the mixer transport they collapse into one "Resources ▾" button (a single link
  shows as one direct button); each row carries a type icon and opens in a new tab.
* Bandmates can add their own finds: once they've entered the access password, a
  "+ Add a resource" form appears in the Resources list. Adds go live immediately
  and stay anonymous. The browser that added an item can remove it (an ✕ appears on
  its own adds); you can remove anyone's from Settings → STEMMAXXER.
* Manage the full list per song in Settings → STEMMAXXER — pick a type, label, and
  URL; add up to 20 per song; band-added items are tagged "band" and you can edit or
  remove any of them. Type auto-detects from the URL (YouTube→Video, Songsterr→Tab,
  Ultimate-Guitar→Chords). Your existing Chart / Lesson links migrate in as the first
  resources automatically, so nothing already set is lost.
* Ships as a Workbench beta feature ("Per-song resources") — preview it on your
  device, then Publish to the band when you're happy.
= 1.14.20 =
* The whole Workbench (Shift+W) is now behind your deploy passkey — enter it once
  and it's remembered on that device, so bandmates can't open the panel (or see
  the Traffic tab). If no deploy passkey is set on the server, the panel stays
  open as before. The redundant per-section passkey boxes inside are gone now
  that the whole panel is gated.
= 1.14.19 =
* NEW Workbench "Traffic" tab — a light per-day hit counter for the player page so
  you can tell if the private link has spread beyond the band. Shows today /
  yesterday / 7-day / 30-day totals, a 30-day bar chart, and a status line that
  flags an unusual spike (with a nudge to change the band password). Bots are
  skipped; it's a rough counter, not analytics.
= 1.14.18 =
* Song titles now keep punctuation the file name can't hold — parentheses,
  apostrophes, ampersands, etc. When you add a song via the on-site Add page
  (New song mode), the exact title you type (e.g. "Street Spirit (Fade Out)")
  is saved as the display name and shown in the banner + song dropdown. (Songs
  already in the library keep their current name until you re-add them or edit
  the title under Settings → STEMMAXXER.)
= 1.14.17 =
* New Reset button icon: the transport Reset button now shows a mixer-faders
  glyph (knobs snapped to a default line) instead of the old square, so it reads
  as "reset the mix to default" rather than "stop" — and stays clearly distinct
  from the Restart loop next to it.
= 1.14.16 =
* Publishing a beta feature to the band is now one-way and permanent: once
  published, the feature is "baked in" and drops off the Workbench Beta list (no
  more "Hide from band" toggle). Published features show only as a read-only
  "baked in & live" note. Vet each feature in Preview first, since it can't be
  un-published from the Workbench.
= 1.14.15 =
* The A and B loop flags on the playback bar can now be DRAGGED left/right to move
  the loop points — grab a flag and slide it. Works whether or not the loop is on,
  and even before you've set the other point. A can't cross past B (and vice versa).
= 1.14.14 =
* NEW Workbench control (Fader Look → "A/B marker color") to recolor the A/B loop
  flags and the shaded loop region on the playback bar, independent of the accent.
* Fix: Deploy now correctly publishes the playback-bar handle colors/width (and
  the new A/B marker color) to the band — they were previously dropped on deploy.
= 1.14.13 =
* NEW "Add stem to existing song" on the on-site Add page (/stemmaxxer-add.html).
  Toggle to that mode, pick a song already in the library, and drop in just the
  missing stem(s) — e.g. a Click track for an older song that never had one. Only
  the new stems are filed; the song's existing stems are untouched. Works for both
  newer (Band__Song__Instrument) and older (SongNN-MM-StemName) songs, and shows
  which channels the song already has vs. what you can still add.
= 1.14.12 =
* The playback bar now shows a subtle timeline ruler (faint baseline + tick
  marks) even before a song plays, so the empty bar reads as a seek timeline
  instead of blank space. The amber fill grows over it; upcoming ticks stay
  visible past the playhead.
= 1.14.11 =
* Workbench cleanup: removed the EQ visualization's controls (Song Banner →
  "Gap after title" and "Pattern height") now that the banner selector retires
  the animated EQ. The banner's Left/Right inset controls remain.
= 1.14.10 =
* A/B section looping is now a PERMANENT feature (graduated out of beta): the
  A/B/loop/clear controls and their keys ([ ] L Shift+L) are on for everyone, all
  the time. No more publishing it, and it survives every future update.
* Published beta features now PERSIST across plugin updates — a "Publish to band"
  finally sticks instead of being hidden again on the next build. (Fully-vetted
  features get made permanent like A/B looping above; anything still in beta stays
  exactly as you left it — published or not — through updates.)
* Band/song banner selector (beta) refined: the animated EQ is removed and the
  title fills the width; the whole banner is now a subtle orange-lined field with
  an orange dropdown-arrow button, so it clearly reads as selectable.
= 1.14.9 =
* NEW beta feature "Band/song banner selector." The big BAND — TITLE banner
  doubles as the song picker: click it (or focus + Enter, and type to jump).
  It's a light, display-scale trigger with a chevron chip — not a big orange
  button — and the EQ animation stays to its right. When on, the transport's own
  dropdown is removed and the master volume stretches to fill that space.
  (Beta — preview it on your device, publish to the band when you like it.)
* A/B looping gains a clear button (the X in the loop group) that removes the A
  and B flags and turns the loop off. Keyboard: Shift+L.
= 1.14.8 =
* NEW Workbench controls for the playback-bar handle (under Fader Look): pick its
  background color, its hamburger-line color, and its width. Widening the handle
  grows it to the LEFT — its right edge stays pinned to the current playback
  position, so a wider handle never sits ahead of where the song actually is.
= 1.14.7 =
* Playback-bar drag handle restyled: flat, with three horizontal hamburger lines,
  and kept fully inside the bar so it no longer pokes above or below the bar edge.
= 1.14.6 =
* A/B looping now drops an "A" flag onto the playback bar the instant you set the
  start point (and a "B" flag for the end) — so you can see where the loop start
  landed even before you've set B or switched the loop on.
* The playback bar is now taller by default (30px) for an easier click/drag
  target. (Still adjustable in the Workbench under Fader Look → playback bar.)
* Beta / Preview is now PER-FEATURE. Each pipeline feature has its own
  "Publish to band" button, so you can push one finished feature live while
  another stays in preview — no more all-or-nothing. Each shows its own status
  (Not published / Preview only / Live for band). Plugin updates still hide
  everything until you re-publish.
= 1.14.5 =
* The Workbench "Beta / Preview" section now lists exactly which unpublished
  features are in the pipeline, with a status line showing whether they're
  preview-only on this device or already published to the band. It's the
  reminder of "what's not live yet" so nothing gets forgotten.
= 1.14.4 =
* The "Learn" (teacher mode) button is now right-justified to the mixer's right
  edge, with the same margin as the legend's left edge and clear separation from
  the keyboard-shortcut legend.
= 1.14.3 =
* The channel "+" feature buttons are now accent orange (matching the play
  button and song selector). The featured channel's button glows brighter and
  shows "−" so it's still easy to tell which part is spotlighted.
= 1.14.2 =
* Fix: the Workbench "Preview / Publish new features" buttons now have their own
  passkey box right there, so they work on their own (before, they silently
  needed a passkey entered elsewhere first and looked like they did nothing).
= 1.14.1 =
* Song selector no longer squashed: the button shows the full band + title, and
  the open list is a comfortable fixed width so long song names stay on one line.
  (Master slider trimmed slightly to make room; the transport still fits one row.)
= 1.14.0 =
* NEW Charts / Lesson links per song. Add a tab/chart URL and/or a video-lesson
  URL under Settings → STEMMAXXER; "Charts" and "Lesson" buttons then appear on
  that song in the mixer (open in a new tab). Songs without links show nothing.
* NEW A/B section looping (beta). Set a loop start (A) and end (B) and repeat
  that section on a loop — great for drilling a tricky part, and it works with
  the slow-down speed. Drag the shaded region's edges on the playback bar to
  fine-tune; with no A/B set it loops the whole song. Keyboard: [ = A, ] = B,
  L = loop on/off.
* NEW beta / preview channel. New features stay hidden from the band until you
  publish them. In the Workbench: "Preview new features on this device" (unlocks
  with your passkey, your browser only) lets you vet them with the real app;
  "Publish new features to the band" makes them live for everyone. Every plugin
  update starts hidden again, so nothing reaches the band before you approve it.
  (A/B looping ships as the first beta feature; Charts/Lesson links are live.)
= 1.13.0 =
* Layout: each channel's feature "+" button now lives in that channel's header,
  right-justified next to the number and name (kept compact so the header always
  stays on one line). The separate FEATURE bar is gone; the SPEED control and the
  BPM readout moved up into the transport row alongside the song selector, master
  volume, and time.
= 1.12.0 =
* NEW "Click" channel for click / metronome tracks. A stem whose name contains
  "click" becomes the Click channel, which sits between Count In and Drums
  (channel 2). As with every part, a song shows it only if that stem exists.
  The converters recognise "click" (and "metronome") automatically.
= 1.11.2 =
* Teacher mode: the explanation now pops up right next to the control you're
  hovering (instead of a fixed corner panel), and is positioned so it never
  covers the control it's describing — it flips to whichever side has room.
= 1.11.1 =
* No more "Save Permalinks" step. The plugin now (a) re-flushes its URL rules
  automatically the first time it loads after any version change, and (b)
  resolves /stemmaxxer.html and /stemmaxxer-add.html straight from the request
  path as a fallback — so both addresses work immediately on install and after
  every update, with no manual step.
= 1.11.0 =
* NEW "Teacher mode" (a graduation-cap "Learn" button at the far right of the
  keyboard legend). Toggle it on and hover any control — play, restart, skips,
  song selector, master, speed, BPM, the feature +/- buttons, and each channel's
  mute/solo/fader — to see a plain-English explanation in a side panel, with the
  hovered control highlighted. Click the cap again (or press Esc) to turn it off.
= 1.10.2 =
* The Workbench "+ Add a Song" control now takes your passkey right there and
  checks it on the spot (a wrong key is caught immediately, with a reminder that
  it's the Deploy passkey, not the band login password). On success the uploader
  opens already unlocked, so you don't enter the passkey again before "Convert
  & add." New lightweight smx_check_key endpoint (same key + lockout as Deploy).
= 1.10.1 =
* Workbench now has a "+ Add a Song" link (under a new Library heading) that
  opens the on-site uploader (/stemmaxxer-add.html) in a new tab.
= 1.10.0 =
* NEW on-site "Add a Song" page at /stemmaxxer-add.html — passkey-gated (no
  WordPress login). Drag in Logic AIFF/WAV exports, they're converted to MP3 in
  the browser and filed straight into the Media library with the correct
  Band__Song__Instrument names. The song appears in the mixer instantly; no
  download, no Media upload, no renaming. Re-adding a song replaces its stems.
  Uses the same passkey + per-IP lockout as Deploy; server validates file name,
  MP3 signature, and size before writing. (The standalone converter still ships
  too, for offline use.)
= 1.9.0 =
* NEW naming scheme: Band__Song__Instrument (no track numbering). Stems are
  grouped into a song by their Band__Song, and each stem is assigned to its
  instrument channel by the name at the end of the file — the mixer's channel
  order (Count In · Click · Drums · Guitar · Bass · Piano · Vocals · Other) is fixed.
* Song selector is now sorted alphabetically by band, then title.
* Band/title for new-scheme songs are read from the file name automatically
  (editable/overridable under Settings → STEMMAXXER).
* Legacy SongNN-MM-StemName files still supported side-by-side, so existing
  songs are untouched and blend seamlessly into the same alphabetical list.
* Companion tool: STEMMAXXER Stem Converter (offline browser page) turns Logic
  AIFF/WAV exports into correctly-named MP3 stems.
* .mp4 added to the recognized audio extensions.
= 1.8.7 =
* Keyboard legend now always stays on one line (tighter chips/separators,
  gentle size step-down on narrower windows).
= 1.8.6 =
* "Multi-Stem Practice Mixer" moved to the footer line between the version
  and "Private band practice tool", styled to match the FEATURE label.
* Keyboard legend at the bottom of the mixer enlarged for readability.
= 1.8.5 =
* Removed the loaded-status indicator from the transport; the song
  selector and master volume slider grew into the freed space.
= 1.8.4 =
* Current build number now shown large at the top of the Workbench.
= 1.8.3 =
* Song selector dropdown enlarged (up to ~560px / 14+ songs visible) with
  an always-visible themed scrollbar when the list overflows.
= 1.8.2 =
* Playback bar now has a chrome drag grip (three vertical lines) riding
  the leading edge, and supports true drag-to-scrub (visual follows the
  pointer; seek lands on release). Click-to-jump still works.
= 1.8.1 =
* Removed the automatic "REBUILD AUDIO" pop-up banner. The rebuild button
  remains in the (hidden) Workbench, and a silent auto-resume still runs
  in the background. Band members see nothing.
= 1.8.0 =
* Novascope-style deploy: the DEPLOY button is always visible and asks for
  a passkey instead of requiring a WordPress login. The passkey lives in
  wp-content/stemmaxxer-key.php (created on activation with CHANGE-ME --
  edit it to your secret; plugin updates never touch it). Wrong-key
  lockout: 5 attempts per IP, 10-minute cooldown. The key is remembered
  for the browser session after a successful deploy.
= 1.7.0 =
* The banner pattern is now a LIVE EQ VISUALIZATION of the playing mix:
  LED-style spectrum bars colored with the fader zone gradient, driven by
  a master analyser. In slowed mode the bars ride a precomputed energy
  envelope of the rendered mix. Banner sliders (insets/gap/height) shape
  the EQ strip.
= 1.6.4 =
* Workbench "Song Banner" section: sliders for left inset, right inset,
  gap after the title, and pattern bar height. All deployable.
= 1.6.3 =
* Song banner is left-aligned with the play button; a subtle diagonal
  grille pattern fills the space after the title (50px gap) out to the
  mixer's right edge with matching margins.
= 1.6.2 =
* Song banner is now one horizontal line: BAND (accent color) + TITLE
  (softened metallic gradient), same size.
* "Multi-Stem Practice Mixer" tag moved from under the logo to the left
  of the keyboard legend at the bottom of the mixer.
= 1.6.1 =
* The loaded song is now displayed between the logo and the mixer as a
  large brushed-metal title (Big Shoulders Display, matching the logo)
  with the artist above it in the accent color.
= 1.6.0 =
* Song selector now matches the play button (accent color) and follows the
  Workbench accent setting / live deploys.
* MASTER VOLUME slider in the transport (persists per browser tab session).
  Wired as a true master bus: stem meters stay pre-master, and it works
  live in slowed-speed mode too.
= 1.5.1 =
* Workbench is now fully unadvertised: Shift+W removed from the keyboard
  legend and the footer. Only people who know the combo can find it.
= 1.5.0 =
* Larger +/- signs on the feature buttons.
* DEPLOY SETTINGS LIVE: new Workbench button (visible only when you're
  logged into WordPress admin in the same browser) that publishes your
  current workbench settings as the site-wide defaults for the whole band.
  Server-side: admin capability + nonce checked, values sanitized.
  "Reset to live defaults" now returns a browser to the deployed settings.
= 1.4.0 =
* Playback bar doubled to 22px, with Workbench controls for its height
  (6-40px) and color (picker + swatches).
* SILENCE WATCHDOG: if playback goes silent (macOS sleep/wake or output-
  device change can stall Chrome audio), a "REBUILD AUDIO" banner appears
  automatically -- one click rebuilds the audio engine and resumes in place.
  Triggers: audio device change, stalled context, or 6s of pure silence
  while tracks are audible. Manual button also in the Workbench.
= 1.3.0 =
* PLAYBACK SPEED (pitch-preserved): SPEED dropdown right of the feature
  buttons (100/90/80/75/70/60/50%). Below 100% the current mix is rendered
  to a single stream and played through the browser's native time-stretcher
  (like YouTube) so pitch stays put and stems can never drift. Mixer changes
  while slowed rebuild the mix automatically (~1-3s). Live LED meters pause
  in slowed mode (no per-stem signal) and show fader positions instead.
* BPM METER: tempo is auto-detected from the drums stem after load and shown
  next to the speed control. When slowed, shows effective tempo too
  (e.g. "124 -> 93"). Set an exact BPM per song in Settings -> STEMMAXXER
  to override detection.
= 1.2.1 =
* Workbench edge tab removed — the panel is fully hidden until Shift+W.
* NEW Workbench control: Meter range (24-72 dB) — how hot/calm the live
  LED meters respond.
= 1.2.0 =
* LIVE LED METERS: while a song plays, each fader's LED ladder now follows the
  track's actual audio signal (post-fader RMS, -48..0 dB scale) with real
  meter ballistics (fast attack, slow release) and a peak-hold marker.
  When stopped, LEDs settle back to the fader position. Workbench has
  LIVE/STATIC and peak-hold toggles.
* Feature "+" buttons are now generated for EVERY stem in the current song
  (VOCALS+, PIANO+, OTHER+, ...). Count In is excluded. Keyboard shortcuts
  auto-assign from each stem's first letter (D/G/B/V/P/O...).
= 1.1.0 =
* Logo now spans the full mixer width (size adjustable in the Workbench).
* NEW: Workbench panel (press Shift+W, or the WORKBENCH tab on the left edge):
  default fader level, featured/ducked levels for the +/- buttons, LED or solid
  fader style, LED segment size, color zone boundaries, accent color, logo width.
  Settings persist per browser.
* Faders now default to 90% (adjustable), leaving headroom to push to 100%.
* Fader fill is now an LED-ladder meter (green/yellow/orange/red by position);
  solid-fill mode still available in the Workbench.
* Feature "-" buttons now restore ALL faders to the default level.
* Buttons release keyboard focus after clicking, so Space (play/pause) can no
  longer invisibly re-trigger the last-clicked button.
= 1.0.0 =
* Initial release.
