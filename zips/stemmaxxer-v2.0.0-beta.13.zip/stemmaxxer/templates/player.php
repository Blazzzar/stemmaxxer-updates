<?php
if (!defined('ABSPATH')) exit;
/* Provided by smx_render_player_page():
 * @var string $smx_songs_json  JSON array of songs [{slug, artist, title, stems:[{name,url}]}]
 * @var string $smx_logo_url    Logo image URL ('' = text wordmark)
 * @var string $smx_version     Plugin version
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>STEMMAXXER</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&family=JetBrains+Mono:wght@400;500;700&family=Big+Shoulders+Display:wght@600;700;800&display=swap" rel="stylesheet">
<style>
  :root{
    --bg:#141416; --panel:#202027; --panel2:#282830; --groove:#141418;
    --line:#3b3b45; --line2:#50505c;
    --text:#e9e9ec; --dim:#8b8b95; --dimmer:#63636d;
    --orange:#ef7d1c;
    --green:#37b24d; --yellow:#f2c517; --zorange:#f0801c; --red:#e6402a;
    --mute:#2f7fe6; --solo:#f2c517; --amber:#f5c518;   /* mute = blue */
    /* Workbench-driven vars */
    --z1:25%; --z2:50%; --z3:75%;   /* fader color zone boundaries */
    --seg:9px;                       /* LED segment pitch */
    --fader-w:30px;                  /* fader / LED track width */
    --logo-w:100%;                   /* logo width relative to mixer width */
    --ns-l:18px; --ns-r:18px;        /* banner left/right insets */
    --ns-gap:50px;                   /* gap between title and pattern */
    --ns-h:34px;                     /* pattern bar height */
  }
  *{box-sizing:border-box;}
  html,body{margin:0;padding:0;}
  body{
    background:radial-gradient(1200px 600px at 50% -10%, #1c1c20 0%, var(--bg) 60%);
    color:var(--text);
    font-family:'Bricolage Grotesque',system-ui,sans-serif;
    min-height:100vh;display:flex;flex-direction:column;align-items:center;
    padding:26px 18px 40px;
    transition:padding-left .22s ease;
  }
  body.wb-open{padding-left:352px;} /* keep the whole player reachable while the workbench is open */
  button{font-family:inherit;}

  /* ---------- Wordmark / logo ---------- */
  .brand{width:100%;max-width:1180px;display:flex;flex-direction:column;align-items:center;}
  .wordmark{
    font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:clamp(40px,7vw,86px);
    letter-spacing:.06em;margin:0 0 4px;color:#c9c9cf;line-height:1;
    text-shadow:0 1px 0 #000, 0 2px 4px rgba(0,0,0,.6);user-select:none;
  }
  .wordmark .xx{color:var(--orange);}
  .wordmark-img{width:var(--logo-w);max-width:100%;height:auto;display:block;margin:0 0 6px;user-select:none;}
  .subtag{
    font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.28em;
    color:var(--dimmer);text-transform:uppercase;margin:2px 0 14px;text-align:center;
  }

  /* ---------- Now-loaded song banner: BAND — TITLE, left-aligned to the play button,
     with a subtle grille pattern filling the rest of the mixer width ---------- */
  .nowsong{
    width:100%;max-width:1180px;display:flex;flex-direction:row;align-items:center;
    margin:4px 0 16px;
    padding:0 var(--ns-r) 0 var(--ns-l); /* default 18px = mixer border + transport padding (play-button inset) */
    white-space:nowrap;overflow:hidden;
    font-size:clamp(32px,5vw,60px);
  }
  /* Wraps title + caret + EQ — the song-selector field (border added in bannersel mode). */
  .ns-selfield{display:flex;align-items:center;flex:1 1 auto;min-width:0;overflow:hidden;}
  .ns-text{display:flex;align-items:baseline;gap:22px;flex:0 1 auto;overflow:hidden;}
  .ns-artist,.ns-title{
    font-family:'Big Shoulders Display',sans-serif;font-weight:800;
    font-size:inherit;line-height:1;letter-spacing:.045em;text-transform:uppercase;
    overflow:hidden;text-overflow:ellipsis;
  }
  .ns-artist{
    color:var(--orange);
    text-shadow:0 2px 3px rgba(0,0,0,.55);
  }
  .ns-title{
    background:linear-gradient(180deg,#e9e9ec 0%,#cfcfd5 38%,#aeaeb8 52%,#d9d9de 66%,#b8b8c2 100%);
    -webkit-background-clip:text;background-clip:text;color:transparent;
    filter:drop-shadow(0 2px 2px rgba(0,0,0,.55));
  }
  .ns-fill{
    flex:1 1 auto;min-width:36px;height:var(--ns-h);align-self:center;
    margin-left:var(--ns-gap);
    position:relative;
    border-top:1px solid var(--line);
    border-bottom:1px solid var(--line);
  }
  .ns-fill canvas{position:absolute;inset:0;width:100%;height:100%;display:block;}

  .stemmaxxer{
    width:100%;max-width:1180px;border:2px solid var(--line2);border-radius:12px;
    background:var(--panel);overflow:hidden;position:relative;
    box-shadow:0 24px 60px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.03);
  }

  /* ---------- Transport ---------- */
  .transport{
    position:relative;display:flex;align-items:center;gap:18px;
    padding:14px 16px calc(var(--scrub-h,30px) + 12px);
    background:linear-gradient(180deg,#26262d,#1e1e24);
    border-bottom:2px solid var(--line);
  }
  .tp-left{display:flex;align-items:center;gap:8px;}
  .tbtn{
    width:46px;height:40px;border-radius:8px;
    background:linear-gradient(180deg,#33333c,#26262d);
    border:1px solid var(--line2);color:var(--text);
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;position:relative;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.05), 0 2px 3px rgba(0,0,0,.4);
    transition:background .12s,border-color .12s,transform .05s;
  }
  .tbtn:hover{border-color:var(--orange);}
  .tbtn:active{transform:translateY(1px);}
  .tbtn.play{
    width:54px;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border-color:color-mix(in srgb, var(--orange), white 28%);color:#160d02;
  }
  .tbtn.play:hover{border-color:#fff;}
  .tbtn svg{display:block;}
  .tbtn .lbl10{position:absolute;bottom:2px;right:4px;font-family:'JetBrains Mono',monospace;font-size:8px;color:var(--dim);}
  .tbtn.play .lbl10{color:#160d02;}

  .tp-mid{flex:1 1 240px;min-width:170px;position:relative;}
  .dropdown{position:relative;width:100%;}
  .dd-button{
    width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;
    padding:9px 14px;border-radius:8px;cursor:pointer;text-align:left;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border:1px solid color-mix(in srgb, var(--orange), white 28%);
    color:#160d02;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.25), 0 2px 4px rgba(0,0,0,.4);
  }
  .dd-button:hover,.dd-button:focus{outline:none;border-color:#fff;}
  .dd-button .dd-song{font-weight:700;font-size:15px;letter-spacing:.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#160d02;}
  .dd-button .dd-song .art{color:rgba(22,13,2,.6);font-weight:600;}
  .dd-caret{color:#160d02;flex:0 0 auto;transition:transform .15s;}
  .dropdown.open .dd-caret{transform:rotate(180deg);}
  .dd-list{
    position:absolute;top:calc(100% + 6px);left:0;right:auto;z-index:40;
    min-width:min(440px, 90vw); /* open list stays comfortably wide even if the button is narrow */
    background:#1b1b21;border:1px solid var(--line2);border-radius:8px;
    box-shadow:0 18px 40px rgba(0,0,0,.6);padding:5px 20px 5px 5px;display:none;
  }
  .dd-item .art{white-space:nowrap;}
  .dd-scroll{max-height:min(548px, 60vh);overflow-y:auto;scrollbar-width:none;}
  .dd-scroll::-webkit-scrollbar{display:none;}
  /* Custom always-visible scrollbar — renders the same in every browser,
     so songs below the fold are never invisible */
  .dd-sb{position:absolute;top:6px;bottom:6px;right:5px;width:10px;background:#101014;border-radius:5px;}
  .dd-sb.hide{display:none;}
  .dd-sb-thumb{
    position:absolute;left:1px;right:1px;top:0;height:40px;border-radius:4px;cursor:grab;
    background:linear-gradient(180deg,#8f8f9c,#5f5f6b);
    box-shadow:inset 0 1px 0 rgba(255,255,255,.3), 0 1px 2px rgba(0,0,0,.5);
  }
  .dd-sb-thumb:hover,.dd-sb-thumb.drag{background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 15%), var(--orange));cursor:grabbing;}
  .dropdown.open .dd-list{display:block;}
  .dd-item{padding:8px 11px;border-radius:6px;cursor:pointer;font-size:14px;display:flex;gap:8px;align-items:baseline;}
  .dd-item .num{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--dimmer);width:22px;flex:0 0 auto;}
  .dd-item .art{color:var(--dim);font-weight:500;}
  .dd-item:hover,.dd-item.hl{background:#2a2a32;}
  .dd-item.sel{background:color-mix(in srgb, var(--orange) 14%, transparent);box-shadow:inset 0 0 0 1px color-mix(in srgb, var(--orange) 40%, transparent);}

  /* ---------- Banner-integrated song selector (beta 'bannersel') ----------
     The big BAND — TITLE banner doubles as the song dropdown. When active, the
     EQ animation is removed, the title fills the whole width, and the whole
     banner reads as a selectable field: a subtle orange-lined box with an
     orange dropdown-arrow button on the right. The transport's own selector is
     removed and the master volume stretches to fill the void. The banner sits
     OUTSIDE .stemmaxxer, so it is gated by a body-level class
     (body.smx-bannersel); the transport bits (inside #app) gate on
     .stemmaxxer.show-bannersel. */
  .ns-caret{display:none;flex:0 0 auto;align-self:center;margin-left:16px;
    width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;
    color:var(--dim);border:1px solid var(--line2);background:rgba(255,255,255,.03);
    transition:transform .15s, color .15s, border-color .15s, background .15s;}
  .ns-caret svg{display:block;}
  body.smx-bannersel .ns-caret{display:inline-flex;
    color:var(--orange);
    border-color:color-mix(in srgb, var(--orange) 60%, transparent);
    background:color-mix(in srgb, var(--orange) 12%, transparent);}
  body.smx-bannersel .ns-fill{display:none;}          /* EQ removed in selector mode */
  body.smx-bannersel .ns-text{flex:1 1 auto;}          /* title fills the freed space */
  /* In banner-selector mode the FIELD (border/bg/hover) lives on .ns-selfield, not the
     whole .nowsong — so the Resources segment can sit OUTSIDE the field, butted against it.
     .nowsong is now just a transparent flex container. */
  body.smx-bannersel .nowsong{cursor:pointer;overflow:visible;position:relative;z-index:60;
    background:none;border:none;padding:0;}
  body.smx-bannersel .ns-selfield{cursor:pointer;
    padding:7px 14px;border:1px solid color-mix(in srgb, var(--orange) 42%, transparent);
    border-radius:10px;background:color-mix(in srgb, var(--orange) 4%, transparent);
    transition:background .15s, border-color .15s;outline:none;}
  body.smx-bannersel .ns-selfield:hover{border-color:var(--orange);
    background:color-mix(in srgb, var(--orange) 9%, transparent);}
  body.smx-bannersel .ns-selfield:hover .ns-caret,
  body.smx-bannersel #nowsong:focus-visible .ns-caret{border-color:var(--orange);
    background:color-mix(in srgb, var(--orange) 22%, transparent);}
  body.smx-bannersel #nowsong:focus-visible .ns-selfield{border-color:var(--orange);
    box-shadow:0 0 0 2px color-mix(in srgb, var(--orange) 40%, transparent);}
  body.smx-bannersel.dd-open .ns-selfield{border-color:var(--orange);}
  body.smx-bannersel.dd-open .ns-caret{transform:rotate(180deg);border-color:var(--orange);
    background:color-mix(in srgb, var(--orange) 26%, transparent);}
  body.smx-bannersel #ddList{left:0;}
  .dd-list.show{display:block;}
  /* Transport rebalance when the banner selector is active: drop the old
     selector, let the right cluster grow, and stretch the master to fill. */
  .stemmaxxer.show-bannersel .tp-mid{display:none;}
  .stemmaxxer.show-bannersel .tp-right{flex:1 1 auto;justify-content:flex-end;}
  .stemmaxxer.show-bannersel .master{flex:1 1 auto;}
  .stemmaxxer.show-bannersel .master input[type=range]{flex:1 1 auto;width:auto;min-width:160px;}

  /* ---- Per-song RESOURCES relocated INTO the banner (v1.14.22) ----
     #resWrap now lives inside .nowsong (outside .stemmaxxer), sitting right of
     the song title where the EQ animation used to be. Because it's outside
     .stemmaxxer, the injectFeatureCSS `.stemmaxxer:not(.show-resources)` rule
     can't reach it — so gate it on the body-mirrored class instead. */
  body:not(.smx-resources) #resWrap{display:none !important;}
  /* Let the banner show the dropdown (base .nowsong is overflow:hidden). */
  body.smx-resources .nowsong{overflow:visible;position:relative;}
  #resWrap{flex:0 0 auto;align-self:center;}
  body.smx-resources #resWrap .resbtn{padding:9px 15px;font-size:12px;
    border-color:color-mix(in srgb, var(--orange) 42%, transparent);
    background:color-mix(in srgb, var(--orange) 6%, transparent);}
  body.smx-resources #resWrap .resbtn:hover{border-color:var(--orange);
    background:color-mix(in srgb, var(--orange) 12%, transparent);}
  body.smx-resources #resWrap .slink{padding:9px 14px;font-size:12px;}
  /* Non-bannersel (resources published without the banner selector): standalone
     tinted pill sitting after the title with a clear gap. */
  body.smx-resources:not(.smx-bannersel) #resWrap{margin-left:20px;}

  /* BANNER-SELECTOR MODE — Resources is a SEGMENT butted against the selector field:
     SAME HEIGHT, squared on the LEFT (shared seam), rounded on the RIGHT. The selector
     field squares its RIGHT corners and drops its right border so the seam is one line. */
  body.smx-bannersel.smx-resources .ns-text{flex:0 1 auto;}   /* title natural; caret rides to the seam */
  body.smx-bannersel .ns-caret{margin-left:auto;}
  body.smx-bannersel.smx-resources .ns-selfield{
    border-top-right-radius:0;border-bottom-right-radius:0;border-right:none;}
  body.smx-bannersel.smx-resources #resWrap{align-self:stretch;margin-left:0;display:flex;}
  body.smx-bannersel.smx-resources #resWrap .resbtn,
  body.smx-bannersel.smx-resources #resWrap .slink{height:100%;
    border-top-left-radius:0;border-bottom-left-radius:0;
    border-top-right-radius:10px;border-bottom-right-radius:10px;
    border-left:1px solid color-mix(in srgb, var(--orange) 42%, transparent);}

  /* Beta/preview features are hidden until this browser previews them or they're published */
  .stemmaxxer:not(.beta-on) .beta{display:none !important;}
  /* A/B loop controls */
  .loopgrp{display:inline-flex;align-items:center;gap:4px;margin-left:6px;padding-left:8px;border-left:1px solid var(--line2);}
  .lpbtn{
    height:40px;min-width:32px;padding:0 8px;border-radius:8px;cursor:pointer;
    background:linear-gradient(180deg,#33333c,#26262d);border:1px solid var(--line2);color:var(--text);
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:13px;letter-spacing:.04em;
    display:inline-flex;align-items:center;justify-content:center;transition:all .12s;
  }
  .lpbtn:hover{border-color:var(--orange);}
  .lpbtn.set{border-color:var(--orange);color:var(--orange);}
  .lpbtn.loop svg{width:18px;height:18px;display:block;}
  .lpbtn.loop.on{
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border-color:color-mix(in srgb, var(--orange), white 28%);color:#160d02;box-shadow:0 0 12px color-mix(in srgb, var(--orange) 45%, transparent);
  }
  .loop-region{position:absolute;top:0;bottom:0;background:color-mix(in srgb, var(--loop-c, var(--orange)) 24%, transparent);
    border-left:2px solid var(--loop-c, var(--orange));border-right:2px solid var(--loop-c, var(--orange));z-index:2;pointer-events:none;}
  .loop-handle{position:absolute;top:0;bottom:0;width:12px;pointer-events:auto;cursor:ew-resize;}
  .loop-handle.a{left:-7px;} .loop-handle.b{right:-7px;}
  /* Standalone A / B position flags on the playback bar — shown the moment a point is set,
     even before the other point exists or the loop is switched on, so you can see where A landed.
     Color is Workbench-adjustable via --loop-c (falls back to the accent). */
  .loop-mark{position:absolute;top:0;bottom:0;width:2px;background:var(--loop-c, var(--orange));z-index:3;pointer-events:none;
    box-shadow:0 0 6px color-mix(in srgb, var(--loop-c, var(--orange)) 70%, transparent);}
  .loop-mark .lm-tag{position:absolute;top:0;
    font-family:'JetBrains Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.04em;
    color:#160d02;background:var(--loop-c, var(--orange));padding:1px 5px;line-height:1.35;
    pointer-events:auto;cursor:ew-resize;}
  .loop-mark.a .lm-tag{left:0;border-radius:0 5px 5px 0;}
  .loop-mark.b .lm-tag{right:0;border-radius:5px 0 0 5px;}
  /* Invisible wider grab strip so the thin flag is easy to drag left/right. */
  .loop-mark .lm-grab{position:absolute;top:0;bottom:0;left:-9px;width:20px;pointer-events:auto;cursor:ew-resize;}
  .loop-mark .lm-tag:hover,.loop-mark .lm-grab:hover ~ .lm-tag{filter:brightness(1.12);}
  .tp-right{display:flex;align-items:center;gap:12px;flex:0 1 auto;min-width:0;}
  .songlinks{display:flex;align-items:center;gap:8px;}
  .songlinks:empty{display:none;}
  .slink{
    display:inline-flex;align-items:center;gap:6px;text-decoration:none;cursor:pointer;
    padding:7px 12px;border-radius:7px;border:1px solid var(--line2);
    background:linear-gradient(180deg,#30303a,#25252c);color:var(--text);
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:11px;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;
    transition:all .12s;
  }
  .slink svg{flex:0 0 auto;color:var(--orange);}
  .slink:hover{border-color:var(--orange);}
  /* ---- Per-song resources (bf-resources beta): collapse many links into one
        "Resources ▾" button; a single link shows as one direct .slink. ---- */
  .stemmaxxer.show-resources #songLinks{display:none !important;} /* the new list supersedes the old chart/lesson buttons */
  .reswrap{position:relative;display:inline-flex;align-items:center;}
  .reswrap:empty{display:none;}
  .resbtn{display:inline-flex;align-items:center;gap:8px;cursor:pointer;padding:7px 12px;border-radius:7px;
    border:1px solid var(--line2);background:linear-gradient(180deg,#30303a,#25252c);color:var(--text);
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:11px;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;transition:all .12s;}
  .resbtn:hover{border-color:var(--orange);}
  .resbtn .r-ico{flex:0 0 auto;color:var(--orange);}
  .resbtn .cnt{color:var(--orange);}
  .resbtn .car{display:inline-flex;transition:transform .15s;}
  .reswrap.open .resbtn .car{transform:rotate(180deg);}
  /* Open Resources list: WIDER, a lighter surface, an orange frame + soft glow, and a
     background scrim that dims the mixer behind it. All Workbench-adjustable via the
     --res-* vars (width / bg / frame color / glow strength / scrim dim). */
  .reslist{position:absolute;top:calc(100% + 6px);right:0;z-index:60;display:none;
    width:var(--res-w,420px);max-width:calc(100vw - 32px);
    background:var(--res-bg,#2a2a34);
    border:1px solid var(--res-bd,var(--orange));
    border-radius:12px;padding:8px;white-space:normal; /* white-space reset: the banner sets nowrap,
      which had collapsed the Add-form inputs (url/label/type) onto one line */
    box-shadow:0 22px 54px rgba(0,0,0,.72),
               0 0 0 1px color-mix(in srgb, var(--res-bd,var(--orange)) 26%, transparent),
               0 10px 44px color-mix(in srgb, var(--res-bd,var(--orange)) var(--res-glow,55%), transparent);}
  /* Backdrop scrim — dims everything behind the open panel; the panel + its button stay lit. */
  #resScrim{position:fixed;inset:0;z-index:58;background:rgba(8,8,10,var(--res-scrim,.55));
    opacity:0;visibility:hidden;pointer-events:none;transition:opacity .16s ease, visibility .16s;}
  body.res-open #resScrim{opacity:1;visibility:visible;pointer-events:auto;}
  body.res-open #resWrap{z-index:62;}   /* lift the button + panel above the scrim */
  .reswrap.open .reslist{display:block;}
  .reshead{font-size:9px;letter-spacing:.16em;text-transform:uppercase;color:var(--dimmer);padding:6px 8px 8px;}
  .resitem{display:flex;align-items:flex-start;gap:10px;padding:9px 10px;border-radius:7px;text-decoration:none;color:var(--text);}
  .resitem:hover{background:rgba(255,255,255,.055);}
  .resitem-open{display:flex;align-items:flex-start;gap:10px;flex:1 1 auto;min-width:0;text-decoration:none;color:inherit;}
  .resico{width:28px;height:28px;flex:0 0 auto;border-radius:7px;display:flex;align-items:center;justify-content:center;margin-top:1px;
    background:rgba(255,255,255,.06);border:1px solid var(--line2);}
  .restext{flex:1 1 auto;min-width:0;}
  .res-l1{display:flex;align-items:baseline;gap:9px;}
  .resitem .lab{font-size:13px;flex:0 1 auto;letter-spacing:0;text-transform:none;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
  .resitem .typ{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dimmer);flex:0 0 auto;}
  /* Optional per-resource description subtitle (Option A) — wraps up to 2 lines. */
  .res-desc{font-size:11.5px;line-height:1.4;color:var(--dim);margin-top:3px;letter-spacing:0;text-transform:none;
    display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
  .resitem .ext{color:var(--dimmer);flex:0 0 auto;margin-top:7px;}
  .res-rm{flex:0 0 auto;width:22px;height:22px;border-radius:6px;border:1px solid var(--line2);background:none;color:var(--dimmer);
    cursor:pointer;font-size:12px;line-height:1;display:none;align-items:center;justify-content:center;padding:0;margin-left:2px;margin-top:1px;}
  .res-mine .res-rm{display:inline-flex;} /* only band items THIS device added get an ✕ */
  .res-rm:hover{border-color:var(--vid,#ff5a5a);color:var(--vid,#ff5a5a);}
  /* Edit pencil — shown on any mixer-added (band) item; admin-added items don't get one. */
  .res-edit{flex:0 0 auto;width:22px;height:22px;border-radius:6px;border:1px solid var(--line2);background:none;color:var(--dimmer);
    cursor:pointer;line-height:1;display:inline-flex;align-items:center;justify-content:center;padding:0;margin-left:2px;margin-top:1px;}
  .res-edit:hover{border-color:var(--orange);color:var(--orange);}
  .resitem.editing{display:block;padding:6px 8px;}
  .resitem.editing .res-form{padding:0;}
  .res-add{margin:4px 4px 2px;display:block;width:calc(100% - 8px);text-align:left;padding:8px 10px;border-radius:7px;
    border:1px dashed var(--line2);background:none;color:var(--dim);cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;}
  .res-add:hover{border-color:var(--orange);color:var(--orange);}
  .res-sep{height:1px;background:var(--line);margin:5px 6px;}
  .res-form{padding:6px 6px 2px;display:none;}
  .res-form.open{display:block;}
  .res-form input,.res-form select,.res-form textarea{display:block;width:100%;margin-bottom:6px;padding:8px 9px;border-radius:6px;border:1px solid var(--line2);
    background:var(--groove,#141418);color:var(--text);font-family:'JetBrains Mono',monospace;font-size:11px;outline:none;box-sizing:border-box;}
  .res-form textarea{resize:vertical;min-height:42px;line-height:1.4;}
  .res-form input:focus,.res-form select:focus,.res-form textarea:focus{border-color:var(--orange);}
  .res-form input::placeholder,.res-form textarea::placeholder{color:var(--dimmer);}
  .res-frow{display:flex;gap:6px;}
  .res-frow .res-save{flex:1;padding:8px;border-radius:6px;border:1px solid color-mix(in srgb,var(--orange),#000 8%);
    background:linear-gradient(180deg,color-mix(in srgb,var(--orange),#fff 12%),color-mix(in srgb,var(--orange),#000 8%));
    color:#160d02;font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;}
  .res-frow .res-cancel{padding:8px 10px;border-radius:6px;border:1px solid var(--line2);background:none;color:var(--dim);
    font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;}
  .res-msg{font-size:10px;color:var(--dimmer);padding:2px 4px 4px;min-height:14px;letter-spacing:0;text-transform:none;}
  .res-msg.err{color:var(--vid,#ff5a5a);}
  /* Status readout retired from the UI (v1.8.5) — kept in the DOM for the engine's messages */
  .status{display:none !important;}
  .master{display:flex;align-items:center;gap:10px;}
  .master .m-lbl{font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:.18em;color:var(--dimmer);text-transform:uppercase;}
  .master input[type=range]{
    -webkit-appearance:none;appearance:none;width:120px;height:6px;border-radius:3px;
    background:linear-gradient(90deg,var(--orange) var(--fill,100%),#101014 var(--fill,100%));
    outline:none;cursor:pointer;
  }
  .master input[type=range]::-webkit-slider-thumb{
    -webkit-appearance:none;appearance:none;width:14px;height:14px;border-radius:4px;
    background:linear-gradient(180deg,#eef0f4,#9a9ca6);border:1px solid #6e6e78;
    box-shadow:0 2px 4px rgba(0,0,0,.5);
  }
  .master input[type=range]::-moz-range-thumb{
    width:14px;height:14px;border-radius:4px;
    background:linear-gradient(180deg,#eef0f4,#9a9ca6);border:1px solid #6e6e78;
  }
  .master .m-val{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--dim);width:30px;text-align:right;}
  .status{display:flex;align-items:center;gap:8px;min-width:160px;}
  .status .dot{width:9px;height:9px;border-radius:50%;background:var(--dimmer);flex:0 0 auto;}
  .status.loading .dot{background:var(--orange);animation:pulse 1s infinite;}
  .status.ready .dot{background:#37b24d;box-shadow:0 0 8px rgba(55,178,77,.7);}
  .status.error .dot{background:var(--red);box-shadow:0 0 8px rgba(230,64,42,.7);}
  @keyframes pulse{0%,100%{opacity:.35}50%{opacity:1}}
  .status .stxt{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);line-height:1.3;min-width:0;}
  .status .stxt b{color:var(--text);font-weight:500;display:block;max-width:190px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .time{font-family:'JetBrains Mono',monospace;font-size:15px;letter-spacing:.04em;color:var(--text);white-space:nowrap;}
  .time .tot{color:var(--dim);}

  .tp-progress{position:absolute;left:0;right:0;bottom:0;height:var(--scrub-h,30px);background:#101014;cursor:grab;touch-action:none;}
  .tp-progress.dragging{cursor:grabbing;}
  /* Timeline ruler: faint baseline + minor/major tick marks, sitting UNDER the
     fill so the bar reads as a seek timeline even before a song plays. Ticks
     stay visible in the un-played (right) portion as the amber fill grows. */
  .tp-ruler{
    position:absolute;inset:0;z-index:0;pointer-events:none;
    background-repeat:no-repeat;
    background-position:center center, center center, center center;
    background-image:
      linear-gradient(rgba(255,255,255,.09), rgba(255,255,255,.09)),
      repeating-linear-gradient(90deg, rgba(255,255,255,.22) 0 1px, transparent 1px 12.5%),
      repeating-linear-gradient(90deg, rgba(255,255,255,.12) 0 1px, transparent 1px 2.5%);
    background-size:100% 1px, 100% 16px, 100% 9px;
  }
  .tp-progress-fill{position:relative;height:100%;width:0%;background:var(--scrub-c,#f5c518);box-shadow:0 0 10px color-mix(in srgb, var(--scrub-c,#f5c518) 55%, transparent);pointer-events:none;overflow:visible;}
  /* Drag grip on the leading edge of the fill: flat chip, three horizontal
     (hamburger) lines, kept inside the bar height so it never pokes above/below.
     Its RIGHT edge is pinned to the playback position (right:0 of the fill, no
     transform), so widening the handle grows it LEFTWARD — it never runs ahead
     of where the song actually is. Colors + width are Workbench-adjustable. */
  .scrub-grip{
    position:absolute;right:0;top:0;bottom:0;width:var(--grip-w,15px);
    background:var(--grip-bg,#cdcfd6);
    border:1px solid color-mix(in srgb, var(--grip-bg,#cdcfd6), black 32%);border-radius:2px;
    display:flex;align-items:center;justify-content:center;
  }
  .scrub-grip::before{
    content:"";width:8px;height:10px;
    background-image:repeating-linear-gradient(0deg, var(--grip-lines,#5b5b62) 0 1.5px, transparent 1.5px 4px);
  }


  /* ---------- Feature bar ---------- */
  /* Feature "+" button, now living inside each channel's header (right-justified) */
  .chfeat{
    flex:0 0 auto;margin-left:auto;
    width:28px;height:26px;border-radius:6px;padding:0;cursor:pointer;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border:1px solid color-mix(in srgb, var(--orange), white 28%);color:#160d02;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.25);
    display:inline-flex;align-items:center;justify-content:center;transition:all .12s;
  }
  .chfeat .sign{font-family:'Big Shoulders Display',sans-serif;font-size:22px;font-weight:700;line-height:1;color:#160d02;}
  .chfeat:hover{border-color:#fff;}
  .chfeat.active{
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 24%), var(--orange));
    border-color:#fff;box-shadow:0 0 12px color-mix(in srgb, var(--orange) 55%, transparent), inset 0 1px 0 rgba(255,255,255,.3);
  }

  /* Base pill styling retained for the SPEED button (now in the transport) */
  .featbtn{
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:12px;letter-spacing:.1em;
    padding:8px 14px;border-radius:7px;cursor:pointer;
    background:linear-gradient(180deg,#30303a,#25252c);
    border:1px solid var(--line2);color:var(--text);
    display:flex;align-items:center;gap:6px;transition:all .12s;white-space:nowrap;
  }
  .featbtn:hover{border-color:var(--orange);}
  .speed{position:relative;display:inline-flex;flex:0 0 auto;}
  .speed-btn b{color:inherit;font-weight:700;margin-left:4px;}
  .speed-btn .sign{font-size:10px;}
  .speed-list{
    position:absolute;top:calc(100% + 6px);right:0;z-index:60;min-width:120px;
    background:#1b1b21;border:1px solid var(--line2);border-radius:8px;
    box-shadow:0 18px 40px rgba(0,0,0,.6);padding:5px;display:none;
  }
  .speed.open .speed-list{display:block;}
  .speed-item{
    display:block;width:100%;text-align:left;padding:7px 12px;border-radius:6px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;letter-spacing:.08em;
    background:none;border:none;color:var(--text);
  }
  .speed-item:hover{background:#2a2a32;}
  .speed-item.sel{background:color-mix(in srgb, var(--orange) 16%, transparent);color:var(--orange);}
  .bpm{
    display:inline-flex;align-items:baseline;gap:7px;font-family:'JetBrains Mono',monospace;white-space:nowrap;
  }
  .bpm-lbl{font-size:10px;letter-spacing:.22em;color:var(--dimmer);text-transform:uppercase;}
  .bpm b{font-size:15px;font-weight:700;color:var(--amber);letter-spacing:.04em;}

  /* ---------- Mixer ---------- */
  .mixer{display:flex;gap:10px;padding:14px;background:#1c1c22;min-height:420px;}
  .strip{
    flex:1 1 0;min-width:104px;
    background:linear-gradient(180deg,var(--panel2),#232329);
    border:1px solid var(--line);border-radius:9px;
    padding:10px 8px 12px;display:flex;flex-direction:column;align-items:center;
    position:relative;transition:opacity .18s, border-color .18s;
  }
  .strip.ducked{opacity:.4;}
  .strip.muted{opacity:.5;}
  .strip.soloed{border-color:var(--solo);}
  .strip.failed{opacity:.35;}
  .strip-head{width:100%;display:flex;align-items:center;flex-wrap:nowrap;gap:8px;padding:2px 4px 8px;border-bottom:1px solid var(--line);margin-bottom:9px;}
  .tnum{flex:0 0 auto;font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:26px;line-height:.9;color:var(--orange);text-shadow:0 1px 0 #000;}
  .tname{flex:0 1 auto;min-width:0;font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:26px;line-height:.9;letter-spacing:.02em;text-transform:uppercase;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .strip.failed .tname{color:var(--red);}
  .ms{display:flex;gap:6px;width:100%;margin-bottom:12px;}
  .msbtn{
    flex:1 1 0;height:28px;border-radius:6px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:12px;
    background:linear-gradient(180deg,#2f2f38,#26262d);
    border:1px solid var(--line2);color:var(--dim);transition:all .1s;
  }
  .msbtn:hover{color:var(--text);border-color:var(--dim);}
  .msbtn.on.m{background:var(--mute);border-color:#6ea8ff;color:#fff;box-shadow:0 0 10px rgba(47,127,230,.5);}
  .msbtn.on.s{background:var(--solo);border-color:#ffe066;color:#241f00;box-shadow:0 0 10px rgba(242,197,23,.5);}

  /* ---------- Fader: LED ladder (default) or solid fill ---------- */
  .fader{position:relative;height:246px;display:flex;justify-content:center;width:100%;margin-bottom:8px;}
  .fader-track{
    position:relative;width:var(--fader-w,30px);height:100%;
    background:linear-gradient(90deg,#0e0e12,#191920 50%,#0e0e12);
    border:1px solid #0a0a0d;border-radius:6px;
    box-shadow:inset 0 2px 8px rgba(0,0,0,.8);cursor:pointer;touch-action:none;overflow:hidden;
  }
  /* Full-height color ladder: green→yellow→orange→red by position, cut into LED segments */
  .fader-ladder{
    position:absolute;inset:2px 4px;
    background-image:
      repeating-linear-gradient(180deg, rgba(8,8,10,.95) 0, rgba(8,8,10,.95) 3px, transparent 3px, transparent var(--seg)),
      linear-gradient(to top,
        var(--green) 0 var(--z1),
        var(--yellow) var(--z1) var(--z2),
        var(--zorange) var(--z2) var(--z3),
        var(--red) var(--z3) 100%);
    border-radius:3px;
  }
  /* Dark shade covering the UNLIT portion above the fader position (leaves a dim ghost) */
  .fader-unlit{
    position:absolute;top:0;left:0;right:0;height:10%;
    background:rgba(10,10,13,.9);
  }
  /* Solid-fill mode (workbench toggle) */
  .fader-fill{
    position:absolute;left:0;right:0;bottom:0;height:100%;border-radius:0 0 5px 5px;
    background:var(--red);transition:background-color .25s ease;display:none;
  }
  .smx-solid .fader-ladder,.smx-solid .fader-unlit{display:none;}
  .smx-solid .fader-fill{display:block;}
  /* Peak-hold marker (live meters) */
  .fader-peak{
    position:absolute;left:4px;right:4px;height:3px;bottom:0;z-index:1;
    background:#fff;border-radius:1px;display:none;
    box-shadow:0 0 6px rgba(255,255,255,.6);
  }
  .fader-fill.z0{background:var(--green);}
  .fader-fill.z1{background:var(--yellow);}
  .fader-fill.z2{background:var(--zorange);}
  .fader-fill.z3{background:var(--red);}
  .strip.muted .fader-ladder{filter:grayscale(1) brightness(.6);}
  .strip.muted .fader-fill{background:#4a4a52 !important;}
  .fader-ticks{
    position:absolute;top:0;bottom:0;right:-9px;width:6px;
    background-image:repeating-linear-gradient(180deg,var(--dimmer) 0,var(--dimmer) 1px,transparent 1px,transparent 12px);
    opacity:.5;pointer-events:none;
  }
  .fader-ticks.left{right:auto;left:-9px;}
  .fader-handle{
    position:absolute;left:50%;transform:translateX(-50%);
    width:calc(var(--fader-w,30px) + 14px);height:32px;bottom:0;z-index:2;
    background:linear-gradient(180deg,#eef0f4 0%,#c7c9d0 45%,#9a9ca6 55%,#d3d5db 100%);
    border:1px solid #6e6e78;border-radius:5px;
    box-shadow:0 3px 6px rgba(0,0,0,.6), inset 0 1px 0 rgba(255,255,255,.8);
    pointer-events:none;display:flex;align-items:center;justify-content:center;
  }
  .fader-handle .cap{position:absolute;width:100%;height:3px;background:var(--orange);border-radius:1px;box-shadow:0 0 5px color-mix(in srgb, var(--orange) 70%, transparent);}
  .pct{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--dim);letter-spacing:.04em;min-height:16px;}
  .strip.muted .pct::after{content:" · MUTE";color:var(--mute);}
  .strip.failed .pct::after{content:" · FILE ERROR";color:var(--red);font-size:9px;}

  /* ---------- Loading overlay ---------- */
  .loading{
    position:absolute;inset:0;background:rgba(16,16,20,.88);z-index:100;
    display:none;align-items:center;justify-content:center;
    backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px);border-radius:10px;
  }
  .stemmaxxer.is-loading .loading{display:flex;}
  .loading-inner{
    background:var(--panel);border:2px solid var(--line2);border-radius:9px;
    padding:28px 40px;min-width:300px;text-align:center;
  }
  .loading-label{font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;letter-spacing:.22em;color:var(--orange);margin-bottom:12px;}
  .loading-text{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--text);margin-bottom:14px;}
  .loading-bar{height:6px;background:var(--groove);border-radius:3px;overflow:hidden;}
  .loading-fill{height:100%;width:0%;background:var(--orange);transition:width .15s ease;}

  /* ---------- Hint footer (keyboard legend) — always one line ---------- */
  .hint{
    padding:11px 16px 13px;border-top:2px solid var(--line);background:#1a1a20;
    font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--dim);
    letter-spacing:.02em;line-height:1.8;
    display:flex;align-items:center;flex-wrap:nowrap;
    white-space:nowrap;overflow:hidden;
  }
  .hint kbd{background:var(--panel2);border:1px solid var(--line2);border-radius:3px;padding:1px 5px;color:#c9c9cf;font-family:inherit;}
  .hint .hsep{margin:0 8px;color:var(--dimmer);}
  .hint #hint{min-width:0;overflow:hidden;text-overflow:clip;}
  @media (max-width:1250px){ .hint{font-size:11px;} }
  @media (max-width:1080px){ .hint{font-size:10px;} }
  @media (max-width:1010px){ .hint{font-size:9px;letter-spacing:0;} .hint .hsep{margin:0 5px;} .hint kbd{padding:1px 4px;} }

  /* ---------- Teacher mode (hover-to-learn) ---------- */
  .teach-toggle{
    flex:0 0 auto;margin-left:auto;display:inline-flex;align-items:center;gap:6px;
    background:var(--panel2);border:1px solid var(--line2);border-radius:6px;color:var(--dim);cursor:pointer;
    padding:3px 9px;font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;
    transition:all .15s ease;
  }
  .teach-toggle svg{width:16px;height:16px;display:block;flex:0 0 auto;}
  .teach-toggle:hover{border-color:var(--orange);color:var(--text);}
  .stemmaxxer.teach .teach-toggle{background:var(--orange);border-color:var(--orange);color:#160d02;box-shadow:0 0 12px color-mix(in srgb, var(--orange) 45%, transparent);}
  .stemmaxxer.teach [data-teach]{cursor:help;}
  .teach-hi{outline:2px solid var(--orange) !important;outline-offset:2px;border-radius:5px;}
  .teach-panel{
    position:fixed;left:0;top:0;width:300px;max-width:calc(100vw - 24px);overflow:auto;
    background:rgba(18,18,22,.985);border:1px solid var(--orange);border-radius:12px;
    box-shadow:0 18px 50px rgba(0,0,0,.6);padding:14px 16px;z-index:800;display:none;
    pointer-events:none; /* never steal hover from the control being explained */
  }
  .teach-panel.open{display:block;}
  .teach-panel .teach-eyebrow{font-family:'JetBrains Mono',monospace;font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:var(--dimmer);margin-bottom:7px;}
  .teach-panel .teach-t{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:19px;letter-spacing:.03em;text-transform:uppercase;color:var(--orange);margin-bottom:5px;line-height:1.05;}
  .teach-panel .teach-d{font-family:'Bricolage Grotesque',system-ui,sans-serif;font-size:13.5px;line-height:1.5;color:var(--text);}
  .teach-panel .teach-d kbd{background:var(--panel2);border:1px solid var(--line2);border-radius:3px;padding:0 5px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#c9c9cf;}

  /* Footnote matches the FEATURE label styling (fb-label) */
  /* Two-line footer (v1.14.27): brand+version bright on top, tagline quieter below. */
  .footnote{margin-top:16px;text-align:center;font-family:'JetBrains Mono',monospace;}
  .footnote .fn-l1{font-size:12.5px;letter-spacing:.1em;color:var(--text);font-weight:700;text-transform:uppercase;}
  .footnote .fn-l1 b{color:var(--orange);font-weight:700;}
  .footnote .fn-l2{font-size:11.5px;letter-spacing:.02em;color:var(--dim);margin-top:5px;white-space:nowrap;}
  .footnote .fn-l2 .fn-sep{color:var(--line2);margin:0 7px;}
  .fn-link{background:none;border:none;padding:0;cursor:pointer;font-family:'JetBrains Mono',monospace;
    font-size:11px;letter-spacing:.02em;color:var(--dim);text-decoration:underline;text-underline-offset:2px;
    text-decoration-color:var(--line2);transition:color .12s, text-decoration-color .12s;}
  .fn-link:hover,.fn-link:focus-visible{color:var(--orange);text-decoration-color:var(--orange);outline:none;}

  /* ---- Feedback modal ---- */
  #fbBackdrop{position:fixed;inset:0;z-index:2000;background:rgba(8,8,10,.62);
    opacity:0;visibility:hidden;pointer-events:none;transition:opacity .16s, visibility .16s;}
  body.fb-open #fbBackdrop{opacity:1;visibility:visible;pointer-events:auto;}
  #fbModal{position:fixed;inset:0;z-index:2001;display:flex;align-items:center;justify-content:center;padding:20px;
    opacity:0;visibility:hidden;pointer-events:none;transition:opacity .16s, visibility .16s;}
  body.fb-open #fbModal{opacity:1;visibility:visible;pointer-events:auto;}
  .fb-card{position:relative;width:440px;max-width:100%;background:#2a2a34;
    border:1px solid var(--orange);border-radius:14px;padding:22px 22px 20px;
    box-shadow:0 26px 60px rgba(0,0,0,.72),0 0 0 1px color-mix(in srgb,var(--orange) 26%,transparent),0 12px 44px color-mix(in srgb,var(--orange) 40%,transparent);
    transform:translateY(6px);transition:transform .16s;}
  body.fb-open .fb-card{transform:translateY(0);}
  .fb-x{position:absolute;top:10px;right:12px;background:none;border:none;color:var(--dim);font-size:24px;line-height:1;cursor:pointer;padding:2px 6px;}
  .fb-x:hover{color:var(--text);}
  .fb-title{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:26px;letter-spacing:.02em;color:var(--text);}
  .fb-title b{color:var(--orange);}
  .fb-sub{color:var(--dim);font-size:12px;line-height:1.5;margin:4px 0 14px;}
  .fb-msg{font-size:11px;color:var(--dimmer);min-height:15px;margin:0 0 8px;letter-spacing:0;}
  .fb-msg.err{color:var(--vid,#ff5a5a);}
  .fb-msg.ok{color:var(--green,#37b24d);}
  .fb-in{display:block;width:100%;box-sizing:border-box;margin-bottom:10px;padding:10px 11px;border-radius:8px;
    border:1px solid var(--line2);background:#141418;color:var(--text);font-family:'JetBrains Mono',monospace;font-size:12px;outline:none;}
  .fb-in:focus{border-color:var(--orange);}
  .fb-in::placeholder{color:var(--dimmer);}
  textarea.fb-in{resize:vertical;min-height:96px;line-height:1.45;}
  .fb-row{display:flex;gap:8px;margin-top:2px;}
  .fb-send{flex:1;padding:11px;border-radius:8px;border:1px solid color-mix(in srgb,var(--orange),#000 8%);
    background:linear-gradient(180deg,color-mix(in srgb,var(--orange),#fff 12%),color-mix(in srgb,var(--orange),#000 8%));
    color:#160d02;font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;cursor:pointer;}
  .fb-send:disabled{opacity:.6;cursor:default;}
  .fb-cancel{padding:11px 14px;border-radius:8px;border:1px solid var(--line2);background:none;color:var(--dim);
    font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;cursor:pointer;}
  .fb-cancel:hover{color:var(--text);border-color:var(--dim);}

  /* ---------- WORKBENCH (Shift+W) ---------- */
  .workbench{
    position:fixed;top:0;left:0;bottom:0;width:320px;z-index:500;
    background:#1b1b21;border-right:2px solid var(--line2);
    box-shadow:14px 0 44px rgba(0,0,0,.55);
    transform:translateX(-104%);transition:transform .22s ease;
    display:flex;flex-direction:column;
  }
  .workbench.open{transform:translateX(0);}
  .wb-head{
    display:flex;align-items:center;justify-content:space-between;
    padding:16px 18px;border-bottom:2px solid var(--line);flex:0 0 auto;
  }
  .wb-title{font-family:'JetBrains Mono',monospace;font-size:12px;font-weight:700;letter-spacing:.2em;color:var(--orange);display:block;}
  .wb-version{
    display:block;font-family:'Big Shoulders Display',sans-serif;font-weight:800;
    font-size:28px;line-height:1;letter-spacing:.05em;color:var(--text);margin-top:5px;
  }
  .wb-close{
    width:30px;height:30px;border-radius:6px;cursor:pointer;background:none;
    border:1px solid var(--line2);color:var(--text);font-size:16px;line-height:1;
    display:flex;align-items:center;justify-content:center;
  }
  .wb-close:hover{border-color:var(--orange);}
  .wb-body{overflow-y:auto;padding:6px 18px 22px;flex:1 1 auto;scrollbar-width:thin;scrollbar-color:#50505c #1b1b21;}
  /* Whole-panel passkey lock */
  .wb-lock{display:none;padding:26px 20px 22px;flex:1 1 auto;}
  .workbench.wb-locked .wb-lock{display:block;}
  .workbench.wb-locked .wb-body,.workbench.wb-locked .wb-foot{display:none;}
  .wb-lock-title{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:20px;letter-spacing:.03em;
    text-transform:uppercase;color:var(--text);margin-bottom:8px;}
  .wb-lock-note{font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--dim);line-height:1.7;letter-spacing:.03em;margin-bottom:16px;}
  .wb-tabs{display:flex;gap:6px;position:sticky;top:0;z-index:4;background:#1b1b21;padding:4px 0 10px;margin-bottom:4px;}
  .wb-tab{flex:1 1 0;padding:9px 6px;border-radius:8px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;
    letter-spacing:.08em;text-transform:uppercase;background:#141418;border:1px solid var(--line2);color:var(--dim);white-space:nowrap;}
  .wb-tab.on{background:linear-gradient(180deg, color-mix(in srgb,var(--orange),white 12%), color-mix(in srgb,var(--orange),black 8%));border-color:var(--orange);color:#160d02;}
  .wb-pane{display:none;} .wb-pane.on{display:block;}
  /* Changelog tab */
  .cl-note{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);line-height:1.7;letter-spacing:.03em;margin:0 0 12px;}
  .cl-list{display:flex;flex-direction:column;}
  .cl-row{display:flex;gap:11px;padding:9px 2px;border-top:1px solid var(--line);align-items:baseline;}
  .cl-row:first-child{border-top:none;}
  .cl-v{flex:0 0 auto;width:52px;font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;color:var(--orange);letter-spacing:.01em;}
  .cl-t{flex:1 1 auto;min-width:0;font-size:12px;color:var(--text);line-height:1.45;}
  .cl-row.cur{background:color-mix(in srgb,var(--orange) 7%,transparent);border-radius:6px;margin:0 -4px;padding-left:6px;padding-right:6px;}
  .cl-badge{display:inline-block;margin-left:7px;font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:#160d02;
    background:var(--orange);border-radius:4px;padding:1px 5px;vertical-align:middle;}
  /* Traffic tab */
  .tr-note{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);line-height:1.7;letter-spacing:.03em;margin:0 0 14px;}
  .tr-tiles{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;}
  .tr-tile{background:var(--groove);border:1px solid var(--line);border-radius:8px;padding:11px 12px;}
  .tr-n{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:26px;line-height:1;color:var(--text);}
  .tr-l{font-family:'JetBrains Mono',monospace;font-size:8px;letter-spacing:.16em;text-transform:uppercase;color:var(--dimmer);margin-top:4px;}
  .tr-chart{display:flex;align-items:flex-end;gap:2px;height:70px;padding:6px 2px 0;border-bottom:1px solid var(--line);}
  .tr-bar{flex:1 1 0;min-width:2px;background:linear-gradient(180deg, color-mix(in srgb,var(--orange),white 10%), var(--orange));border-radius:2px 2px 0 0;min-height:2px;}
  .tr-bar.zero{background:#2a2a30;}
  .tr-axis{display:flex;justify-content:space-between;font-family:'JetBrains Mono',monospace;font-size:8px;color:var(--dimmer);letter-spacing:.06em;margin-top:5px;}
  .tr-flag{font-family:'JetBrains Mono',monospace;font-size:9px;line-height:1.65;letter-spacing:.03em;margin-top:14px;padding:9px 11px;border-radius:7px;}
  .tr-flag.ok{color:#9be7ad;background:rgba(75,196,99,.10);border:1px solid rgba(110,231,168,.35);}
  .tr-flag.warn{color:#ffcf8f;background:color-mix(in srgb,var(--orange) 12%, transparent);border:1px solid color-mix(in srgb,var(--orange),transparent 55%);}
  .tr-flag.hot{color:#ff9d9d;background:rgba(230,64,42,.12);border:1px solid rgba(255,106,82,.5);}
  .wb-sec{
    font-family:'JetBrains Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.24em;
    text-transform:uppercase;color:var(--dimmer);margin:20px 0 10px;padding-bottom:5px;
    border-bottom:1px solid var(--line);
  }
  .wb-row{margin-bottom:14px;}
  .wb-lbl{
    display:flex;justify-content:space-between;align-items:baseline;
    font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.08em;
    text-transform:uppercase;color:var(--dim);margin-bottom:6px;
  }
  .wb-lbl b{color:var(--orange);font-weight:700;font-size:11px;}
  .wb-row input[type=range]{
    -webkit-appearance:none;appearance:none;width:100%;height:6px;border-radius:3px;
    background:linear-gradient(90deg,var(--orange) var(--fill,50%),#101014 var(--fill,50%));
    outline:none;cursor:pointer;
  }
  .wb-row input[type=range]::-webkit-slider-thumb{
    -webkit-appearance:none;appearance:none;width:18px;height:18px;border-radius:4px;
    background:linear-gradient(180deg,#eef0f4,#9a9ca6);border:1px solid #6e6e78;
    box-shadow:0 2px 4px rgba(0,0,0,.5);
  }
  .wb-row input[type=range]::-moz-range-thumb{
    width:18px;height:18px;border-radius:4px;
    background:linear-gradient(180deg,#eef0f4,#9a9ca6);border:1px solid #6e6e78;
  }
  .wb-note{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);line-height:1.6;letter-spacing:.03em;margin-top:4px;}
  .wb-toggle{display:flex;gap:8px;}
  .wb-tbtn{
    flex:1 1 0;padding:8px 0;border-radius:6px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;letter-spacing:.1em;
    background:linear-gradient(180deg,#2f2f38,#26262d);border:1px solid var(--line2);color:var(--dim);
  }
  .wb-tbtn.on{
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border-color:color-mix(in srgb, var(--orange), white 28%);color:#160d02;
  }
  .wb-color{display:flex;align-items:center;gap:10px;}
  .wb-color input[type=color]{
    width:44px;height:30px;border:1px solid var(--line2);border-radius:6px;background:#101014;cursor:pointer;padding:2px;
  }
  .wb-swatches{display:flex;gap:6px;}
  .wb-sw{width:22px;height:22px;border-radius:5px;border:1px solid rgba(255,255,255,.25);cursor:pointer;padding:0;}
  .wb-reset{
    width:100%;margin-top:18px;padding:10px;border-radius:7px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:10px;font-weight:700;letter-spacing:.14em;
    background:none;border:1px solid var(--line2);color:var(--dim);
  }
  .wb-reset:hover{border-color:var(--red);color:var(--red);}
  .wb-deploy{
    width:100%;padding:12px;border-radius:7px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;letter-spacing:.16em;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border:1px solid color-mix(in srgb, var(--orange), white 28%);color:#160d02;
    box-shadow:0 0 14px color-mix(in srgb, var(--orange) 35%, transparent);
  }
  .wb-deploy:hover{border-color:#fff;}
  .wb-keyinput{
    width:100%;padding:9px 12px;border-radius:7px;border:1px solid var(--line2);
    background:var(--groove);color:var(--text);
    font-family:'JetBrains Mono',monospace;font-size:13px;letter-spacing:.12em;
    outline:none;box-shadow:inset 0 2px 6px rgba(0,0,0,.5);
  }
  .wb-keyinput:focus{border-color:var(--orange);}
  .wb-betalist{margin-bottom:12px;}
  .bl-status{
    font-family:'JetBrains Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.1em;
    text-transform:uppercase;padding:6px 9px;border-radius:6px;margin-bottom:10px;line-height:1.5;
    background:rgba(255,255,255,.04);border:1px solid var(--line2);color:var(--dim);
  }
  .bl-status.hidden{
    color:#ffcf8f;border-color:color-mix(in srgb, var(--orange), transparent 55%);
    background:color-mix(in srgb, var(--orange) 12%, transparent);
  }
  .bl-status.live{
    color:#9be7ad;border-color:rgba(110,231,168,.5);background:rgba(75,196,99,.12);
  }
  .bl-item{
    padding:9px 10px;border-radius:6px;margin-bottom:8px;
    background:var(--groove);border:1px solid var(--line);
  }
  .bl-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:3px;}
  .bl-title{
    font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;letter-spacing:.04em;
    color:var(--text);
  }
  .bl-badge{
    flex:0 0 auto;font-family:'JetBrains Mono',monospace;font-size:8px;font-weight:700;letter-spacing:.08em;
    text-transform:uppercase;padding:2px 6px;border-radius:4px;white-space:nowrap;
    background:rgba(255,255,255,.05);border:1px solid var(--line2);color:var(--dim);
  }
  .bl-badge.hidden{color:#ffcf8f;border-color:color-mix(in srgb, var(--orange), transparent 55%);background:color-mix(in srgb, var(--orange) 12%, transparent);}
  .bl-badge.live{color:#9be7ad;border-color:rgba(110,231,168,.5);background:rgba(75,196,99,.12);}
  .bl-desc{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);line-height:1.6;letter-spacing:.02em;margin-bottom:8px;}
  .bl-pub{
    width:100%;padding:8px 0;border-radius:6px;cursor:pointer;
    font-family:'JetBrains Mono',monospace;font-size:9px;font-weight:700;letter-spacing:.12em;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border:1px solid color-mix(in srgb, var(--orange), white 28%);color:#160d02;
  }
  .bl-pub:hover{border-color:#fff;}
  .bl-pub.on{background:linear-gradient(180deg,#4bc463,#2f9e45);border-color:#6ee7a8;color:#062611;}
  .bl-pub:disabled{opacity:.6;cursor:wait;}
  .bl-empty{font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);line-height:1.6;letter-spacing:.03em;padding:2px 0 4px;}
  .bl-baked{font-family:'JetBrains Mono',monospace;font-size:9px;color:#9be7ad;line-height:1.6;letter-spacing:.02em;
    margin-top:8px;padding:8px 10px;border-radius:6px;background:rgba(75,196,99,.10);border:1px solid rgba(110,231,168,.4);}
  .bl-baked b{color:#c8f4d3;}
  .wb-deploy:disabled{opacity:.6;cursor:wait;}
  .wb-deploy.ok{background:linear-gradient(180deg,#4bc463,#2f9e45);border-color:#6ee7a8;}
  .wb-deploy.err{background:linear-gradient(180deg,#e6402a,#b52c1a);border-color:#ff6a52;color:#fff;}
  .wb-foot{
    font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--dimmer);letter-spacing:.06em;
    padding:10px 18px 14px;border-top:1px solid var(--line);flex:0 0 auto;line-height:1.6;
  }
  .wb-addsong{
    display:block;width:100%;padding:12px;border-radius:7px;cursor:pointer;text-align:center;text-decoration:none;
    font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;
    background:linear-gradient(180deg, color-mix(in srgb, var(--orange), white 14%), color-mix(in srgb, var(--orange), black 10%));
    border:1px solid color-mix(in srgb, var(--orange), white 28%);color:#160d02;
    box-shadow:0 0 14px color-mix(in srgb, var(--orange) 35%, transparent);
  }
  .wb-addsong:hover{border-color:#fff;}
  /* ---------- Desktop-only overlay ---------- */
  .desktop-only{
    display:none;position:fixed;inset:0;z-index:999;
    background:rgba(10,10,12,.97);
    flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:30px;
  }
  .desktop-only .dm-wm{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:44px;letter-spacing:.05em;color:#c9c9cf;}
  .desktop-only .dm-wm .xx{color:var(--orange);}
  .desktop-only h2{font-family:'JetBrains Mono',monospace;letter-spacing:.14em;font-size:14px;margin:12px 0 8px;color:var(--text);}
  .desktop-only p{color:var(--dim);max-width:340px;line-height:1.6;font-size:14px;font-family:'Bricolage Grotesque',sans-serif;}
  .desktop-only .dm-continue{
    margin-top:24px;padding:14px 24px;border-radius:26px;border:none;cursor:pointer;
    background:var(--orange);color:#101014;
    font-family:'JetBrains Mono',monospace;font-weight:700;font-size:12px;letter-spacing:.12em;
  }
  .desktop-only .dm-continue:active{filter:brightness(.92);}
  .desktop-only .dm-note{margin-top:14px;max-width:320px;line-height:1.7;color:#6d6d78;font-size:11px;letter-spacing:.06em;font-family:'JetBrains Mono',monospace;}
  /* ===================== STEMMAXXER LITE — mobile CONSOLE skin (v2.0.0) =====================
     A second control surface over the SAME engine. Hidden by default; shown only at
     <=900px when the `mobile` beta feature is active (body.smx-mobile). */
  #smxLite{display:none;position:fixed;inset:0;z-index:400;background:var(--bg);color:var(--text);
    flex-direction:column;font-family:'Bricolage Grotesque',sans-serif;-webkit-user-select:none;user-select:none;touch-action:none;}
  .lite-head{flex:none;display:flex;align-items:center;gap:8px;padding:calc(env(safe-area-inset-top,0px) + 10px) 16px 8px;}
  .lite-wm{font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:18px;letter-spacing:.05em;color:#c9c9cf;}
  .lite-wm .xx{color:var(--orange);}
  .lite-chip{font:700 9px 'JetBrains Mono',monospace;letter-spacing:.16em;color:var(--orange);border:1px solid rgba(239,125,28,.5);border-radius:4px;padding:2px 5px;}
  .lite-ver{font:600 9px 'JetBrains Mono',monospace;letter-spacing:.06em;color:var(--dimmer);align-self:center;}
  #liteLoad{position:absolute;inset:0;z-index:500;display:none;flex-direction:column;align-items:center;justify-content:center;background:rgba(16,16,20,.97);}
  #smxLite.loading #liteLoad{display:flex;}
  #liteLoad .ll-label{font:700 13px 'JetBrains Mono';letter-spacing:.24em;color:var(--orange);margin-bottom:12px;}
  #liteLoad .ll-text{font:600 12px 'JetBrains Mono';color:var(--text);margin-bottom:14px;}
  #liteLoad .ll-bar{width:200px;height:6px;background:#23232b;border-radius:3px;overflow:hidden;}
  #liteLoad .ll-fill{height:100%;width:0;background:var(--orange);transition:width .15s ease;}
  .lite-lock{margin-left:auto;color:#6d6d78;font-size:13px;}
  .lite-banner{flex:none;margin:6px 12px 0;border:1px solid rgba(239,125,28,.42);background:rgba(239,125,28,.06);
    border-radius:11px;padding:11px 13px;display:flex;align-items:center;gap:8px;text-align:left;color:inherit;width:auto;}
  .lite-banner .lb-artist{font-family:'Big Shoulders Display';font-weight:800;font-size:19px;letter-spacing:.02em;color:var(--orange);text-transform:uppercase;white-space:nowrap;}
  .lite-banner .lb-title{font-family:'Big Shoulders Display';font-weight:800;font-size:19px;letter-spacing:.02em;color:var(--text);text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0;}
  .lite-banner .lb-caret{margin-left:auto;flex:none;width:26px;height:26px;border-radius:7px;background:var(--orange);color:#101014;display:flex;align-items:center;justify-content:center;font-size:12px;}
  .lite-sub{flex:none;display:flex;align-items:center;gap:10px;padding:8px 16px 2px;}
  .lite-bpm{font:700 11px 'JetBrains Mono';color:var(--amber);letter-spacing:.04em;}
  .lite-bpm span{color:#6d6d78;font-weight:400;}
  .lite-hinttx{margin-left:auto;font:600 8.5px 'JetBrains Mono';letter-spacing:.09em;color:#6d6d78;text-transform:uppercase;}
  .lite-rows{flex:1;display:flex;flex-direction:column;gap:7px;padding:6px 12px;min-height:0;}
  .lite-row{position:relative;flex:1;min-height:50px;display:flex;align-items:stretch;border-radius:10px;overflow:hidden;border:2px solid #3a3a44;background:#23232b;}
  .lr-feat{flex:none;width:44px;display:flex;align-items:center;justify-content:center;font:700 22px 'JetBrains Mono';line-height:1;color:var(--orange);background:rgba(239,125,28,.13);border:none;border-right:1px solid #14141a;-webkit-tap-highlight-color:transparent;}
  .lr-feat.on{background:var(--orange);color:#101014;}
  .lr-name{flex:none;width:82px;display:flex;align-items:center;justify-content:flex-start;text-align:left;padding:0 6px 0 10px;font-family:'Big Shoulders Display',sans-serif;font-weight:800;font-size:20px;letter-spacing:.02em;text-transform:uppercase;color:#fff;line-height:1;}
  .lite-speed{display:inline-flex;align-items:stretch;height:38px;border:1px solid var(--line);border-radius:19px;overflow:hidden;background:#23232b;}
  .ls-btn{width:38px;border:none;background:rgba(239,125,28,.1);color:var(--orange);font:700 18px 'JetBrains Mono';display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;}
  .ls-btn.dis{color:#4a4a52;background:#1e1e25;}
  .ls-val{padding:0 12px;display:flex;align-items:center;font:700 10.5px 'JetBrains Mono';letter-spacing:.05em;color:#cfcfd6;border-left:1px solid var(--line);border-right:1px solid var(--line);white-space:nowrap;touch-action:manipulation;-webkit-tap-highlight-color:transparent;cursor:pointer;}
  .lr-lane{position:relative;flex:1;overflow:hidden;touch-action:none;border-left:1px solid #14141a;}
  .lr-zones{position:absolute;top:5px;bottom:5px;left:0;right:0;background:linear-gradient(90deg,var(--green) 0 25%,var(--yellow) 25% 50%,var(--zorange) 50% 75%,var(--red) 75% 100%);}
  .lr-cover{position:absolute;top:5px;bottom:5px;right:0;left:60%;background:#23232b;}
  .lr-slits{position:absolute;top:5px;bottom:5px;left:0;right:0;background:repeating-linear-gradient(90deg,transparent 0 7px,#1b1b21 7px 9px);}
  .lr-grip{position:absolute;top:2px;bottom:2px;left:60%;width:16px;margin-left:-8px;border-radius:4px;background:linear-gradient(180deg,#f0f0f4,#b6b6be);border:2px solid #0c0c10;z-index:2;box-shadow:0 1px 5px rgba(0,0,0,.6);}
  .lr-grip::after{content:"";position:absolute;left:50%;top:3px;bottom:3px;width:2px;transform:translateX(-50%);background:var(--orange);border-radius:1px;}
  .lr-err{position:absolute;inset:0;display:none;align-items:center;justify-content:center;gap:10px;background:rgba(38,14,12,.92);color:#ff9d8a;font:700 10px 'JetBrains Mono';letter-spacing:.07em;z-index:6;}
  .lite-row.failed .lr-err{display:flex;}
  .lr-err .rbtn{border:1px solid #ff9d8a;border-radius:13px;padding:5px 13px;color:#ff9d8a;font:700 10px 'JetBrains Mono';}
  .lr-ms{flex:none;display:flex;align-items:stretch;width:100px;border-left:2px solid #14141a;}
  .lr-m,.lr-s{position:relative;flex:1;border:none;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;}
  .lr-m{background:rgba(47,127,230,.13);}         /* off-state tint — mute = blue */
  .lr-s{background:rgba(242,197,23,.12);border-left:1px solid #14141a;} /* off-state tint — solo = yellow */
  .lr-m .lt,.lr-s .lt{position:relative;z-index:1;font:700 15px 'JetBrains Mono';}
  .lr-m .lt{color:#7fb0ff;} .lr-s .lt{color:var(--solo);}
  .lr-m .fl,.lr-s .fl{position:absolute;inset:0;display:none;}
  .lr-m.on .fl{display:block;background:var(--mute);} .lr-s.on .fl{display:block;background:var(--solo);}
  .lr-m.on .lt{color:#eef4ff;} .lr-s.on .lt{color:#161200;}
  /* detached inset pill when the segment does NOT own the frame color (e.g. focus owns it) */
  .lite-row:not(.st-mute) .lr-m.on .fl{inset:6px;border-radius:8px;}
  .lite-row:not(.st-solo) .lr-s.on .fl{inset:6px;border-radius:8px;}
  .lite-row.muted .lr-zones{filter:saturate(.15) brightness(.45);}
  .lite-row.muted .lr-grip{opacity:.35;}
  .lite-row.ducked .lr-zones{filter:saturate(.55) brightness(.72);}
  .lite-row.st-focus{border-color:var(--orange);box-shadow:0 0 0 1px var(--orange),0 0 15px rgba(239,125,28,.28);}
  .lite-row.st-solo{border-color:var(--solo);box-shadow:0 0 0 1px var(--solo),0 0 15px rgba(242,197,23,.26);}
  .lite-row.st-mute{border-color:var(--mute);box-shadow:0 0 0 1px var(--mute),0 0 15px rgba(47,127,230,.30);}
  /* Solid Fill fader style (Workbench → Fader Style; mirrors desktop body.smx-solid).
     The lit portion becomes one solid zone color set by the current level. */
  body.smx-solid .lite-row .lr-slits{display:none;}
  body.smx-solid .lite-row .lr-zones{background:var(--green);}
  body.smx-solid .lite-row.z0 .lr-zones{background:var(--green);}
  body.smx-solid .lite-row.z1 .lr-zones{background:var(--yellow);}
  body.smx-solid .lite-row.z2 .lr-zones{background:var(--zorange);}
  body.smx-solid .lite-row.z3 .lr-zones{background:var(--red);}
  body.smx-solid .lite-row.muted .lr-zones{background:#4a4a52;filter:none;}
  .lite-transport{flex:none;border-top:1px solid #2c2c34;background:#1a1a20;padding:10px 14px calc(env(safe-area-inset-bottom,0px) + 8px);}
  .lite-scrub{position:relative;height:30px;border-radius:6px;border:1px solid #2c2c34;overflow:hidden;touch-action:none;
    background-color:#101014;background-repeat:no-repeat;background-position:center center;
    background-image:
      linear-gradient(rgba(255,255,255,.09),rgba(255,255,255,.09)),
      repeating-linear-gradient(90deg,rgba(255,255,255,.22) 0 1px,transparent 1px 12.5%),
      repeating-linear-gradient(90deg,rgba(255,255,255,.12) 0 1px,transparent 1px 2.5%);
    background-size:100% 1px,100% 16px,100% 9px;}
  .lite-scrub .ls-fill{position:absolute;left:0;top:0;bottom:0;width:0%;background:linear-gradient(180deg,#f8d13d,#e9b90f);z-index:1;}
  .lite-scrub .ls-region{position:absolute;top:0;bottom:0;background:rgba(239,125,28,.20);border-left:2px solid var(--orange);border-right:2px solid var(--orange);z-index:2;pointer-events:none;}
  .lite-scrub .ls-flag{position:absolute;top:0;bottom:0;display:flex;align-items:center;font:700 9px 'JetBrains Mono';color:#101014;background:var(--orange);padding:0 6px;z-index:4;touch-action:none;cursor:ew-resize;}
  .lite-scrub .ls-flag.a{transform:translateX(-100%);border-radius:4px 0 0 4px;}
  .lite-scrub .ls-flag.b{border-radius:0 4px 4px 0;}
  .lite-loopbar{display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 0 2px;}
  .lite-loopbar .llb-lbl{font:700 8.5px 'JetBrains Mono';letter-spacing:.14em;color:var(--dimmer);text-transform:uppercase;margin-right:2px;}
  .llb-btn{height:32px;min-width:36px;padding:0 12px;border-radius:16px;border:1px solid var(--line);background:#23232b;color:#cfcfd6;font:700 11px 'JetBrains Mono';letter-spacing:.04em;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;}
  .llb-btn.set{border-color:var(--orange);color:var(--orange);background:rgba(239,125,28,.1);}
  .llb-btn.on{background:var(--orange);color:#101014;border-color:var(--orange);}
  .llb-btn.clr{color:var(--dimmer);font-size:15px;}
  .llb-btn.dis{opacity:.3;}
  .lite-time{display:flex;justify-content:space-between;font:600 12px 'JetBrains Mono';color:#8f8f9b;padding:7px 2px 2px;}
  .lite-tbtns{display:flex;align-items:center;justify-content:center;gap:15px;padding:6px 0 9px;}
  .lt-aux{width:46px;height:46px;border-radius:50%;background:#23232b;border:1px solid var(--line);color:#cfcfd6;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;}
  .lt-skip{width:52px;height:52px;border-radius:50%;background:#23232b;border:1px solid var(--line);color:#cfcfd6;font:700 10px 'JetBrains Mono';display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.05;-webkit-tap-highlight-color:transparent;}
  .lt-play{width:76px;height:76px;border-radius:50%;border:none;background:linear-gradient(180deg,#f89440,#e56f0f);box-shadow:0 8px 24px rgba(239,125,28,.36);display:flex;align-items:center;justify-content:center;color:#16161a;-webkit-tap-highlight-color:transparent;}
  .lite-chips{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;}
  .lchip{height:38px;padding:0 14px;border-radius:19px;border:1px solid var(--line);background:#23232b;color:#cfcfd6;font:700 10.5px 'JetBrains Mono';letter-spacing:.05em;display:flex;align-items:center;gap:6px;-webkit-tap-highlight-color:transparent;}
  .lchip.on{border-color:var(--orange);color:var(--orange);background:rgba(239,125,28,.1);}
  .lchip.disabled{opacity:.32;}
  .lite-sheet{position:fixed;inset:0;z-index:420;background:rgba(10,10,12,.98);display:none;flex-direction:column;padding:calc(env(safe-area-inset-top,0px) + 14px) 14px 14px;}
  .lite-sheet.open{display:flex;}
  .ls-head{display:flex;align-items:center;margin-bottom:10px;}
  .ls-head h3{font-family:'Big Shoulders Display';font-weight:800;font-size:24px;letter-spacing:.03em;text-transform:uppercase;}
  .ls-close{margin-left:auto;width:40px;height:40px;border-radius:10px;border:1px solid var(--line);background:#23232b;color:#cfcfd6;font-size:19px;}
  .ls-list{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:3px;}
  .ls-item{text-align:left;padding:13px 12px;border-radius:9px;background:#1b1b21;border:1px solid #2c2c34;color:inherit;display:flex;flex-direction:column;gap:1px;}
  .ls-item.sel{border-color:var(--orange);background:rgba(239,125,28,.08);}
  .ls-item .lsi-a{font-family:'Big Shoulders Display';font-weight:800;font-size:16px;letter-spacing:.02em;text-transform:uppercase;color:var(--orange);}
  .ls-item .lsi-t{font-family:'Big Shoulders Display';font-weight:800;font-size:17px;letter-spacing:.02em;text-transform:uppercase;color:var(--text);}
  @media (max-width:900px){
    /* When the `mobile` beta feature is active (device preview or published), the LITE
       mobile UI takes over the phone and everything desktop is suppressed. */
    body.smx-mobile #smxLite{display:flex;}
    body.smx-mobile .stemmaxxer,
    body.smx-mobile .brand,
    body.smx-mobile .nowsong,
    body.smx-mobile .footnote,
    body.smx-mobile .workbench,
    body.smx-mobile #resScrim,
    body.smx-mobile .desktop-only{display:none;}
    /* Otherwise: the desktop-recommended overlay, tap-through-able via
       body.smx-mobile-ok (the v1.14.35 "Use it here anyway" button). */
    body:not(.smx-mobile):not(.smx-mobile-ok) .stemmaxxer,
    body:not(.smx-mobile):not(.smx-mobile-ok) .brand,
    body:not(.smx-mobile):not(.smx-mobile-ok) .footnote,
    body:not(.smx-mobile):not(.smx-mobile-ok) .workbench,
    body:not(.smx-mobile):not(.smx-mobile-ok) .nowsong{display:none;}
    body:not(.smx-mobile):not(.smx-mobile-ok) .desktop-only{display:flex;}
  }
</style>
</head>
<body>

  <div class="brand">
  <?php if ($smx_logo_url !== ''): ?>
    <img class="wordmark-img" src="<?php echo esc_url($smx_logo_url); ?>" alt="STEMMAXXER">
  <?php else: ?>
    <div class="wordmark">STEMMA<span class="xx">XX</span>ER</div>
  <?php endif; ?>
  </div>

  <div class="nowsong" id="nowsong" aria-live="polite" tabindex="0" aria-haspopup="listbox"
       data-teach-title="Song selector" data-teach="This band &amp; song banner is also the song picker &mdash; click it (or press Enter) to open the list, then start typing to jump to a song. The list is alphabetical by band, then title.">
    <!-- The song-SELECTOR field: title + caret + (EQ). In banner-selector mode this
         span carries the clickable orange field, rounded on the LEFT, squared on the
         RIGHT so the Resources segment butts flush against it. -->
    <span class="ns-selfield" id="nsSelfield">
      <span class="ns-text">
        <span class="ns-artist" id="nsArtist"></span>
        <span class="ns-title" id="nsTitle"></span>
      </span>
      <span class="ns-caret" id="nsCaret" aria-hidden="true"><svg width="16" height="10" viewBox="0 0 12 8"><path d="M1 1 L6 6 L11 1" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
      <span class="ns-fill" aria-hidden="true"><canvas id="nsCanvas"></canvas></span>
    </span>
    <!-- Per-song RESOURCES — a SEPARATE segment butted against the selector field's right
         edge: same height, squared on the LEFT (shared seam), rounded on the RIGHT.
         Sibling of the selector field, gated by body.smx-resources. Filled by renderResources(). -->
    <span class="reswrap bf-resources" id="resWrap" data-teach-title="Resources" data-teach="Every link for this song — tabs, chords, video lessons, reference mixes — in one place, in its own panel butted against the song banner. A single link opens directly; more than one drops a list. If you know the band password you can add your own finds with “+ Add”.">
      <!-- filled by renderResources(): a single .slink, or a Resources ▾ button + list -->
    </span>
  </div>
  <!-- Backdrop scrim: dims the mixer behind the open Resources list. Body-level sibling so
       the banner (z-index 60) stays lit above it while the mixer below is dimmed. -->
  <div id="resScrim" aria-hidden="true"></div>

  <div class="stemmaxxer" id="app">
    <!-- TRANSPORT -->
    <div class="transport">
      <div class="tp-left">
        <button class="tbtn play" id="btnPlay" title="Play / Pause" aria-label="Play or pause"
          data-teach-title="Play / Pause" data-teach="Starts or pauses every stem at once — they always stay perfectly in sync. Keyboard: <kbd>Space</kbd>.">
          <svg id="icoPlay" width="16" height="18" viewBox="0 0 16 18"><path d="M1 1 L15 9 L1 17 Z" fill="currentColor"/></svg>
          <svg id="icoPause" width="14" height="16" viewBox="0 0 14 16" style="display:none"><rect x="1" y="1" width="4" height="14" fill="currentColor"/><rect x="9" y="1" width="4" height="14" fill="currentColor"/></svg>
        </button>
        <button class="tbtn" id="btnRestart" title="Restart song"
          data-teach-title="Restart" data-teach="Jumps back to the very start of the song and keeps playing. Keyboard: <kbd>R</kbd>.">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 9a6 6 0 1 0 1.8-4.2"/><path d="M4 2 L4 5.2 L7.2 5.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <button class="tbtn" id="btnReset" title="Reset (stop, clear mute/solo, faders to default)"
          data-teach-title="Reset" data-teach="A clean slate: stops and returns to the start, clears any mute, solo, or feature, and sets every fader back to its default level. Keyboard: <kbd>Shift</kbd>+<kbd>R</kbd>.">
          <svg width="21" height="18" viewBox="0 0 22 20" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><line x1="4" y1="3" x2="4" y2="17" stroke-linecap="round"/><line x1="11" y1="3" x2="11" y2="17" stroke-linecap="round"/><line x1="18" y1="3" x2="18" y2="17" stroke-linecap="round"/><line x1="2" y1="12.5" x2="20" y2="12.5" stroke-dasharray="1.5 1.6" opacity=".55"/><rect x="2" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/><rect x="9" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/><rect x="16" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/></svg>
        </button>
        <button class="tbtn" id="btnBack" title="Back 10 seconds"
          data-teach-title="Back 10 seconds" data-teach="Skips backward 10 seconds. Keyboard: <kbd>&larr;</kbd> (left arrow).">
          <svg width="20" height="14" viewBox="0 0 20 14"><path d="M9 1 L1 7 L9 13 Z M19 1 L11 7 L19 13 Z" fill="currentColor"/></svg>
          <span class="lbl10">10</span>
        </button>
        <button class="tbtn" id="btnFwd" title="Forward 10 seconds"
          data-teach-title="Forward 10 seconds" data-teach="Skips forward 10 seconds. Keyboard: <kbd>&rarr;</kbd> (right arrow).">
          <svg width="20" height="14" viewBox="0 0 20 14"><path d="M11 1 L19 7 L11 13 Z M1 1 L9 7 L1 13 Z" fill="currentColor"/></svg>
          <span class="lbl10">10</span>
        </button>
        <span class="loopgrp">
          <button class="lpbtn" id="loopABtn" title="Set loop start (A)"
            data-teach-title="Loop start (A)" data-teach="Marks the start of a practice loop at the current position. You can also drag the A flag along the playback bar to move it. Keyboard: <kbd>[</kbd>.">A</button>
          <button class="lpbtn" id="loopBBtn" title="Set loop end (B)"
            data-teach-title="Loop end (B)" data-teach="Marks the end of the loop at the current position. You can also drag the B flag along the playback bar to move it. Keyboard: <kbd>]</kbd>.">B</button>
          <button class="lpbtn loop" id="loopToggleBtn" title="Loop on/off"
            data-teach-title="Loop on / off" data-teach="Repeats the A&ndash;B section over and over (great for drilling a tricky part; works with the slow-down speed too). With no A/B set it loops the whole song. Keyboard: <kbd>L</kbd>.">
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><path d="M4 8a6 6 0 0 1 6-6h4M16 12a6 6 0 0 1-6 6H6" stroke-linecap="round"/><path d="M13 -1 L16 2 L13 5 M7 15 L4 18 L7 21" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <button class="lpbtn" id="loopClearBtn" title="Clear loop (remove A &amp; B)"
            data-teach-title="Clear loop" data-teach="Removes the A and B points and their flags from the playback bar and turns the loop off &mdash; a clean slate for the loop. Keyboard: <kbd>Shift</kbd>+<kbd>L</kbd>.">
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true"><path d="M5 5 L15 15 M15 5 L5 15" stroke-linecap="round"/></svg>
          </button>
        </span>
      </div>

      <div class="tp-mid">
        <div class="dropdown" id="dropdown" data-teach-title="Song selector" data-teach="Pick a song to load into the mixer. The list is alphabetical by band, then title — start typing to jump to one.">
          <button class="dd-button" id="ddButton" aria-haspopup="listbox" aria-expanded="false">
            <span class="dd-song" id="ddSong">Loading…</span>
            <span class="dd-caret"><svg width="12" height="8" viewBox="0 0 12 8"><path d="M1 1 L6 6 L11 1" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg></span>
          </button>
          <div class="dd-list" id="ddList">
            <div class="dd-scroll" id="ddScroll" role="listbox"></div>
            <div class="dd-sb hide" id="ddSb"><div class="dd-sb-thumb" id="ddSbThumb"></div></div>
          </div>
        </div>
      </div>

      <div class="tp-right">
        <span class="songlinks" id="songLinks">
          <a class="slink" id="chartLink" target="_blank" rel="noopener" style="display:none;" data-teach-title="Charts / Tab" data-teach="Opens this song&rsquo;s chord chart or tab in a new tab. Set the link per song in Settings → STEMMAXXER.">
            <svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M5 2h7l4 4v12H5z" stroke-linejoin="round"/><path d="M12 2v4h4" stroke-linejoin="round"/><path d="M7.5 10h5M7.5 13h5" stroke-linecap="round"/></svg>
            Charts
          </a>
          <a class="slink" id="lessonLink" target="_blank" rel="noopener" style="display:none;" data-teach-title="Lesson" data-teach="Opens a video lesson for this song in a new tab. Set the link per song in Settings → STEMMAXXER.">
            <svg viewBox="0 0 20 20" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M7 4l10 6-10 6z"/></svg>
            Lesson
          </a>
        </span>
        <div class="master" title="Master volume" data-teach-title="Master volume" data-teach="Sets the overall loudness of the whole mix at once, without changing the balance between the parts.">
          <span class="m-lbl">Master</span>
          <input type="range" id="mVol" min="0" max="100" step="5" value="100">
          <span class="m-val" id="mVolVal">100</span>
        </div>
        <span class="speed" id="speedWrap" data-teach-title="Playback speed" data-teach="Slows the song down without changing its pitch — perfect for learning a fast part. Pick anywhere from 100% down to 50%; the notes stay in tune.">
          <button class="featbtn speed-btn" id="speedBtn">SPEED <b id="speedVal">100%</b><span class="sign">▾</span></button>
          <span class="speed-list" id="speedList"></span>
        </span>
        <span class="bpm" data-teach-title="Tempo (BPM)" data-teach="The song&rsquo;s tempo in beats per minute, detected automatically from the drums (or set per song in Settings). When you slow the song down, it shows the reduced tempo too."><span class="bpm-lbl">BPM</span><b id="bpmVal">—</b></span>
        <div class="status" id="status">
          <span class="dot"></span>
          <span class="stxt"><b id="statusName">—</b><span id="statusMsg">idle</span></span>
        </div>
        <div class="time"><span id="tElapsed">0:00</span> <span class="tot">/ <span id="tTotal">0:00</span></span></div>
      </div>

      <div class="tp-progress" id="scrubber" data-teach-title="Playback bar" data-teach="Shows how far you are through the song — the tick marks read like a timeline ruler. Click anywhere on it — or drag the little grip — to jump to that spot."><div class="tp-ruler" aria-hidden="true"></div><div class="tp-progress-fill" id="progress"><span class="scrub-grip" aria-hidden="true"></span></div><div class="loop-region" id="loopRegion" style="display:none;"><span class="loop-handle a" id="loopHandleA"></span><span class="loop-handle b" id="loopHandleB"></span></div><span class="loop-mark a" id="loopMarkA" style="display:none;"><span class="lm-grab"></span><span class="lm-tag">A</span></span><span class="loop-mark b" id="loopMarkB" style="display:none;"><span class="lm-grab"></span><span class="lm-tag">B</span></span></div>
    </div>

    <!-- MIXER -->
    <div class="mixer" id="mixer"></div>

    <!-- HINT -->
    <div class="hint">
      <span id="hint"></span>
      <button class="teach-toggle" id="teachToggle" aria-pressed="false" title="RTFM — hover any control to see what it does"
        data-teach-title="RTFM" data-teach="You&rsquo;re using it right now &mdash; Read The Field Manual. While this is on, hover any button, fader, or control and its plain-English explanation appears here. Click the manual again to turn it off.">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="4.5" y="3" width="15" height="18" rx="1.5" stroke-linejoin="round"/><line x1="8.5" y1="3" x2="8.5" y2="21"/><line x1="11.5" y1="8" x2="16.5" y2="8" stroke-linecap="round"/><line x1="11.5" y1="11.5" x2="16.5" y2="11.5" stroke-linecap="round"/></svg>
        <span>RTFM</span>
      </button>
    </div>

    <!-- LOADING OVERLAY -->
    <div class="loading" aria-hidden="true">
      <div class="loading-inner">
        <div class="loading-label">LOADING</div>
        <div class="loading-text"><span id="loadCount">0 of 0</span> &nbsp;&middot;&nbsp; <span id="loadPct">0%</span></div>
        <div class="loading-bar"><div class="loading-fill" id="loadFill"></div></div>
      </div>
    </div>
  </div>

  <div class="footnote">
    <div class="fn-l1"><b>STEMMAXXER</b> v<?php echo esc_html($smx_version); ?></div>
    <div class="fn-l2">Multi-Stem Practice Mixer <span class="fn-sep">&middot;</span> Private band practice tool <span class="fn-sep">&middot;</span> <button type="button" class="fn-link" id="fbBugBtn">Report a bug</button> <span class="fn-sep">&middot;</span> <button type="button" class="fn-link" id="fbFeatBtn">Request a feature</button></div>
  </div>

  <!-- Feedback modal (bug report / feature request) → emails Chris from STEMMAXXER -->
  <div id="fbBackdrop" aria-hidden="true"></div>
  <div id="fbModal" role="dialog" aria-modal="true" aria-labelledby="fbTitle" aria-hidden="true">
    <div class="fb-card">
      <button type="button" class="fb-x" id="fbClose" aria-label="Close">&times;</button>
      <div class="fb-title" id="fbTitle">Report a bug</div>
      <div class="fb-sub" id="fbSub">Found something broken? Tell Chris what happened.</div>
      <div class="fb-msg" id="fbStatus"></div>
      <textarea id="fbMessage" class="fb-in" rows="5" maxlength="4000" placeholder="What happened? What were you trying to do?"></textarea>
      <input type="email" id="fbEmail" class="fb-in" placeholder="Your email (optional, so Chris can reply)" autocomplete="email">
      <div class="fb-row">
        <button type="button" class="fb-send" id="fbSend">Send</button>
        <button type="button" class="fb-cancel" id="fbCancel">Cancel</button>
      </div>
    </div>
  </div>

  <!-- TEACHER MODE explanation panel -->
  <div class="teach-panel" id="teachPanel" aria-live="polite">
    <div class="teach-eyebrow">Teacher mode</div>
    <div class="teach-t" id="teachT">Teacher mode</div>
    <div class="teach-d" id="teachD">Hover any button or control and its plain-English explanation shows here.</div>
  </div>

  <!-- WORKBENCH (hidden until Shift+W) -->
  <div class="workbench" id="workbench" aria-hidden="true">
    <div class="wb-head">
      <span>
        <span class="wb-title">WORKBENCH</span>
        <span class="wb-version">BUILD <?php echo esc_html($smx_version); ?></span>
      </span>
      <button class="wb-close" id="wbClose" title="Close (Shift+W)">&times;</button>
    </div>

    <div class="wb-lock" id="wbLock">
      <div class="wb-lock-title">Workbench locked</div>
      <div class="wb-lock-note">Enter your deploy passkey to open the Workbench. It&rsquo;s remembered on this device, so you won&rsquo;t be asked again.</div>
      <input type="password" id="wbLockKey" class="wb-keyinput" placeholder="deploy passkey" autocomplete="current-password" style="margin-bottom:10px;">
      <button class="wb-deploy" id="wbLockBtn">UNLOCK</button>
      <div class="wb-note" id="wbLockMsg" style="min-height:14px;margin-top:10px;"></div>
    </div>

    <div class="wb-body">

      <div class="wb-tabs">
        <button class="wb-tab on" id="wbTabMixerBtn">Mixer</button>
        <button class="wb-tab" id="wbTabTrafficBtn">Traffic</button>
        <button class="wb-tab" id="wbTabLogBtn">Changelog</button>
      </div>

      <div class="wb-pane on" id="wbPaneMixer">
      <div class="wb-sec">Library</div>
      <input type="password" id="wbAddKey" class="wb-keyinput" placeholder="passkey" autocomplete="off" style="display:none;">
      <button class="wb-addsong" id="wbAddSong">+ Add a Song</button>
      <div class="wb-note" id="wbAddNote">Opens the uploader, already unlocked with your passkey &mdash; no need to re-enter it.</div>

      <div class="wb-sec">Mix Behavior</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Default fader level</span><b id="vDef">90%</b></div>
        <input type="range" id="sDef" min="50" max="100" step="5" value="90">
        <div class="wb-note">Where faders sit on song load, Reset, and when a &ldquo;&ndash;&rdquo; button restores the mix.</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Featured track level (+)</span><b id="vFeat">100%</b></div>
        <input type="range" id="sFeat" min="50" max="100" step="5" value="100">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Ducked tracks level (+)</span><b id="vDuck">50%</b></div>
        <input type="range" id="sDuck" min="10" max="90" step="5" value="50">
        <div class="wb-note">The level every non-featured track drops to when a &ldquo;+&rdquo; button is pressed. Adjust live while a feature is active to audition.</div>
      </div>

      <div class="wb-sec">Live Meters</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Meter animation</span></div>
        <div class="wb-toggle">
          <button class="wb-tbtn on" id="tMetOn">LIVE</button>
          <button class="wb-tbtn" id="tMetOff">STATIC</button>
        </div>
        <div class="wb-note">LIVE: LEDs follow each track's actual signal while playing (post-fader, like a real console). STATIC: LEDs show the fader position.</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Peak hold</span></div>
        <div class="wb-toggle">
          <button class="wb-tbtn on" id="tPkOn">ON</button>
          <button class="wb-tbtn" id="tPkOff">OFF</button>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Meter range</span><b id="vMet">48 dB</b></div>
        <input type="range" id="sMet" min="24" max="72" step="6" value="48">
        <div class="wb-note">The dB window the LEDs show. Narrower (24) = hotter, jumpier meters that only light on the loud stuff. Wider (72) = calmer meters that also show quiet detail.</div>
      </div>

      <div class="wb-sec">Fader Look</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Fader style</span></div>
        <div class="wb-toggle">
          <button class="wb-tbtn on" id="tLed">LED LADDER</button>
          <button class="wb-tbtn" id="tSolid">SOLID FILL</button>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>LED segment size</span><b id="vSeg">9px</b></div>
        <input type="range" id="sSeg" min="5" max="16" step="1" value="9">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Fader width</span><b id="vFaderW">30px</b></div>
        <input type="range" id="sFaderW" min="24" max="64" step="2" value="30">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Green zone up to</span><b id="vZ1">25%</b></div>
        <input type="range" id="sZ1" min="5" max="90" step="5" value="25">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Yellow zone up to</span><b id="vZ2">50%</b></div>
        <input type="range" id="sZ2" min="10" max="95" step="5" value="50">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Orange zone up to</span><b id="vZ3">75%</b></div>
        <input type="range" id="sZ3" min="15" max="100" step="5" value="75">
        <div class="wb-note">Red fills the rest, up to 100%.</div>
      </div>

      <div class="wb-sec">Design</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Accent color</span></div>
        <div class="wb-color">
          <input type="color" id="cAccent" value="#ef7d1c">
          <div class="wb-swatches">
            <button class="wb-sw" data-c="#ef7d1c" style="background:#ef7d1c" title="Orange (default)"></button>
            <button class="wb-sw" data-c="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-c="#f5c518" style="background:#f5c518" title="Amber"></button>
            <button class="wb-sw" data-c="#5571a3" style="background:#5571a3" title="Slate blue"></button>
            <button class="wb-sw" data-c="#37b24d" style="background:#37b24d" title="Green"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Logo width</span><b id="vLogo">100%</b></div>
        <input type="range" id="sLogo" min="40" max="100" step="5" value="100">
        <div class="wb-note">Relative to the mixer width.</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Playback bar height</span><b id="vScrub">30px</b></div>
        <input type="range" id="sScrub" min="6" max="40" step="2" value="30">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Playback bar color</span></div>
        <div class="wb-color">
          <input type="color" id="cScrub" value="#f5c518">
          <div class="wb-swatches">
            <button class="wb-sw" data-sc="#f5c518" style="background:#f5c518" title="Amber (default)"></button>
            <button class="wb-sw" data-sc="#ef7d1c" style="background:#ef7d1c" title="Orange"></button>
            <button class="wb-sw" data-sc="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-sc="#37b24d" style="background:#37b24d" title="Green"></button>
            <button class="wb-sw" data-sc="#5571a3" style="background:#5571a3" title="Slate blue"></button>
            <button class="wb-sw" data-sc="#e8e8ea" style="background:#e8e8ea" title="White"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Handle background</span></div>
        <div class="wb-color">
          <input type="color" id="cGripBg" value="#cdcfd6">
          <div class="wb-swatches">
            <button class="wb-sw" data-gb="#cdcfd6" style="background:#cdcfd6" title="Silver (default)"></button>
            <button class="wb-sw" data-gb="#ffffff" style="background:#ffffff" title="White"></button>
            <button class="wb-sw" data-gb="#2a2a33" style="background:#2a2a33" title="Charcoal"></button>
            <button class="wb-sw" data-gb="#ef7d1c" style="background:#ef7d1c" title="Orange"></button>
            <button class="wb-sw" data-gb="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-gb="#101014" style="background:#101014" title="Black"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Handle lines</span></div>
        <div class="wb-color">
          <input type="color" id="cGripLn" value="#5b5b62">
          <div class="wb-swatches">
            <button class="wb-sw" data-gl="#5b5b62" style="background:#5b5b62" title="Grey (default)"></button>
            <button class="wb-sw" data-gl="#141418" style="background:#141418" title="Near-black"></button>
            <button class="wb-sw" data-gl="#ffffff" style="background:#ffffff" title="White"></button>
            <button class="wb-sw" data-gl="#ef7d1c" style="background:#ef7d1c" title="Orange"></button>
            <button class="wb-sw" data-gl="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-gl="#f5c518" style="background:#f5c518" title="Amber"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Handle width</span><b id="vGripW">15px</b></div>
        <input type="range" id="sGripW" min="8" max="48" step="1" value="15">
        <div class="wb-note">The handle grows to the <b>left</b> as you widen it — its right edge stays pinned to the current playback position, so a wider handle never sits ahead of where the song actually is.</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>A/B marker color</span></div>
        <div class="wb-color">
          <input type="color" id="cLoop" value="#ef7d1c">
          <div class="wb-swatches">
            <button class="wb-sw" data-lc="#ef7d1c" style="background:#ef7d1c" title="Orange (default)"></button>
            <button class="wb-sw" data-lc="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-lc="#f5c518" style="background:#f5c518" title="Amber"></button>
            <button class="wb-sw" data-lc="#37b24d" style="background:#37b24d" title="Green"></button>
            <button class="wb-sw" data-lc="#3fa7ff" style="background:#3fa7ff" title="Blue"></button>
            <button class="wb-sw" data-lc="#e8e8ea" style="background:#e8e8ea" title="White"></button>
          </div>
        </div>
        <div class="wb-note">The A / B loop flags and the shaded loop region on the playback bar.</div>
      </div>

      <div class="wb-sec">Song Banner</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Left inset</span><b id="vNsL">18px</b></div>
        <input type="range" id="sNsL" min="0" max="80" step="2" value="18">
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Right inset</span><b id="vNsR">18px</b></div>
        <input type="range" id="sNsR" min="0" max="80" step="2" value="18">
      </div>

      <div class="wb-sec">Resources panel</div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Panel width</span><b id="vResW">420px</b></div>
        <input type="range" id="sResW" min="300" max="560" step="10" value="420">
        <div class="wb-note">Width of the open resources list (the &ldquo;Resources&rdquo; dropdown).</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Panel background</span></div>
        <div class="wb-color">
          <input type="color" id="cResBg" value="#2a2a34">
          <div class="wb-swatches">
            <button class="wb-sw" data-rb="#2a2a34" style="background:#2a2a34" title="Light charcoal (default)"></button>
            <button class="wb-sw" data-rb="#31313d" style="background:#31313d" title="Lighter"></button>
            <button class="wb-sw" data-rb="#1b1b21" style="background:#1b1b21" title="Dark (old)"></button>
            <button class="wb-sw" data-rb="#202027" style="background:#202027" title="Panel"></button>
            <button class="wb-sw" data-rb="#0f0f13" style="background:#0f0f13" title="Near-black"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Frame &amp; glow color</span></div>
        <div class="wb-color">
          <input type="color" id="cResBd" value="#ef7d1c">
          <div class="wb-swatches">
            <button class="wb-sw" data-rf="#ef7d1c" style="background:#ef7d1c" title="Orange (default)"></button>
            <button class="wb-sw" data-rf="#ed1c24" style="background:#ed1c24" title="MMN red"></button>
            <button class="wb-sw" data-rf="#f5c518" style="background:#f5c518" title="Amber"></button>
            <button class="wb-sw" data-rf="#37b24d" style="background:#37b24d" title="Green"></button>
            <button class="wb-sw" data-rf="#3fa7ff" style="background:#3fa7ff" title="Blue"></button>
            <button class="wb-sw" data-rf="#50505c" style="background:#50505c" title="Grey (no accent)"></button>
          </div>
        </div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Frame glow</span><b id="vResGlow">55%</b></div>
        <input type="range" id="sResGlow" min="0" max="100" step="5" value="55">
        <div class="wb-note">Strength of the soft colored glow around the panel (0 = flat, no glow).</div>
      </div>
      <div class="wb-row">
        <div class="wb-lbl"><span>Background dim</span><b id="vResScrim">55%</b></div>
        <input type="range" id="sResScrim" min="0" max="85" step="5" value="55">
        <div class="wb-note">How much the mixer behind the open list is dimmed. 0 turns the scrim off. Open the Resources list to preview.</div>
      </div>

      <div class="wb-sec">Beta / Preview</div>
      <input type="password" id="wbBetaKey" class="wb-keyinput" placeholder="passkey" autocomplete="off" style="display:none;">
      <button class="wb-deploy" id="wbBetaDevice" style="background:linear-gradient(180deg,#3a3a44,#2a2a30);border-color:var(--line2);color:var(--text);box-shadow:none;margin-bottom:12px;">PREVIEW NEW FEATURES ON THIS DEVICE</button>
      <div class="wb-betalist" id="wbBetaList"></div>
      <div class="wb-note" id="wbBetaNote">Tap Preview to try every pipeline feature on this browser only (the band still sees stable). When you&rsquo;re happy, tap a feature&rsquo;s <b>Publish to band</b> button — that <b>bakes it in permanently</b> for everyone and drops it off this list. Publishing is one-way, so vet each feature in Preview first.</div>

      <div class="wb-sec" style="margin-top:20px;">Deploy</div>
      <div class="wb-row" id="wbKeyRow" style="display:none;">
        <div class="wb-lbl"><span>Deploy passkey</span></div>
        <input type="password" id="wbKey" class="wb-keyinput" placeholder="enter passkey" autocomplete="off">
      </div>
      <button class="wb-deploy" id="wbDeploy">DEPLOY SETTINGS LIVE</button>
      <div class="wb-note" id="wbDeployNote">Publishes your current workbench settings as the site defaults — what every band member gets. Requires the deploy passkey (stored server-side in wp-content/stemmaxxer-key.php).</div>

      <button class="wb-reset" id="wbRebuild" style="margin-top:20px;">REBUILD AUDIO ENGINE</button>
      <div class="wb-note" style="margin:-8px 0 4px;">Rescue button if playback ever goes silent (e.g. after the Mac sleeps or headphones switch). Also appears automatically when the player detects trouble.</div>
      <button class="wb-reset" id="wbReset">RESET TO LIVE DEFAULTS</button>
      </div><!-- /wbPaneMixer -->

      <div class="wb-pane" id="wbPaneTraffic">
        <div class="wb-sec">Page Traffic</div>
        <div class="tr-note">A rough hit counter for this page &mdash; it should stay low (just your band practicing). If it spikes, the link may have spread beyond your group; change the band password under Settings &rarr; STEMMAXXER. Bots are skipped; a reload counts as a hit.</div>
        <div class="tr-tiles">
          <div class="tr-tile"><div class="tr-n" id="trToday">&ndash;</div><div class="tr-l">Today</div></div>
          <div class="tr-tile"><div class="tr-n" id="trYest">&ndash;</div><div class="tr-l">Yesterday</div></div>
          <div class="tr-tile"><div class="tr-n" id="tr7">&ndash;</div><div class="tr-l">Last 7 days</div></div>
          <div class="tr-tile"><div class="tr-n" id="tr30">&ndash;</div><div class="tr-l">Last 30 days</div></div>
        </div>
        <div class="tr-chart" id="trChart"></div>
        <div class="tr-axis"><span>30 days ago</span><span>today</span></div>
        <div class="tr-flag ok" id="trFlag">&nbsp;</div>
      </div>

      <div class="wb-pane" id="wbPaneLog">
        <div class="wb-sec">Changelog</div>
        <div class="cl-note">A high-level summary of every STEMMAXXER update, newest first.</div>
        <div class="cl-list" id="clList"></div>
      </div>

    </div>
    <div class="wb-foot">Settings are saved in this browser only.<br>Toggle: <b style="color:var(--orange)">SHIFT+W</b> &nbsp;·&nbsp; Close: <b style="color:var(--orange)">ESC</b></div>
  </div>

  <div class="desktop-only">
    <div class="dm-wm">STEMMA<span class="xx">XX</span>ER</div>
    <h2>OPTIMIZED FOR DESKTOP</h2>
    <p>The mixer is built for a larger screen. Please open STEMMAXXER on a desktop or laptop browser.</p>
    <button class="dm-continue" id="dmContinue" type="button">USE IT HERE ANYWAY</button>
    <div class="dm-note">A phone-native version is coming. For now this opens the full mixer on your phone &mdash; remembered on this device.</div>
  </div>

  <!-- ===================== STEMMAXXER LITE — mobile CONSOLE skin (v2.0.0) =====================
       Hidden unless <=900px AND the `mobile` beta feature is active (body.smx-mobile). -->
  <div id="smxLite" aria-hidden="true">
    <div class="lite-head">
      <span class="lite-wm">STEMMA<span class="xx">XX</span>ER</span>
      <span class="lite-chip">LITE</span>
      <span class="lite-ver">v<?php echo esc_html($smx_version); ?></span>
      <span class="lite-lock" aria-hidden="true">&#128274;</span>
    </div>
    <div id="liteLoad" aria-hidden="true"><div class="ll-inner"><div class="ll-label">LOADING</div><div class="ll-text"><span id="liteLoadCount">0 of 0</span> &middot; <span id="liteLoadPct">0%</span></div><div class="ll-bar"><div class="ll-fill" id="liteLoadFill"></div></div></div></div>
    <button class="lite-banner" id="liteBanner" type="button" aria-haspopup="listbox">
      <span class="lb-artist" id="liteArtist"></span>
      <span class="lb-title" id="liteTitle"></span>
      <span class="lb-caret" aria-hidden="true">&#9662;</span>
    </button>
    <div class="lite-sub">
      <span class="lite-bpm"><span id="liteBpm">&mdash;</span> <span>BPM</span></span>
      <span class="lite-hinttx">+ FOCUSES A PART &middot; DRAG = LEVEL</span>
    </div>
    <div class="lite-rows" id="liteRows"></div>
    <div class="lite-transport">
      <div class="lite-scrub" id="liteScrub"><div class="ls-region" id="liteRegion" style="display:none"></div><div class="ls-fill" id="liteFill"></div><span class="ls-flag a" id="liteFlagA" style="display:none">A</span><span class="ls-flag b" id="liteFlagB" style="display:none">B</span></div>
      <div class="lite-loopbar">
        <span class="llb-lbl">Loop</span>
        <button class="llb-btn" id="liteLoopA" type="button" title="Set loop start">A</button>
        <button class="llb-btn" id="liteLoopB" type="button" title="Set loop end">B</button>
        <button class="llb-btn" id="liteLoopToggle" type="button" title="Loop on/off">&#8635; LOOP</button>
        <button class="llb-btn clr" id="liteLoopClear" type="button" aria-label="Clear loop">&times;</button>
      </div>
      <div class="lite-time"><span id="liteElapsed">0:00</span><span id="liteTotal">0:00</span></div>
      <div class="lite-tbtns">
        <button class="lt-aux" id="liteRestart" type="button" aria-label="Restart song" title="Restart"><svg width="19" height="16" viewBox="0 0 19 16" fill="currentColor" aria-hidden="true"><rect x="2" y="1" width="3" height="14" rx="1"/><path d="M17 1 L7 8 L17 15 Z"/></svg></button>
        <button class="lt-skip" id="liteBack" type="button" aria-label="Back 10 seconds"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M15 9a6 6 0 1 1-1.8-4.2"/><path d="M14 2 L14 5.2 L10.8 5.2" stroke-linecap="round" stroke-linejoin="round"/></svg>10</button>
        <button class="lt-play" id="litePlay" type="button" aria-label="Play or pause">
          <svg id="litePlayIco" width="26" height="30" viewBox="0 0 26 30"><path d="M2 2 L24 15 L2 28 Z" fill="currentColor"/></svg>
          <svg id="litePauseIco" width="22" height="26" viewBox="0 0 22 26" style="display:none"><rect x="2" y="1" width="6" height="24" fill="currentColor"/><rect x="14" y="1" width="6" height="24" fill="currentColor"/></svg>
        </button>
        <button class="lt-skip" id="liteFwd" type="button" aria-label="Forward 10 seconds"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M3 9a6 6 0 1 0 1.8-4.2"/><path d="M4 2 L4 5.2 L7.2 5.2" stroke-linecap="round" stroke-linejoin="round"/></svg>10</button>
        <button class="lt-aux" id="liteReset" type="button" aria-label="Reset the mix" title="Reset"><svg width="22" height="20" viewBox="0 0 22 20" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><line x1="4" y1="3" x2="4" y2="17" stroke-linecap="round"/><line x1="11" y1="3" x2="11" y2="17" stroke-linecap="round"/><line x1="18" y1="3" x2="18" y2="17" stroke-linecap="round"/><line x1="2" y1="12.5" x2="20" y2="12.5" stroke-dasharray="1.5 1.6" opacity=".55"/><rect x="2" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/><rect x="9" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/><rect x="16" y="11" width="4" height="3" rx="1" fill="currentColor" stroke="none"/></svg></button>
      </div>
      <div class="lite-chips">
        <span class="lite-speed"><button class="ls-btn" id="liteSpeedDown" type="button" aria-label="Slower">&minus;</button><span class="ls-val" id="liteSpeedVal">SPEED 100%</span><button class="ls-btn" id="liteSpeedUp" type="button" aria-label="Faster">+</button></span>
        <button class="lchip" id="liteCountin" type="button">COUNT-IN</button>
        <button class="lchip" id="liteClick" type="button">CLICK</button>
      </div>
    </div>
  </div>
  <div class="lite-sheet" id="liteSheet">
    <div class="ls-head"><h3>Songs</h3><button class="ls-close" id="liteSheetClose" type="button" aria-label="Close">&times;</button></div>
    <div class="ls-list" id="liteSheetList"></div>
  </div>

<script>
(function () {
  "use strict";

  /* ---------- Mobile bypass (temporary, pre-LITE) ----------
   * The <900px "Optimized for desktop" overlay can be tapped through to
   * the full mixer; the choice is remembered per device. Lets phone users
   * (and Chris, testing the iOS Silent-Mode fix) reach the mixer. When
   * LITE ships (v2.0.0) this whole overlay is replaced by the mobile UI. */
  (function mobileBypass(){
    var KEY = 'smx-mobile-ok';
    try { if (localStorage.getItem(KEY) === '1') document.body.classList.add('smx-mobile-ok'); } catch (_) {}
    var b = document.getElementById('dmContinue');
    if (b) b.addEventListener('click', function () {
      document.body.classList.add('smx-mobile-ok');
      try { localStorage.setItem(KEY, '1'); } catch (_) {}
    });
  })();

  /* ============================================================
   * SONG DATA — injected by WordPress from the media-library scan.
   * ============================================================ */
  var SONGS = <?php echo $smx_songs_json; ?> || [];
  // Deployed (site-wide default) workbench settings + passkey-gated deploy endpoint
  var WB_LIVE   = <?php echo isset($smx_wb_live_json) ? $smx_wb_live_json : '{}'; ?> || {};
  var SMX_AJAX  = <?php echo isset($smx_ajax_url_json) ? $smx_ajax_url_json : '""'; ?>;
  var SMX_NONCE = <?php echo isset($smx_nonce_json) ? $smx_nonce_json : '""'; ?>;
  // Song resources (per-song labeled links) — add/remove nonce + whether this
  // visitor is band-authed (can add). Delete tokens for a device's own band adds.
  var SMX_RES_NONCE = <?php echo isset($smx_res_nonce_json) ? $smx_res_nonce_json : '""'; ?>;
  var SMX_BAND_AUTH = <?php echo isset($smx_band_auth_json) ? $smx_band_auth_json : 'false'; ?>;
  var SMX_FB_NONCE  = <?php echo isset($smx_fb_nonce_json) ? $smx_fb_nonce_json : '""'; ?>;
  var SMX_VERSION   = <?php echo isset($smx_version) ? wp_json_encode($smx_version) : '""'; ?>;
  var SMX_COVER     = <?php echo isset($smx_cover_url) ? wp_json_encode($smx_cover_url) : '""'; ?>;      // 1024² lock-screen art
  var SMX_COVER_512 = <?php echo isset($smx_cover_512_url) ? wp_json_encode($smx_cover_512_url) : '""'; ?>; // 512² variant

  var root = document.getElementById('app');
  if (!root) return;

  function $(id){ return document.getElementById(id); }

  /* ---------- Beta / preview channel (per-feature) ----------
   * Beta features are hidden from the band by default. Each feature has its own
   * KEY and can be published to the band INDEPENDENTLY, so one polished feature
   * can go live while another is still being worked on.
   * A feature shows for a given viewer when EITHER this device has opted into
   * preview (localStorage — Chris sees every pipeline feature) OR that specific
   * feature key is in the server-published set (SMX_PUBLISHED).
   *
   * Single source of truth for the pipeline. Each entry needs a unique `key`
   * that matches the feature's markup class `bf-<key>` (e.g. bf-loop).
   * When a feature graduates to permanent-for-everyone, remove it here AND drop
   * the bf-<key> gating class from its markup. */
  // A/B looping graduated to permanent (always-on for everyone) in v1.14.10 —
  // it no longer lives here and its markup no longer carries the bf-loop class.
  var BETA_FEATURES = [
    { key: 'bannersel', title: 'Band/song banner selector', desc: 'The big BAND — TITLE banner becomes the song picker (click it or press Enter; type to jump). The animated EQ is removed, the title fills the width, and the whole banner reads as a subtle orange-lined field with an orange dropdown arrow. The transport’s own dropdown is removed and the master volume stretches to fill the space.' },
    { key: 'resources', title: 'Per-song resources', desc: 'Each song can carry as many labeled links as you want — tabs, chords, guitar/drum video lessons, a reference mix. Right beside the song title they collapse into one “Resources ▾” button (a single link shows as one direct button). Bandmates who’ve passed the password can add their own finds with “+ Add” and remove ones they added; you manage the full list in Settings → STEMMAXXER. Your existing Charts / Lesson links migrate in automatically.' },
    { key: 'mobile', title: 'Mobile view (LITE)', desc: 'On phones (screens under 900px) STEMMAXXER shows a finger-friendly mixer &mdash; the CONSOLE view &mdash; instead of the &ldquo;open on desktop&rdquo; screen. Big touch faders, mute/solo, tap a stem name to FOCUS it (that part up, the rest ducked), plus loop, speed and count-in/click as one-tap chips. Same songs, same engine. This is the first LITE skin; the PADS view and a skin picker come next.' }
  ];
  var SMX_PUBLISHED = <?php echo isset($smx_published_json) ? $smx_published_json : '[]'; ?> || [];
  var SMX_STATS = <?php echo isset($smx_stats_json) ? $smx_stats_json : '{"days":[],"total":0}'; ?> || {days:[],total:0};
  var SMX_KEY_SET = <?php echo isset($smx_key_set_json) ? $smx_key_set_json : 'false'; ?>; // is the Workbench passkey-gated?
  function deviceBeta(){ try { return localStorage.getItem('smx-beta') === '1'; } catch (_) { return false; } }
  function isPublished(key){ return SMX_PUBLISHED.indexOf(key) >= 0; }
  function featureShown(key){ return deviceBeta() || isPublished(key); }
  function betaOn(){ return deviceBeta() || SMX_PUBLISHED.length > 0; } // any beta context active
  // Emit one hide-rule per feature so each shows only when its own show-<key> class is present.
  (function injectFeatureCSS(){
    var css = '';
    for (var i = 0; i < BETA_FEATURES.length; i++) {
      var k = BETA_FEATURES[i].key;
      css += '.stemmaxxer:not(.show-' + k + ') .bf-' + k + '{display:none !important;}';
    }
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
  })();
  function applyBeta(){
    root.classList.toggle('beta-on', deviceBeta()); // legacy global (device preview shows everything)
    for (var i = 0; i < BETA_FEATURES.length; i++) {
      var k = BETA_FEATURES[i].key, shown = featureShown(k);
      root.classList.toggle('show-' + k, shown);
      // Mirror onto <body> so features whose markup lives OUTSIDE .stemmaxxer
      // (e.g. the song banner) can gate on body.smx-<key>.
      document.body.classList.toggle('smx-' + k, shown);
    }
    setBannerSelMode(featureShown('bannersel'));
  }
  // Relocate the shared dropdown list so it anchors under whichever selector is
  // active: the transport button (#dropdown) normally, or the banner in beta mode.
  function setBannerSelMode(on){
    var list = document.getElementById('ddList'),
        home = document.getElementById('dropdown'),
        banner = document.getElementById('nowsong');
    if (!list || !home || !banner) return;
    if (on) { if (list.parentNode !== banner) banner.appendChild(list); }
    else { if (list.parentNode !== home) home.appendChild(list); }
  }
  applyBeta();

  function renderBetaList(){
    var box = document.getElementById('wbBetaList');
    if (!box) return;
    // Split the pipeline: still-toggleable (not yet published) vs. baked-in
    // (published live to the band — permanent, no longer hideable).
    var pending = [], baked = [];
    for (var i = 0; i < BETA_FEATURES.length; i++) {
      (isPublished(BETA_FEATURES[i].key) ? baked : pending).push(BETA_FEATURES[i]);
    }
    var html = '';
    if (!pending.length) {
      html += '<div class="bl-empty">No new features to publish right now.</div>';
    } else {
      for (var j = 0; j < pending.length; j++) {
        var f = pending[j];
        var badge = deviceBeta()
          ? '<span class="bl-badge hidden">Preview only</span>'
          : '<span class="bl-badge">Not published</span>';
        html += '<div class="bl-item">'
              +   '<div class="bl-head"><div class="bl-title">' + f.title + '</div>' + badge + '</div>'
              +   '<div class="bl-desc">' + f.desc + '</div>'
              +   '<button class="bl-pub" data-feat="' + f.key + '" data-live="1">PUBLISH TO BAND</button>'
              + '</div>';
      }
    }
    // Read-only summary of features that have been baked in (published permanently).
    if (baked.length) {
      var names = baked.map(function (b) { return b.title; }).join(' · ');
      html += '<div class="bl-baked">&#10003; Baked in &amp; live for the band: <b>' + names + '</b>. '
            +   'Publishing is permanent &mdash; these are no longer hideable here.</div>';
    }
    box.innerHTML = html;
  }
  renderBetaList();
  var mixerEl   = $('mixer'),
      playBtn   = $('btnPlay'), icoPlay = $('icoPlay'), icoPause = $('icoPause'),
      tElapsed  = $('tElapsed'), tTotal = $('tTotal'),
      scrubber  = $('scrubber'), progress = $('progress'),
      statusEl  = $('status'), statusName = $('statusName'), statusMsg = $('statusMsg'),
      loadCount = $('loadCount'), loadPct = $('loadPct'), loadFill = $('loadFill'),
      hintEl    = $('hint'),
      ddWrap    = $('dropdown'), ddButton = $('ddButton'), ddSong = $('ddSong'), ddList = $('ddList'),
      wbEl      = $('workbench');

  /* ============================================================
   * WORKBENCH SETTINGS — persisted in localStorage
   * ============================================================ */
  var WB_FACTORY = {
    defLevel: 90,      // default fader level %
    featLevel: 100,    // featured track level on "+"
    duckLevel: 50,     // everything else on "+"
    faderStyle: 'led', // 'led' | 'solid'
    seg: 9,            // LED segment pitch px
    faderW: 30,        // fader / LED track width px
    z1: 25, z2: 50, z3: 75, // color zone boundaries %
    accent: '#ef7d1c',
    logoW: 100,        // % of mixer width
    meters: true,      // live LED metering while playing
    peakHold: true,    // peak-hold marker on live meters
    meterDb: 48,       // meter range: dB window mapped onto the ladder
    scrubH: 30,        // playback bar height px
    scrubC: '#f5c518', // playback bar color
    gripBg: '#cdcfd6', // playback-bar handle background
    gripLines: '#5b5b62', // playback-bar handle hamburger lines
    gripW: 15,         // playback-bar handle width px (grows leftward)
    loopC: '#ef7d1c',  // A/B loop markers + region color on the playback bar
    nsL: 18,           // banner left inset px
    nsR: 18,           // banner right inset px
    nsGap: 50,         // gap between song title and pattern px
    nsH: 34,           // pattern bar height px
    resW: 420,         // Resources dropdown width px
    resBg: '#2a2a34',  // Resources dropdown background (lighter surface)
    resBd: '#ef7d1c',  // Resources dropdown frame / glow color
    resGlow: 55,       // Resources frame glow strength %
    resScrim: 55       // Resources backdrop dim % (0 = no scrim)
  };
  // Precedence: your local tweaks > deployed live settings > factory
  var WB = (function () {
    var s = {};
    try { s = JSON.parse(localStorage.getItem('smx-workbench') || '{}'); } catch (_) {}
    var out = {};
    for (var k in WB_FACTORY) {
      out[k] = (s[k] !== undefined) ? s[k]
             : (WB_LIVE[k] !== undefined) ? WB_LIVE[k]
             : WB_FACTORY[k];
    }
    return out;
  })();
  var wbSuppressSave = false; // true during init/reset so merely LOADING the page never freezes settings locally
  function wbSave() {
    if (wbSuppressSave) return;
    try { localStorage.setItem('smx-workbench', JSON.stringify(WB)); } catch (_) {}
  }
  function wbApplyVisual() {
    var d = document.documentElement.style;
    // Keep zones ordered
    if (WB.z2 <= WB.z1) WB.z2 = Math.min(95, WB.z1 + 5);
    if (WB.z3 <= WB.z2) WB.z3 = Math.min(100, WB.z2 + 5);
    d.setProperty('--z1', WB.z1 + '%');
    d.setProperty('--z2', WB.z2 + '%');
    d.setProperty('--z3', WB.z3 + '%');
    d.setProperty('--seg', WB.seg + 'px');
    d.setProperty('--fader-w', WB.faderW + 'px');
    d.setProperty('--orange', WB.accent);
    d.setProperty('--logo-w', WB.logoW + '%');
    d.setProperty('--scrub-h', WB.scrubH + 'px');
    d.setProperty('--scrub-c', WB.scrubC);
    d.setProperty('--grip-bg', WB.gripBg);
    d.setProperty('--grip-lines', WB.gripLines);
    d.setProperty('--grip-w', WB.gripW + 'px');
    d.setProperty('--loop-c', WB.loopC);
    d.setProperty('--ns-l', WB.nsL + 'px');
    d.setProperty('--ns-r', WB.nsR + 'px');
    d.setProperty('--ns-gap', WB.nsGap + 'px');
    d.setProperty('--ns-h', WB.nsH + 'px');
    d.setProperty('--res-w', WB.resW + 'px');
    d.setProperty('--res-bg', WB.resBg);
    d.setProperty('--res-bd', WB.resBd);
    d.setProperty('--res-glow', WB.resGlow + '%');
    d.setProperty('--res-scrim', (WB.resScrim / 100));
    nsColorsDirty = true; // zone-threshold changes re-tint the banner EQ
    document.body.classList.toggle('smx-solid', WB.faderStyle === 'solid');
    tracks.forEach(renderFader);
  }

  /* ============================================================
   * AUDIO ENGINE — ported from V1 (sample-accurate Web Audio)
   * ============================================================ */
  var ctx = null, unlocked = false;
  var masterGain = null, masterAnalyser = null;
  var masterVol = (function () {
    try {
      var v = parseFloat(sessionStorage.getItem('smx-master'));
      if (!isNaN(v) && v >= 0 && v <= 1) return v;
    } catch (_) {}
    return 1;
  })();

  /* ---------- iOS Silent-Mode fix (v1.14.34) ----------
   * iOS silences Web Audio API output while the ring/silent switch (or
   * Action-button Silent Mode) is on, even though ordinary <audio>
   * elements play through — discovered the hard way in V1 beta ("The
   * iOS playback mystery"). Two layers, both harmless elsewhere:
   *   1) Audio Session API — the sanctioned fix: declaring the page
   *      'playback' tells iOS this is media playback, the category that
   *      ignores the switch (newer Safaris).
   *   2) Silent keep-alive <audio> loop — the proven fallback (unmute.js
   *      pattern): while a looping silent media element plays, iOS
   *      reclassifies the page as media playback and un-mutes Web Audio
   *      on versions that lack (1).
   * Both engage on the SAME first user gesture that already unlocks the
   * engine, so autoplay policy is respected. Neither touches the audio
   * graph — inter-stem sync is unaffected. */
  var IS_IOS = /iP(hone|od|ad)/.test(navigator.platform || '') ||
               (/Mac/.test(navigator.platform || '') && (navigator.maxTouchPoints || 0) > 1);
  function applyAudioSessionType() {
    try {
      if (navigator.audioSession && 'type' in navigator.audioSession &&
          navigator.audioSession.type !== 'playback') {
        navigator.audioSession.type = 'playback';
      }
    } catch (_) {}
  }
  applyAudioSessionType(); // no-op outside WebKit
  var SMX_SILENCE = 'data:audio/wav;base64,UklGRsQPAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YaAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
  var keepAlive = null;
  function startKeepAlive() {
    if (!IS_IOS) return;
    try {
      if (!keepAlive) {
        keepAlive = document.createElement('audio');
        keepAlive.id = 'smxKeepAlive';
        keepAlive.src = SMX_SILENCE;
        keepAlive.loop = true;
        keepAlive.setAttribute('playsinline', '');
        keepAlive.style.display = 'none';
        document.body.appendChild(keepAlive);
      }
      var p = keepAlive.play();
      if (p && p.catch) p.catch(function () {});
    } catch (_) {}
  }

  /* ---------- Lock-screen "Now Playing" (Media Session API) ----------
   * The looping keep-alive <audio> above makes iOS/Android surface a
   * Now-Playing widget on the lock screen. With no metadata the OS falls
   * back to the page favicon (the low-res site icon Chris saw). We hand it
   * the STEMMAXXER album cover + the current song's title/artist, keep the
   * play/pause state honest, and point the widget's transport buttons at the
   * real engine. Purely additive — never touches the audio graph, so the
   * silent-switch fix is unaffected. */
  var smxMediaWired = false;
  function smxMediaArtwork() {
    var a = [];
    if (SMX_COVER)     a.push({ src: SMX_COVER,     sizes: '1024x1024', type: 'image/png' });
    if (SMX_COVER_512) a.push({ src: SMX_COVER_512, sizes: '512x512',   type: 'image/png' });
    return a;
  }
  function smxMediaMeta(song) {
    if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title:  (song && song.title)  ? song.title  : 'STEMMAXXER',
        artist: (song && song.artist) ? song.artist : '',
        album:  'STEMMAXXER',
        artwork: smxMediaArtwork()
      });
    } catch (_) {}
    smxMediaWire();
  }
  function smxMediaState(on) {
    if (!('mediaSession' in navigator)) return;
    try { navigator.mediaSession.playbackState = on ? 'playing' : 'paused'; } catch (_) {}
  }
  function smxMediaPos() {
    if (!('mediaSession' in navigator) || !navigator.mediaSession.setPositionState) return;
    if (!duration || !isFinite(duration)) return;
    try {
      var pos = Math.max(0, Math.min(duration, currentPlayhead()));
      navigator.mediaSession.setPositionState({ duration: duration, playbackRate: rate || 1, position: pos });
    } catch (_) {}
  }
  function smxMediaWire() {
    if (smxMediaWired || !('mediaSession' in navigator)) return;
    var set = function (action, fn) { try { navigator.mediaSession.setActionHandler(action, fn); } catch (_) {} };
    set('play',          function () { if (!playing) { ensureContext(); togglePlay(); } });
    set('pause',         function () { if (playing) togglePlay(); });
    set('previoustrack', function () { ensureContext(); var b = $('btnRestart'); if (b) b.click(); });
    set('seekbackward',  function (d) { seekTo(currentPlayhead() - ((d && d.seekOffset) || 10)); });
    set('seekforward',   function (d) { seekTo(currentPlayhead() + ((d && d.seekOffset) || 10)); });
    set('seekto',        function (d) { if (d && typeof d.seekTime === 'number') seekTo(d.seekTime); });
    smxMediaWired = true;
  }

  function ensureContext() {
    if (!ctx) {
      var Ctor = window.AudioContext || window.webkitAudioContext;
      if (!Ctor) return null;
      ctx = new Ctor();
      masterGain = ctx.createGain();          // master bus: every stem feeds this
      masterGain.gain.value = masterVol;
      masterGain.connect(ctx.destination);
      masterAnalyser = ctx.createAnalyser();  // feeds the banner EQ visualization
      masterAnalyser.fftSize = 256;
      masterAnalyser.smoothingTimeConstant = 0.72;
      masterGain.connect(masterAnalyser);
    }
    if (ctx.state === 'suspended') { ctx.resume().catch(function(){}); }
    return ctx;
  }

  function unlockAudioOnFirstGesture() {
    if (unlocked) return;
    var audioCtx = ensureContext();
    if (!audioCtx) return;
    try {
      var silent = audioCtx.createBuffer(1, 1, 22050);
      var src = audioCtx.createBufferSource();
      src.buffer = silent;
      src.connect(audioCtx.destination);
      src.start(0);
    } catch (_) {}
    applyAudioSessionType(); // some WebKit builds apply the type at session activation
    startKeepAlive();        // iOS only; reuses the same element on re-unlock
    unlocked = true;
  }
  (function bindAudioUnlock() {
    var handler = function () {
      unlockAudioOnFirstGesture();
      document.removeEventListener('touchend', handler);
      document.removeEventListener('mousedown', handler);
      document.removeEventListener('keydown', handler);
    };
    document.addEventListener('touchend', handler, { passive: true });
    document.addEventListener('mousedown', handler);
    document.addEventListener('keydown', handler);
  })();

  var tracks = [];
  var duration = 0;
  var playing = false;
  var playStartCtxTime = 0, playStartOffset = 0, pausedOffset = 0;
  var tickHandle = null;
  var loopEnabled = false, loopA = null, loopB = null; // A/B section loop (beta)
  var loadToken = 0;
  var activeFeature = null; // stem name | null

  /* ---------- Playback speed (pitch-preserved) ----------
   * At 100% the live Web Audio engine runs untouched. Below 100%, the
   * current mix (faders + mute/solo baked in) is rendered offline to a
   * single stream and played through an <audio> element with
   * preservesPitch — the browser's native time-stretcher (same tech as
   * YouTube's speed control). One stream = stems can never drift apart.
   * Any mixer change while slowed triggers a debounced re-render. */
  var rate = 1;
  var stretch = { audio: null, url: null, timer: null, token: 0, building: false };
  function stretchActive() { return rate < 0.999; }

  function iconsPlaying(on) {
    icoPlay.style.display = on ? 'none' : 'block';
    icoPause.style.display = on ? 'block' : 'none';
  }

  function bufferToWav(buf) { // AudioBuffer → 16-bit PCM WAV Blob
    var nCh = Math.min(2, buf.numberOfChannels), sr = buf.sampleRate, n = buf.length;
    var bytes = 44 + n * nCh * 2;
    var ab = new ArrayBuffer(bytes), dv = new DataView(ab);
    function ws(o, s) { for (var i = 0; i < s.length; i++) dv.setUint8(o + i, s.charCodeAt(i)); }
    ws(0, 'RIFF'); dv.setUint32(4, bytes - 8, true); ws(8, 'WAVE'); ws(12, 'fmt ');
    dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, nCh, true);
    dv.setUint32(24, sr, true); dv.setUint32(28, sr * nCh * 2, true);
    dv.setUint16(32, nCh * 2, true); dv.setUint16(34, 16, true);
    ws(36, 'data'); dv.setUint32(40, n * nCh * 2, true);
    var chans = [];
    for (var c = 0; c < nCh; c++) chans.push(buf.getChannelData(c));
    var o = 44;
    for (var i = 0; i < n; i++) {
      for (c = 0; c < nCh; c++) {
        var v = Math.max(-1, Math.min(1, chans[c][i]));
        dv.setInt16(o, v < 0 ? v * 32768 : v * 32767, true);
        o += 2;
      }
    }
    return new Blob([ab], { type: 'audio/wav' });
  }

  function onStretchEnded() {
    playing = false;
    iconsPlaying(false);
    pausedOffset = 0;
    if (stretch.audio) { try { stretch.audio.currentTime = 0; } catch (_) {} }
    progress.style.width = '0%';
    tElapsed.textContent = '0:00';
    setStatus('ready', 'speed ' + Math.round(rate * 100) + '%');
  }

  function teardownStretch() {
    stretch.token++;
    if (stretch.timer) { clearTimeout(stretch.timer); stretch.timer = null; }
    if (stretch.audio) { try { stretch.audio.pause(); } catch (_) {} }
    if (stretch.url) { URL.revokeObjectURL(stretch.url); stretch.url = null; }
    if (stretch.audio) { stretch.audio.removeAttribute('src'); }
    stretch.building = false;
  }

  function rebuildStretchMix(pos, resume) {
    var ready = loadedTracks();
    if (!ready.length || duration <= 0) return;
    var myTok = ++stretch.token;
    stretch.building = true;
    setStatus('loading', 'rebuilding mix…');
    var sr = (ctx && ctx.sampleRate) || 44100;
    var off = new OfflineAudioContext(2, Math.ceil(duration * sr), sr);
    var anySolo = tracks.some(function (t) { return t.soloed && !t.failed; });
    ready.forEach(function (t) {
      var audible = !t.muted && (anySolo ? t.soloed : true);
      var g = off.createGain();
      g.gain.value = audible ? t.fader : 0;
      var s = off.createBufferSource();
      s.buffer = t.buffer;
      s.connect(g);
      g.connect(off.destination);
      s.start(0);
    });
    off.startRendering().then(function (mix) {
      if (myTok !== stretch.token) return;
      // Coarse energy envelope (20 frames/sec) so the banner EQ can dance in slowed mode
      (function () {
        var chd = mix.getChannelData(0), envRate = 20;
        var hop = Math.floor(mix.sampleRate / envRate);
        var frames = Math.max(1, Math.floor(chd.length / hop));
        var env = new Float32Array(frames), peak = 0;
        for (var fi = 0; fi < frames; fi++) {
          var s = 0, o = fi * hop;
          for (var j = 0; j < hop; j += 4) { var v = chd[o + j]; s += v * v; }
          env[fi] = Math.sqrt(s / (hop / 4));
          if (env[fi] > peak) peak = env[fi];
        }
        if (peak > 0) for (fi = 0; fi < frames; fi++) env[fi] /= peak; // normalize 0..1
        stretch.env = env;
        stretch.envRate = envRate;
      })();
      var blob = bufferToWav(mix);
      if (stretch.url) URL.revokeObjectURL(stretch.url);
      stretch.url = URL.createObjectURL(blob);
      var a = stretch.audio;
      if (!a) {
        a = new Audio();
        a.preload = 'auto';
        a.addEventListener('ended', onStretchEnded);
        stretch.audio = a;
      }
      var onReady = function () {
        a.removeEventListener('canplaythrough', onReady);
        if (myTok !== stretch.token) return;
        try { a.preservesPitch = true; } catch (_) {}
        try { a.webkitPreservesPitch = true; } catch (_) {}
        a.playbackRate = rate;
        a.volume = masterVol; // master volume applies live in slowed mode too
        try { a.currentTime = Math.max(0, Math.min(pos, duration - 0.05)); } catch (_) {}
        stretch.building = false;
        setStatus('ready', 'speed ' + Math.round(rate * 100) + '%');
        if (resume) {
          a.play().catch(function () {});
          playing = true;
          iconsPlaying(true);
        } else {
          playing = false;
          iconsPlaying(false);
        }
        tick();
      };
      a.addEventListener('canplaythrough', onReady);
      try { a.preservesPitch = true; } catch (_) {}
      try { a.webkitPreservesPitch = true; } catch (_) {}
      a.src = stretch.url;
      a.load();
    }).catch(function (e) {
      if (myTok !== stretch.token) return;
      stretch.building = false;
      setStatus('error', 'mix render failed');
      if (window.console) console.error('Offline mix render failed:', e);
    });
  }

  function markStretchDirty() {
    if (!stretchActive() || !loadedTracks().length) return;
    if (stretch.timer) clearTimeout(stretch.timer);
    stretch.timer = setTimeout(function () {
      stretch.timer = null;
      if (!stretchActive()) return;
      var pos = currentPlayhead();
      var wasPlaying = playing;
      if (stretch.audio) { try { stretch.audio.pause(); } catch (_) {} }
      playing = false;
      iconsPlaying(false);
      rebuildStretchMix(pos, wasPlaying);
    }, 400);
  }

  var SPEEDS = [1, 0.9, 0.8, 0.75, 0.7, 0.6, 0.5];
  function setRate(r) {
    if (Math.abs(r - rate) < 0.001) return;
    var pos = currentPlayhead();
    var wasPlaying = playing;
    var wasStretch = stretchActive();
    rate = r;
    $('speedVal').textContent = Math.round(r * 100) + '%';
    renderBpm();
    buildSpeedMenu();
    if (!stretchActive()) {
      // Back to the live sample-accurate engine
      teardownStretch();
      playing = false;
      iconsPlaying(false);
      pausedOffset = pos;
      setStatus('ready', 'speed 100%');
      if (wasPlaying) startPlayback(pos); else tick();
    } else if (wasStretch && stretch.audio && !stretch.building) {
      // Already stretched: just change the element's rate — no re-render needed
      stretch.audio.playbackRate = rate;
      setStatus('ready', 'speed ' + Math.round(rate * 100) + '%');
    } else if (!wasStretch) {
      // Entering stretch mode from the live engine
      stopAllSources();
      playing = false;
      iconsPlaying(false);
      pausedOffset = pos;
      rebuildStretchMix(pos, wasPlaying);
    }
  }

  function buildSpeedMenu() {
    var list = $('speedList');
    list.innerHTML = '';
    SPEEDS.forEach(function (s) {
      var it = document.createElement('button');
      it.className = 'speed-item' + (Math.abs(s - rate) < 0.001 ? ' sel' : '');
      it.textContent = Math.round(s * 100) + '%';
      it.addEventListener('click', function (e) {
        e.stopPropagation();
        $('speedWrap').classList.remove('open');
        setRate(s);
        it.blur();
      });
      list.appendChild(it);
    });
  }
  $('speedBtn').addEventListener('click', function (e) {
    e.stopPropagation();
    buildSpeedMenu();
    $('speedWrap').classList.toggle('open');
    this.blur();
  });
  document.addEventListener('click', function () { $('speedWrap').classList.remove('open'); });

  /* ---------- BPM: auto-detect from the drums stem (admin can override) ----------
   * Onset-strength autocorrelation over the middle of the song. Isolated
   * drums make this far more reliable than analyzing a full mix. */
  var songBpm = null; // number | null
  function detectBPM(buffer) {
    try {
      var srr = buffer.sampleRate, ch = buffer.getChannelData(0), hop = 512;
      var totalF = Math.floor(ch.length / hop);
      var maxF = Math.floor(60 * srr / hop);
      var startF = Math.max(0, Math.floor((totalF - maxF) / 2));
      var n = Math.min(totalF, startF + maxF) - startF;
      if (n < 400) return null;
      var energy = new Float32Array(n);
      for (var f = 0; f < n; f++) {
        var off = (startF + f) * hop, sum = 0;
        for (var j = 0; j < hop; j++) { var v = ch[off + j]; sum += v * v; }
        energy[f] = Math.sqrt(sum / hop);
      }
      var onset = new Float32Array(n), mean = 0;
      for (f = 1; f < n; f++) { var d = energy[f] - energy[f - 1]; onset[f] = d > 0 ? d : 0; mean += onset[f]; }
      mean /= n;
      for (f = 0; f < n; f++) onset[f] -= mean;
      var fps = srr / hop, best = -Infinity, bestBpm = null;
      for (var bpm = 60; bpm <= 200; bpm += 0.5) {
        var li = Math.round(fps * 60 / bpm);
        if (li < 2 || li >= n / 2) continue;
        var ac = 0, count = n - li;
        for (f = 0; f < count; f++) ac += onset[f] * onset[f + li];
        ac /= count;
        var prior = Math.exp(-Math.pow((bpm - 130) / 60, 2)); // gentle rock-tempo prior
        var score = ac * prior;
        if (score > best) { best = score; bestBpm = bpm; }
      }
      if (bestBpm === null || best <= 0) return null;
      return Math.round(bestBpm);
    } catch (_) { return null; }
  }
  function analyzeBpmForSong(myToken) {
    var song = SONGS[currentSongIdx];
    if (song && typeof song.bpm === 'number' && song.bpm > 0) {
      songBpm = song.bpm;
      renderBpm();
      return;
    }
    setTimeout(function () {
      if (myToken !== loadToken) return;
      var src = null;
      for (var i = 0; i < tracks.length; i++) {
        if (tracks[i].buffer && /drum/i.test(tracks[i].name)) { src = tracks[i].buffer; break; }
      }
      if (!src) {
        for (i = 0; i < tracks.length; i++) {
          if (tracks[i].buffer && !isCountIn(tracks[i].name)) { src = tracks[i].buffer; break; }
        }
      }
      var bpm = src ? detectBPM(src) : null;
      if (myToken !== loadToken) return;
      songBpm = bpm;
      renderBpm();
    }, 60);
  }
  function renderBpm() {
    var el = $('bpmVal');
    if (!songBpm) { el.textContent = '—'; return; }
    var base = Math.round(songBpm);
    el.textContent = stretchActive() ? (base + ' → ' + Math.round(songBpm * rate)) : String(base);
  }

  /* ---------- AUDIO RESCUE (manual, Workbench-only) ----------
   * Chrome on macOS can lose its audio pipeline after sleep/wake or an
   * output-device change: the graph keeps rendering but nothing reaches
   * the speakers. The rescue rebuilds the AudioContext and every node,
   * then resumes at the same position. Reached via the Workbench button
   * only — no automatic banner (removed at Chris's request, v1.8.1). */
  function rebuildAudioEngine() {
    var pos = currentPlayhead();
    var wasPlaying = playing;
    if (stretchActive()) { // slowed mode: rebuild the rendered mix instead
      if (stretch.audio) { try { stretch.audio.pause(); } catch (_) {} }
      playing = false;
      iconsPlaying(false);
      rebuildStretchMix(pos, wasPlaying);
      return;
    }
    stopAllSources();
    playing = false;
    iconsPlaying(false);
    try { if (ctx) ctx.close(); } catch (_) {}
    ctx = null;
    unlocked = false;
    var audioCtx = ensureContext(); // called inside a click gesture → resumes cleanly
    if (!audioCtx) { setStatus('error', 'web audio unsupported'); return; }
    unlockAudioOnFirstGesture();
    tracks.forEach(function (t) {
      if (!t.buffer) return;
      try {
        t.gain = audioCtx.createGain();
        t.gain.gain.value = 1;
        t.gain.connect(masterGain);
        t.analyser = audioCtx.createAnalyser();
        t.analyser.fftSize = 512;
        t.analyser.smoothingTimeConstant = 0;
        t.gain.connect(t.analyser);
      } catch (_) {}
    });
    applyState();
    pausedOffset = pos;
    setStatus('ready', 'audio engine rebuilt');
    if (wasPlaying) startPlayback(pos); else tick();
  }

  $('wbRebuild').addEventListener('click', function () { wbToggle(false); rebuildAudioEngine(); });

  // Quiet self-heal: if the context slips into 'suspended' while playing,
  // try to resume it silently. No UI, no banner.
  setInterval(function () {
    if (!playing || stretchActive() || !ctx) return;
    if (ctx.state !== 'running') { try { ctx.resume().catch(function () {}); } catch (_) {} }
    if (IS_IOS && keepAlive && keepAlive.paused) { try { var kp = keepAlive.play(); if (kp && kp.catch) kp.catch(function () {}); } catch (_) {} }
  }, 1000);

  /* ---------- Master volume control ---------- */
  function applyMaster() {
    if (masterGain) masterGain.gain.value = masterVol;
    if (stretch.audio) { try { stretch.audio.volume = masterVol; } catch (_) {} }
    var el = $('mVol');
    el.value = Math.round(masterVol * 100);
    el.style.setProperty('--fill', Math.round(masterVol * 100) + '%');
    $('mVolVal').textContent = Math.round(masterVol * 100);
    try { sessionStorage.setItem('smx-master', String(masterVol)); } catch (_) {}
  }
  $('mVol').addEventListener('input', function () {
    masterVol = Math.max(0, Math.min(1, (+this.value) / 100));
    applyMaster();
  });
  applyMaster();

  // Test/debug handle (harmless in production)
  window.__smx = {
    rebuildAudio: rebuildAudioEngine,
    master: function () { return { vol: masterVol, node: masterGain ? masterGain.gain.value : null, elVol: stretch.audio ? stretch.audio.volume : null }; },
    info: function () {
      return {
        rate: rate,
        stretch: !!stretch.audio && stretchActive(),
        building: stretch.building,
        audioRate: stretch.audio ? stretch.audio.playbackRate : null,
        pp: stretch.audio ? (stretch.audio.preservesPitch !== false) : null,
        pos: currentPlayhead(),
        dur: duration,
        playing: playing,
        bpm: songBpm
      };
    },
    ios: function () {
      return {
        isIOS: IS_IOS,
        session: (navigator.audioSession && navigator.audioSession.type) || null,
        keepAlive: keepAlive ? { paused: keepAlive.paused, loop: keepAlive.loop, inDom: !!keepAlive.parentNode } : null
      };
    }
  };

  function fmt(s) {
    if (!isFinite(s) || s < 0) return '0:00';
    var m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return m + ':' + (sec < 10 ? '0' : '') + sec;
  }
  function zoneClass(v) {
    var p = v * 100;
    return p <= WB.z1 ? 'z0' : p <= WB.z2 ? 'z1' : p <= WB.z3 ? 'z2' : 'z3';
  }

  /* ---------- Gain application (fader × mute/solo audibility) ---------- */
  function applyState() {
    var anySolo = tracks.some(function (t) { return t.soloed && !t.failed; });
    tracks.forEach(function (t) {
      if (t.failed) return;
      var audible = !t.muted && (anySolo ? t.soloed : true);
      if (t.gain) t.gain.gain.value = audible ? t.fader : 0;
      t.strip.classList.toggle('muted', t.muted);
      t.strip.classList.toggle('ducked', anySolo && !t.soloed && !t.muted);
      t.strip.classList.toggle('soloed', t.soloed);
      t.mBtn.classList.toggle('on', t.muted);
      t.sBtn.classList.toggle('on', t.soloed);
    });
  }

  /* ---------- Fader rendering & setting ---------- */
  function renderFader(t) {
    var h = t.track.clientHeight || 246;
    var hh = t.handle.offsetHeight || 32;
    var pos = Math.min(Math.max(t.fader * h - hh / 2, -2), h - hh + 2);
    t.handle.style.bottom = pos + 'px';
    t.pctEl.textContent = Math.round(t.fader * 100) + '%';
    paintLevel(t); // immediate paint; the meter loop keeps it live from here
  }

  /* Paint the LED/solid level display for a track.
   * While playing with live meters on, the displayed level is the track's
   * actual post-fader signal (t.meterDisp); otherwise it settles at the
   * fader position. */
  function paintLevel(t) {
    var lvl = t.meterDisp;
    t.unlit.style.height = ((1 - lvl) * 100) + '%';
    t.fill.style.height = (lvl * 100) + '%';
    t.fill.className = 'fader-fill ' + zoneClass(lvl);
    // Peak-hold marker
    var showPeak = WB.meters && WB.peakHold && playing && t.peak > lvl + 0.02 && !t.failed;
    t.peakEl.style.display = showPeak ? 'block' : 'none';
    if (showPeak) {
      t.peakEl.style.bottom = 'calc(' + (t.peak * 100) + '% - 2px)';
      var pz = zoneClass(t.peak);
      t.peakEl.style.background = pz === 'z0' ? 'var(--green)' : pz === 'z1' ? 'var(--yellow)' : pz === 'z2' ? 'var(--zorange)' : 'var(--red)';
    }
  }

  /* ---------- Live metering (AnalyserNode per stem, real-mixer ballistics) ---------- */
  var meterBuf = new Uint8Array(512);
  function meterFrame(ts) {
    checkLoop(); // wrap A→B tightly (rAF cadence) when looping
    for (var i = 0; i < tracks.length; i++) {
      var t = tracks[i];
      if (!t.unlit) continue;
      var target;
      if (WB.meters && playing && !stretchActive() && t.analyser && !t.failed) {
        t.analyser.getByteTimeDomainData(meterBuf);
        var sum = 0;
        for (var j = 0; j < meterBuf.length; j++) {
          var v = (meterBuf[j] - 128) / 128;
          sum += v * v;
        }
        var rms = Math.sqrt(sum / meterBuf.length);
        var db = 20 * Math.log10(rms || 0.00001);       // signal in dBFS
        target = Math.max(0, Math.min(1, (db + WB.meterDb) / WB.meterDb)); // map -range..0 dB → 0..1
      } else {
        target = t.fader; // idle: LEDs show the fader position
      }
      // Ballistics: fast attack, slower release — like a hardware LED bridge
      var k = target > t.meterDisp ? 0.55 : 0.12;
      t.meterDisp += (target - t.meterDisp) * k;
      if (Math.abs(target - t.meterDisp) < 0.001) t.meterDisp = target;
      // Peak hold: grab new peaks instantly, hold ~0.8s, then let them fall
      if (WB.meters && playing) {
        if (t.meterDisp >= t.peak) { t.peak = t.meterDisp; t.peakAt = ts; }
        else if (ts - t.peakAt > 800) t.peak = Math.max(t.meterDisp, t.peak - 0.012);
      } else {
        t.peak = 0;
      }
      paintLevel(t);
    }
    drawEQ(ts);
    requestAnimationFrame(meterFrame);
  }
  requestAnimationFrame(meterFrame);

  /* ---------- Banner EQ visualization (canvas in .ns-fill) ---------- */
  var nsCanvas = document.getElementById('nsCanvas');
  var freqBuf = new Uint8Array(128);
  var nsVals = [], nsW = 0, nsH = 0, nsG = null, nsGrad = null, nsColorsDirty = true;
  var NS_BAR = 5, NS_GAP = 3;

  function drawEQ(ts) {
    if (!nsCanvas || !nsCanvas.parentElement) return;
    var box = nsCanvas.parentElement.getBoundingClientRect();
    if (box.width < 8 || box.height < 2) return;
    var dpr = window.devicePixelRatio || 1;
    var w = Math.floor(box.width), h = Math.floor(box.height);
    if (w !== nsW || h !== nsH || nsColorsDirty || !nsG) {
      nsW = w; nsH = h;
      nsCanvas.width = Math.floor(w * dpr);
      nsCanvas.height = Math.floor(h * dpr);
      nsG = nsCanvas.getContext('2d');
      nsG.setTransform(dpr, 0, 0, dpr, 0, 0);
      nsGrad = nsG.createLinearGradient(0, h, 0, 0); // fader-zone colors, bottom→top
      var z1 = WB.z1 / 100, z2 = WB.z2 / 100, z3 = WB.z3 / 100, e = 0.004;
      nsGrad.addColorStop(0, '#37b24d');
      nsGrad.addColorStop(Math.min(1, z1), '#37b24d');
      nsGrad.addColorStop(Math.min(1, z1 + e), '#f2c517');
      nsGrad.addColorStop(Math.min(1, z2), '#f2c517');
      nsGrad.addColorStop(Math.min(1, z2 + e), '#f0801c');
      nsGrad.addColorStop(Math.min(1, z3), '#f0801c');
      nsGrad.addColorStop(Math.min(1, z3 + e), '#e6402a');
      nsGrad.addColorStop(1, '#e6402a');
      nsColorsDirty = false;
    }
    var n = Math.max(4, Math.floor((w + NS_GAP) / (NS_BAR + NS_GAP)));
    if (nsVals.length !== n) nsVals = new Array(n).fill(0);

    var stretchMode = stretchActive();
    var live = playing && !stretchMode && masterAnalyser;
    var envLevel = 0;
    if (stretchMode && playing && stretch.env && stretch.audio) {
      var fi = Math.floor(stretch.audio.currentTime * (stretch.envRate || 20));
      envLevel = stretch.env[Math.max(0, Math.min(stretch.env.length - 1, fi))] || 0;
    }
    if (live) masterAnalyser.getByteFrequencyData(freqBuf);

    nsG.clearRect(0, 0, w, h);
    var usable = 100; // skip the near-empty top of the spectrum
    for (var i = 0; i < n; i++) {
      var target = 0;
      if (live) {
        var bin = Math.floor(Math.pow(i / n, 1.6) * (usable - 1)); // log-ish frequency spread
        target = Math.min(1, (freqBuf[bin] / 255) * 1.25);
      } else if (stretchMode && playing) {
        // Stylized: real song energy shaping per-bar oscillation
        target = Math.max(0, Math.min(1, envLevel * (0.55 + 0.45 * Math.sin(ts * 0.004 * (0.7 + (i % 9) * 0.31) + i * 1.7))));
      }
      var k = target > nsVals[i] ? 0.5 : 0.14; // EQ ballistics
      nsVals[i] += (target - nsVals[i]) * k;
      var x = i * (NS_BAR + NS_GAP);
      // dim ghost column
      nsG.fillStyle = 'rgba(233,233,236,0.05)';
      nsG.fillRect(x, 0, NS_BAR, h);
      // lit bar
      var bh = Math.max(0, Math.round(nsVals[i] * h));
      if (bh > 0) {
        nsG.fillStyle = nsGrad;
        nsG.fillRect(x, h - bh, NS_BAR, bh);
      }
    }
    // LED segmentation: punch thin gaps across the strip
    if (h >= 16) {
      for (var y = h - 4; y > 0; y -= 4) nsG.clearRect(0, y, w, 1);
    }
  }

  function setFader(t, v, fromUser) {
    v = Math.min(1, Math.max(0, v));
    t.fader = v;
    renderFader(t);
    if (fromUser && activeFeature) {
      // A manual fader move cancels the active feature but keeps positions
      activeFeature = null;
      updateFeatureButtons();
    }
    applyState();
    markStretchDirty(); // slowed mode plays a rendered mix — refresh it
  }

  /* ---------- Feature buttons (GUITAR+ / BASS+ / DRUMS+) ----------
   * "+"  : featured track -> featLevel, every other track -> duckLevel.
   *        Levels are absolute (measured from the fader's full range),
   *        NOT relative to wherever the user dragged a fader.
   * "–"  : restores ALL faders to the default level (defLevel).
   * Manual fader move while active cancels the feature (keeps positions).
   */
  function stemMatches(t, feat) {
    return t.name.toLowerCase() === String(feat).toLowerCase();
  }
  function songHasStem(feat) {
    return tracks.some(function (t) { return stemMatches(t, feat); });
  }
  function isCountIn(name) {
    return /^count[\s_]*in$/i.test(String(name).trim());
  }

  /* Feature "+" buttons now live inside each channel header (see buildStrip).
   * featKeys maps an unused first letter -> stem name for keyboard shortcuts;
   * it's reset in loadSong and populated as each channel's button is built. */
  var featKeys = {}; // letter -> stem name
  function applyFeature(feat) {
    if (activeFeature === feat) { restoreToDefault(); return; }
    activeFeature = feat;
    tracks.forEach(function (t) {
      setFader(t, stemMatches(t, feat) ? WB.featLevel / 100 : WB.duckLevel / 100, false);
    });
    updateFeatureButtons();
  }
  function restoreToDefault() {
    activeFeature = null;
    tracks.forEach(function (t) { setFader(t, WB.defLevel / 100, false); });
    updateFeatureButtons();
  }
  function reapplyActiveFeature() {
    if (!activeFeature) return;
    var feat = activeFeature;
    tracks.forEach(function (t) {
      setFader(t, stemMatches(t, feat) ? WB.featLevel / 100 : WB.duckLevel / 100, false);
    });
  }
  function updateFeatureButtons() {
    var btns = root.querySelectorAll('.chfeat');
    for (var i = 0; i < btns.length; i++) {
      var btn = btns[i];
      var feat = btn.getAttribute('data-feat');
      var on = (activeFeature !== null && feat && feat.toLowerCase() === String(activeFeature).toLowerCase());
      btn.classList.toggle('active', on);
      btn.querySelector('.sign').textContent = on ? '–' : '+';
    }
  }

  /* ---------- Status / loading UI ---------- */
  function setStatus(cls, msg) {
    statusEl.className = 'status ' + cls;
    statusMsg.textContent = msg;
  }
  function showLoading(show) { root.classList.toggle('is-loading', show); liteSetLoading(show); }
  function setLoadingProgress(done, total, pct) {
    loadCount.textContent = done + ' of ' + total;
    loadPct.textContent = Math.round(pct) + '%';
    loadFill.style.width = pct + '%';
    liteSetProgress(done, total, pct);
  }

  /* ---------- Streaming fetch with progress (from V1) ---------- */
  function fetchStem(url, onProgress) {
    return fetch(url).then(function (response) {
      if (!response.ok) throw new Error('HTTP ' + response.status + ' for ' + url);
      var total = Number(response.headers.get('content-length')) || 0;
      if (!response.body || !window.ReadableStream || !total) {
        return response.arrayBuffer().then(function (buf) { onProgress(1); return buf; });
      }
      var reader = response.body.getReader();
      var chunks = [], received = 0;
      return new Promise(function (resolve, reject) {
        (function pump() {
          reader.read().then(function (r) {
            if (r.done) {
              var merged = new Uint8Array(received), offset = 0;
              for (var i = 0; i < chunks.length; i++) { merged.set(chunks[i], offset); offset += chunks[i].byteLength; }
              onProgress(1);
              resolve(merged.buffer);
              return;
            }
            chunks.push(r.value);
            received += r.value.byteLength;
            onProgress(Math.min(0.99, received / total));
            pump();
          }).catch(reject);
        })();
      });
    });
  }

  /* ---------- Teardown ---------- */
  function stopAllSources() {
    tracks.forEach(function (t) {
      if (t.source) {
        try { t.source.onended = null; } catch (_) {}
        try { t.source.stop(); } catch (_) {}
        try { t.source.disconnect(); } catch (_) {}
        t.source = null;
      }
    });
  }
  function unloadCurrent() {
    if (tickHandle) { clearInterval(tickHandle); tickHandle = null; }
    stopAllSources();
    teardownStretch();
    songBpm = null;
    renderBpm();
    tracks = [];
    duration = 0;
    playing = false;
    pausedOffset = 0;
    activeFeature = null;
    mixerEl.innerHTML = '';
    icoPlay.style.display = 'block';
    icoPause.style.display = 'none';
    tElapsed.textContent = '0:00';
    tTotal.textContent = '0:00';
    progress.style.width = '0%';
  }

  /* ---------- Build one channel strip ---------- */
  function buildStrip(stem, i) {
    var strip = document.createElement('div');
    strip.className = 'strip';
    strip.innerHTML =
      '<div class="strip-head"><span class="tnum">' + (i + 1) + '</span>' +
      '<span class="tname"></span></div>' +
      '<div class="ms">' +
        '<button class="msbtn m" title="Mute">M</button>' +
        '<button class="msbtn s" title="Solo">S</button>' +
      '</div>' +
      '<div class="fader"><div class="fader-track">' +
        '<div class="fader-ladder"></div>' +
        '<div class="fader-unlit"></div>' +
        '<div class="fader-fill"></div>' +
        '<div class="fader-peak"></div>' +
        '<div class="fader-ticks left"></div>' +
        '<div class="fader-ticks"></div>' +
        '<div class="fader-handle"><div class="cap"></div></div>' +
      '</div></div>' +
      '<div class="pct">100%</div>';
    strip.querySelector('.tname').textContent = stem.name.toUpperCase();
    // Teacher-mode explanations for this channel's controls
    var chNo = i + 1;
    strip.querySelector('.strip-head').setAttribute('data-teach-title', stem.name + ' channel');
    strip.querySelector('.strip-head').setAttribute('data-teach', 'This whole column controls just the ' + stem.name + ' part. Number ' + chNo + ' is its channel number for the keyboard shortcuts.');
    strip.querySelector('.msbtn.m').setAttribute('data-teach-title', 'Mute — ' + stem.name);
    strip.querySelector('.msbtn.m').setAttribute('data-teach', 'Silences the ' + stem.name + ' while everything else keeps playing. Click again to bring it back. Keyboard: <kbd>Shift</kbd>+<kbd>' + chNo + '</kbd>.');
    strip.querySelector('.msbtn.s').setAttribute('data-teach-title', 'Solo — ' + stem.name);
    strip.querySelector('.msbtn.s').setAttribute('data-teach', 'Plays only the ' + stem.name + ' and mutes the rest. Solo more than one part to hear just those together. Keyboard: <kbd>' + chNo + '</kbd>.');
    strip.querySelector('.fader').setAttribute('data-teach-title', stem.name + ' volume');
    strip.querySelector('.fader').setAttribute('data-teach', 'Drag up or down to set the ' + stem.name + ' level. While the song plays, the lights dance to the actual sound — like a real mixer meter — with a marker that briefly holds each peak.');

    // Feature "+" toggle for this channel — right-justified in the header
    // (every stem except Count In). Toggles this part to the front / back.
    if (!isCountIn(stem.name)) {
      var fbtn = document.createElement('button');
      fbtn.className = 'chfeat';
      fbtn.type = 'button';
      fbtn.setAttribute('data-feat', stem.name);
      var fsign = document.createElement('span');
      fsign.className = 'sign';
      fsign.textContent = '+';
      fbtn.appendChild(fsign);
      fbtn.addEventListener('click', function () { applyFeature(stem.name); fbtn.blur(); });
      var letter = stem.name.trim().charAt(0).toLowerCase();
      var reserved = { r: 1, w: 1, m: 1, s: 1, l: 1 }; // r/w/m/s transport, l = loop
      if (/^[a-z]$/.test(letter) && !featKeys[letter] && !reserved[letter]) featKeys[letter] = stem.name;
      var teach = 'Spotlights the ' + stem.name + ': it goes to full volume while every other part ducks down, so you can hear it clearly. The <b>+</b> flips to a <b>&minus;</b> — press it again to bring the whole mix back to normal.';
      if (/^[a-z]$/.test(letter) && !reserved[letter]) teach += ' Keyboard: <kbd>' + letter.toUpperCase() + '</kbd>.';
      fbtn.setAttribute('data-teach-title', stem.name.toUpperCase() + ' feature');
      fbtn.setAttribute('data-teach', teach);
      strip.querySelector('.strip-head').appendChild(fbtn);
    }
    mixerEl.appendChild(strip);

    var t = {
      name: stem.name, url: stem.url,
      buffer: null, gain: null, source: null, analyser: null,
      fader: WB.defLevel / 100, muted: false, soloed: false, failed: false,
      meterDisp: WB.defLevel / 100, peak: 0, peakAt: 0,
      strip: strip,
      track: strip.querySelector('.fader-track'),
      ladder: strip.querySelector('.fader-ladder'),
      unlit: strip.querySelector('.fader-unlit'),
      fill: strip.querySelector('.fader-fill'),
      peakEl: strip.querySelector('.fader-peak'),
      handle: strip.querySelector('.fader-handle'),
      pctEl: strip.querySelector('.pct'),
      mBtn: strip.querySelector('.msbtn.m'),
      sBtn: strip.querySelector('.msbtn.s')
    };

    var dragging = false;
    function valFromEvent(e) {
      var r = t.track.getBoundingClientRect();
      var cy = (e.touches && e.touches.length) ? e.touches[0].clientY : e.clientY;
      return (r.bottom - cy) / r.height;
    }
    t.track.addEventListener('mousedown', function (e) { dragging = true; setFader(t, valFromEvent(e), true); e.preventDefault(); });
    window.addEventListener('mousemove', function (e) { if (dragging) setFader(t, valFromEvent(e), true); });
    window.addEventListener('mouseup', function () { dragging = false; });
    t.track.addEventListener('touchstart', function (e) { dragging = true; setFader(t, valFromEvent(e), true); e.preventDefault(); }, { passive: false });
    window.addEventListener('touchmove', function (e) { if (dragging) setFader(t, valFromEvent(e), true); }, { passive: false });
    window.addEventListener('touchend', function () { dragging = false; });

    t.mBtn.addEventListener('click', function () { t.muted = !t.muted; applyState(); markStretchDirty(); t.mBtn.blur(); });
    t.sBtn.addEventListener('click', function () { t.soloed = !t.soloed; applyState(); markStretchDirty(); t.sBtn.blur(); });

    return t;
  }

  /* ---------- Load a song ---------- */
  /* ---------- Robust stem loading: retry + concurrency cap ---------- */
  var MAX_STEM_TRIES = 3;
  function ctxDecode(audioCtx, arrayBuffer) {
    return new Promise(function (resolve, reject) {
      var pr;
      try { pr = audioCtx.decodeAudioData(arrayBuffer, resolve, reject); }
      catch (e) { reject(e); return; }
      if (pr && pr.then) pr.then(resolve, reject); // promise-form browsers
    });
  }
  // Fetch + decode one stem, retrying with backoff. Re-fetches fresh each attempt
  // (a failed decode detaches the ArrayBuffer, so reuse is unsafe). Resolves with the
  // AudioBuffer, or rejects after MAX_STEM_TRIES. Cancels if the song changed (token).
  function loadOneStem(t, i, myToken, onProgress) {
    var attempt = 0;
    function tryOnce() {
      attempt++;
      return fetchStem(t.url, onProgress).then(function (arrayBuffer) {
        if (myToken !== loadToken) return null;
        return ctxDecode(ensureContext(), arrayBuffer);
      });
    }
    function loop() {
      return tryOnce().catch(function (err) {
        if (myToken !== loadToken) throw err;
        if (attempt < MAX_STEM_TRIES) {
          if (window.console) console.warn('stem retry ' + attempt + ': ' + t.url, err && err.message);
          try { onProgress(0); } catch (_) {}
          return new Promise(function (res) { setTimeout(res, 300 * attempt); }).then(loop);
        }
        throw err;
      });
    }
    return loop();
  }
  function wireStem(t, audioBuffer, audioCtx) {
    t.buffer = audioBuffer;
    t.gain = audioCtx.createGain();
    t.gain.gain.value = 1;
    t.gain.connect(masterGain);
    t.analyser = audioCtx.createAnalyser();
    t.analyser.fftSize = 512;
    t.analyser.smoothingTimeConstant = 0;
    t.gain.connect(t.analyser);
    if (audioBuffer.duration > duration) duration = audioBuffer.duration;
    t.failed = false;
    if (t.strip) t.strip.classList.remove('failed');
  }
  // Re-attempt a single failed stem without reloading the whole song (LITE retry button).
  function retryStem(i) {
    var t = tracks[i]; if (!t || t.buffer || t.retrying) return;
    var myToken = loadToken, audioCtx = ensureContext(); if (!audioCtx) return;
    t.retrying = true; t.failed = false; if (t.strip) t.strip.classList.remove('failed');
    setStatus('loading', 'retrying ' + t.name);
    loadOneStem(t, i, myToken, function () {}).then(function (audioBuffer) {
      t.retrying = false;
      if (myToken !== loadToken) return;
      if (audioBuffer) {
        wireStem(t, audioBuffer, audioCtx);
        tTotal.textContent = fmt(duration);
        applyState();
        setStatus('ready', t.name + ' loaded — press play to include it');
      }
    }).catch(function () {
      t.retrying = false;
      if (myToken !== loadToken) return;
      t.failed = true; if (t.strip) t.strip.classList.add('failed');
      setStatus('error', t.name + ' still won\'t load');
    });
  }

  function loadSong(idx) {
    var myToken = ++loadToken;
    unloadCurrent();
    var song = SONGS[idx];
    if (!song) return;

    renderDropdownButton();
    renderSongLinks(song);
    renderResources(song);
    // Now-loaded marquee between the logo and the mixer
    document.getElementById('nsArtist').textContent = song.artist || '';
    document.getElementById('nsTitle').textContent = song.title || '';
    statusName.textContent = song.title;
    smxMediaMeta(song); // lock-screen Now-Playing: STEMMAXXER cover + this song's title/artist
    setStatus('loading', 'loading 0 of ' + song.stems.length);

    featKeys = {}; // rebuilt per song as strips (and their feature buttons) are created
    clearLoop();   // loops don't carry across songs
    tracks = song.stems.map(buildStrip);
    tracks.forEach(renderFader);
    updateFeatureButtons();
    renderHint();

    showLoading(true);
    setLoadingProgress(0, tracks.length, 0);

    var audioCtx = ensureContext();
    if (!audioCtx) { setStatus('error', 'web audio unsupported'); showLoading(false); return; }

    var fractions = new Array(tracks.length).fill(0);
    var completedCount = 0;

    function updateAggregate() {
      var sum = 0;
      for (var i = 0; i < fractions.length; i++) sum += fractions[i];
      var pct = (sum / fractions.length) * 100;
      setLoadingProgress(completedCount, tracks.length, pct);
      setStatus('loading', 'loading ' + completedCount + ' of ' + tracks.length);
    }

    // Concurrency pool: at most STEM_CONCURRENCY stems in flight (gentler on mobile
    // connections / connection caps than firing all at once), each retrying on failure.
    var STEM_CONCURRENCY = 4, nextIdx = 0;
    function runWorker() {
      if (myToken !== loadToken) return Promise.resolve();
      var i = nextIdx++;
      if (i >= tracks.length) return Promise.resolve();
      var t = tracks[i];
      return loadOneStem(t, i, myToken, function (frac) {
        if (myToken !== loadToken) return;
        fractions[i] = frac; updateAggregate();
      }).then(function (audioBuffer) {
        if (myToken !== loadToken) return;
        if (audioBuffer) wireStem(t, audioBuffer, audioCtx);
      }).catch(function (err) {
        if (myToken !== loadToken) return;
        t.failed = true; if (t.strip) t.strip.classList.add('failed');
        if (window.console) console.error('Failed to load stem (after retries)', t.url, err);
      }).then(function () {
        if (myToken !== loadToken) return;
        completedCount++; fractions[i] = 1; updateAggregate();
        return runWorker();
      });
    }
    var workers = [];
    for (var wk = 0; wk < Math.min(STEM_CONCURRENCY, tracks.length); wk++) workers.push(runWorker());

    Promise.all(workers).then(function () {
      if (myToken !== loadToken) return;
      showLoading(false);
      var okCount = tracks.filter(function (t) { return t.buffer; }).length;
      if (okCount === 0) {
        setStatus('error', 'no stems could load');
        return;
      }
      setStatus('ready', okCount === tracks.length ? 'loaded successfully' : (okCount + ' of ' + tracks.length + ' loaded'));
      tTotal.textContent = fmt(duration);
      applyState();
      updateFeatureButtons();
      tickHandle = setInterval(tick, 100);
      analyzeBpmForSong(myToken);
      if (stretchActive()) rebuildStretchMix(0, false); // keep the chosen speed across songs
    });

    applyState();
    liteBuild(); // refresh the LITE mobile view (no-op on desktop / when markup absent)
  }

  /* ---------- Playhead ---------- */
  function currentPlayhead() {
    if (stretchActive()) {
      return stretch.audio && stretch.url ? stretch.audio.currentTime : pausedOffset;
    }
    if (!playing) return pausedOffset;
    if (!ctx) return 0;
    return playStartOffset + (ctx.currentTime - playStartCtxTime);
  }
  function tick() {
    if (scrubDragging) return; // mid-drag: the pointer owns the display
    var t = Math.min(duration, currentPlayhead());
    tElapsed.textContent = fmt(t);
    if (duration > 0) progress.style.width = (t / duration * 100) + '%';
    if (playing && !stretchActive() && t >= duration) {
      if (loopEnabled) { seekTo(loopA !== null ? loopA : 0); return; } // loop instead of stopping
      pausedOffset = 0;
      stopAllSources();
      playing = false;
      icoPlay.style.display = 'block';
      icoPause.style.display = 'none';
      setStatus('ready', 'loaded successfully');
      progress.style.width = '0%';
      tElapsed.textContent = '0:00';
    }
  }

  /* ---------- Start / pause / seek (sample-accurate, from V1) ---------- */
  function loadedTracks() { return tracks.filter(function (t) { return t.buffer; }); }

  function startPlayback(fromOffset) {
    var ready = loadedTracks();
    if (!ready.length) return;
    var audioCtx = ensureContext();
    if (!audioCtx) return;
    var offset = Math.max(0, Math.min(duration, fromOffset));
    stopAllSources();

    var doStart = function () {
      if (!audioCtx || audioCtx.state !== 'running') return;
      var startAt = audioCtx.currentTime + 0.05;
      ready.forEach(function (t) {
        var src = audioCtx.createBufferSource();
        src.buffer = t.buffer;
        try { t.gain.connect(masterGain); } catch (_) {}
        src.connect(t.gain);
        var safeOffset = Math.min(offset, t.buffer.duration);
        try { src.start(startAt, safeOffset); } catch (_) {}
        t.source = src;
      });
      playStartCtxTime = startAt;
      playStartOffset = offset;
      playing = true;
      icoPlay.style.display = 'none';
      icoPause.style.display = 'block';
      setStatus('ready', 'playing');
      smxMediaState(true); smxMediaPos();
    };

    if (audioCtx.state === 'running') doStart();
    else audioCtx.resume().then(doStart).catch(function (err) {
      setStatus('error', 'audio blocked');
      if (window.console) console.error('AudioContext resume failed:', err);
    });
  }

  function pausePlayback() {
    if (stretchActive()) {
      if (stretch.audio) {
        pausedOffset = stretch.audio.currentTime;
        try { stretch.audio.pause(); } catch (_) {}
      }
      playing = false;
      iconsPlaying(false);
      setStatus('ready', 'paused');
      smxMediaState(false); smxMediaPos();
      return;
    }
    if (!playing) return;
    pausedOffset = Math.min(duration, currentPlayhead());
    stopAllSources();
    playing = false;
    iconsPlaying(false);
    setStatus('ready', 'paused');
    smxMediaState(false); smxMediaPos();
  }

  function togglePlay() {
    if (!loadedTracks().length) return;
    if (stretchActive()) {
      if (!stretch.audio || !stretch.url || stretch.building) return;
      if (playing) { pausePlayback(); return; }
      stretch.audio.playbackRate = rate;
      stretch.audio.play().catch(function () {});
      playing = true;
      iconsPlaying(true);
      setStatus('ready', 'playing at ' + Math.round(rate * 100) + '%');
      smxMediaState(true); smxMediaPos();
      return;
    }
    if (playing) pausePlayback();
    else startPlayback(pausedOffset);
  }

  function seekTo(seconds) {
    if (!loadedTracks().length) return;
    var target = Math.max(0, Math.min(duration, seconds));
    if (stretchActive()) {
      if (stretch.audio && stretch.url) { try { stretch.audio.currentTime = target; } catch (_) {} }
      pausedOffset = target;
      tick();
      smxMediaPos();
      return;
    }
    if (playing) startPlayback(target);
    else { pausedOffset = target; tick(); }
    smxMediaPos();
  }

  /* ---------- Transport events ---------- */
  playBtn.addEventListener('click', function () { togglePlay(); playBtn.blur(); });
  $('btnRestart').addEventListener('click', function () {
    if (!loadedTracks().length) return;
    if (stretchActive()) {
      if (stretch.audio && stretch.url && !stretch.building) {
        try { stretch.audio.currentTime = 0; } catch (_) {}
        stretch.audio.play().catch(function () {});
        playing = true;
        iconsPlaying(true);
      }
      this.blur();
      return;
    }
    pausedOffset = 0;
    startPlayback(0);
    this.blur();
  });
  $('btnReset').addEventListener('click', function () {
    pausePlayback();
    pausedOffset = 0;
    if (stretchActive() && stretch.audio && stretch.url) { try { stretch.audio.currentTime = 0; } catch (_) {} }
    tracks.forEach(function (t) { t.muted = false; t.soloed = false; });
    restoreToDefault(); // faders to default level, feature off
    clearLoop();         // clear any A/B loop
    progress.style.width = '0%';
    tElapsed.textContent = '0:00';
    setStatus('ready', 'reset');
    this.blur();
  });
  $('btnBack').addEventListener('click', function () { seekTo(currentPlayhead() - 10); this.blur(); });
  $('btnFwd').addEventListener('click',  function () { seekTo(currentPlayhead() + 10); this.blur(); });

  /* Drag-to-scrub: visual follows the pointer live; the actual seek happens
   * on release (a zero-distance drag behaves exactly like the old click). */
  var scrubDragging = false, scrubTarget = 0;
  function scrubTimeFromEvent(e) {
    var rect = scrubber.getBoundingClientRect();
    var cx = (e.touches && e.touches.length) ? e.touches[0].clientX
           : (e.changedTouches && e.changedTouches.length) ? e.changedTouches[0].clientX
           : e.clientX;
    var pct = Math.max(0, Math.min(1, (cx - rect.left) / rect.width));
    return pct * duration;
  }
  function scrubShow(t) {
    tElapsed.textContent = fmt(t);
    if (duration > 0) progress.style.width = (t / duration * 100) + '%';
  }
  function scrubStart(e) {
    if (!duration) return;
    scrubDragging = true;
    scrubber.classList.add('dragging');
    scrubTarget = scrubTimeFromEvent(e);
    scrubShow(scrubTarget);
    e.preventDefault();
  }
  function scrubMove(e) {
    if (!scrubDragging) return;
    scrubTarget = scrubTimeFromEvent(e);
    scrubShow(scrubTarget);
  }
  function scrubEnd(e) {
    if (!scrubDragging) return;
    scrubDragging = false;
    scrubber.classList.remove('dragging');
    seekTo(scrubTarget);
  }
  scrubber.addEventListener('mousedown', scrubStart);
  window.addEventListener('mousemove', scrubMove);
  window.addEventListener('mouseup', scrubEnd);
  scrubber.addEventListener('touchstart', scrubStart, { passive: false });
  window.addEventListener('touchmove', scrubMove, { passive: false });
  window.addEventListener('touchend', scrubEnd);

  /* ---------- A/B section loop (beta) ---------- */
  var loopRegion = $('loopRegion');
  function renderLoopRegion() {
    if (!loopRegion) return;
    if (!loopEnabled || loopA === null || loopB === null || duration <= 0 || loopB <= loopA) { loopRegion.style.display = 'none'; return; }
    var a = Math.max(0, Math.min(loopA, duration)), b = Math.max(0, Math.min(loopB, duration));
    loopRegion.style.display = 'block';
    loopRegion.style.left = (a / duration * 100) + '%';
    loopRegion.style.width = ((b - a) / duration * 100) + '%';
  }
  // A / B position flags — visible whenever their point is set, independent of the loop being on.
  function renderLoopMarks() {
    var mA = $('loopMarkA'), mB = $('loopMarkB');
    if (mA) { if (loopA !== null && duration > 0) { mA.style.display = 'block'; mA.style.left = (Math.max(0, Math.min(loopA, duration)) / duration * 100) + '%'; } else mA.style.display = 'none'; }
    if (mB) { if (loopB !== null && duration > 0) { mB.style.display = 'block'; mB.style.left = (Math.max(0, Math.min(loopB, duration)) / duration * 100) + '%'; } else mB.style.display = 'none'; }
  }
  function updateLoopUI() {
    $('loopABtn').classList.toggle('set', loopA !== null);
    $('loopBBtn').classList.toggle('set', loopB !== null);
    $('loopToggleBtn').classList.toggle('on', loopEnabled);
    renderLoopRegion();
    renderLoopMarks();
  }
  function setLoopA() { loopA = currentPlayhead(); if (loopB !== null && loopB <= loopA) loopB = null; updateLoopUI(); }
  function setLoopB() { loopB = currentPlayhead(); if (loopA !== null && loopA >= loopB) loopA = null; updateLoopUI(); }
  function toggleLoop() { loopEnabled = !loopEnabled; updateLoopUI(); }
  function clearLoop() { loopEnabled = false; loopA = null; loopB = null; updateLoopUI(); }
  // Wrap back to A when the playhead reaches B (called from the meter rAF loop and the tick backup).
  function checkLoop() {
    if (!playing || !loopEnabled || duration <= 0) return;
    var a = (loopA !== null ? loopA : 0), b = (loopB !== null ? loopB : duration);
    if (b - a < 0.15) return;
    if (currentPlayhead() >= b - 0.02) seekTo(a);
  }
  $('loopABtn').addEventListener('click', function () { setLoopA(); this.blur(); });
  $('loopBBtn').addEventListener('click', function () { setLoopB(); this.blur(); });
  $('loopToggleBtn').addEventListener('click', function () { toggleLoop(); this.blur(); });
  $('loopClearBtn').addEventListener('click', function () { clearLoop(); this.blur(); });

  // Drag the A/B edges of the loop region on the playback bar
  (function () {
    var dragEdge = null;
    function edgeTime(e) {
      var rect = scrubber.getBoundingClientRect();
      var cx = (e.touches && e.touches.length) ? e.touches[0].clientX : e.clientX;
      return Math.max(0, Math.min(1, (cx - rect.left) / rect.width)) * duration;
    }
    function startEdge(which) {
      return function (e) { if (!duration) return; dragEdge = which; e.preventDefault(); e.stopPropagation(); };
    }
    $('loopHandleA').addEventListener('mousedown', startEdge('a'));
    $('loopHandleB').addEventListener('mousedown', startEdge('b'));
    $('loopHandleA').addEventListener('touchstart', startEdge('a'), { passive: false });
    $('loopHandleB').addEventListener('touchstart', startEdge('b'), { passive: false });
    // The standalone A/B flags are draggable too (they move the same loop points,
    // even before B is set or the loop is switched on).
    $('loopMarkA').addEventListener('mousedown', startEdge('a'));
    $('loopMarkB').addEventListener('mousedown', startEdge('b'));
    $('loopMarkA').addEventListener('touchstart', startEdge('a'), { passive: false });
    $('loopMarkB').addEventListener('touchstart', startEdge('b'), { passive: false });
    function move(e) {
      if (!dragEdge) return;
      var t = edgeTime(e);
      if (dragEdge === 'a') loopA = Math.min(t, (loopB !== null ? loopB - 0.1 : duration));
      else loopB = Math.max(t, (loopA !== null ? loopA + 0.1 : 0));
      renderLoopRegion(); renderLoopMarks();
      e.preventDefault();
    }
    window.addEventListener('mousemove', move);
    window.addEventListener('touchmove', move, { passive: false });
    window.addEventListener('mouseup', function () { if (dragEdge) { dragEdge = null; updateLoopUI(); } });
    window.addEventListener('touchend', function () { if (dragEdge) { dragEdge = null; updateLoopUI(); } });
  })();
  window.addEventListener('resize', function () { renderLoopRegion(); renderLoopMarks(); });

  /* ---------- Keyboard shortcuts ---------- */
  document.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    // Shift+W toggles the workbench from anywhere (except text inputs)
    if (e.shiftKey && (e.code === 'KeyW')) { e.preventDefault(); wbToggle(); return; }
    if (e.code === 'Escape' && wbEl.classList.contains('open')) { wbToggle(false); return; }
    if (ddWrap.classList.contains('open')) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;

    if (e.code === 'Space') { e.preventDefault(); togglePlay(); return; }
    if (e.code === 'ArrowLeft')  { e.preventDefault(); seekTo(currentPlayhead() - 10); return; }
    if (e.code === 'ArrowRight') { e.preventDefault(); seekTo(currentPlayhead() + 10); return; }
    if (e.key === 'r' || e.key === 'R') {
      e.preventDefault();
      if (e.shiftKey) $('btnReset').click();
      else $('btnRestart').click();
      return;
    }
    // A/B loop keys (permanent feature since v1.14.10)
    if (e.shiftKey && e.key === 'L') { e.preventDefault(); clearLoop(); return; }
    if (!e.shiftKey) {
      if (e.key === '[') { e.preventDefault(); setLoopA(); return; }
      if (e.key === ']') { e.preventDefault(); setLoopB(); return; }
      if (e.key === 'l' || e.key === 'L') { e.preventDefault(); toggleLoop(); return; }
    }
    // Feature-button shortcuts: first letter of each stem (built per song)
    var kf = (e.key && e.key.length === 1) ? featKeys[e.key.toLowerCase()] : null;
    if (kf && !e.shiftKey) { e.preventDefault(); applyFeature(kf); return; }

    var n = NaN;
    if (e.code && e.code.indexOf('Digit') === 0) n = parseInt(e.code.slice(5), 10);
    else if (e.code && e.code.indexOf('Numpad') === 0) n = parseInt(e.code.slice(6), 10);
    if (n >= 1 && n <= tracks.length) {
      e.preventDefault();
      var t = tracks[n - 1];
      if (e.shiftKey) t.muted = !t.muted;
      else t.soloed = !t.soloed;
      applyState();
    }
  });

  function renderHint() {
    var n = tracks.length;
    var SEP = '<span class="hsep">&middot;</span>';
    var letters = [];
    for (var k in featKeys) letters.push('<kbd>' + k.toUpperCase() + '</kbd>');
    hintEl.innerHTML =
      '<kbd>SPACE</kbd> play/pause' + SEP + '<kbd>R</kbd> restart' + SEP + '<kbd>Shift</kbd>+<kbd>R</kbd> reset' +
      SEP + '<kbd>&larr;</kbd>/<kbd>&rarr;</kbd> &plusmn;10s' +
      SEP + '<kbd>1</kbd>&ndash;<kbd>' + n + '</kbd> solo' + SEP + '<kbd>Shift</kbd>+<kbd>1</kbd>&ndash;<kbd>' + n + '</kbd> mute' +
      (letters.length ? SEP + letters.join('/') + ' feature' : '');
  }

  /* ---------- Dropdown (keyboard nav + typeahead, from V1) ---------- */
  var currentSongIdx = 0, highlightedIdx = -1;
  var typeaheadBuffer = '', typeaheadTimer = null;

  function renderDropdownButton() {
    var s = SONGS[currentSongIdx];
    if (!s) { ddSong.textContent = 'No songs found'; return; }
    ddSong.innerHTML = '';
    if (s.artist) {
      var art = document.createElement('span');
      art.className = 'art';
      art.textContent = s.artist + ' — ';
      ddSong.appendChild(art);
    }
    ddSong.appendChild(document.createTextNode(s.title));
  }

  // Show Charts / Lesson buttons only when the loaded song has those links.
  function renderSongLinks(song) {
    var cl = $('chartLink'), ll = $('lessonLink');
    var chart = song && song.chart ? String(song.chart) : '';
    var lesson = song && song.lesson ? String(song.lesson) : '';
    if (chart) { cl.href = chart; cl.style.display = 'inline-flex'; } else { cl.removeAttribute('href'); cl.style.display = 'none'; }
    if (lesson) { ll.href = lesson; ll.style.display = 'inline-flex'; } else { ll.removeAttribute('href'); ll.style.display = 'none'; }
  }

  /* ============================================================
   * PER-SONG RESOURCES (bf-resources beta) — collapse a song's links into one
   * "Resources ▾" button (single link = one direct button). Band members who've
   * passed the gate can add their own; the adding device keeps a delete token so
   * only it (or Chris in admin) can remove that item.
   * ============================================================ */
  var RES_ICONS = {
    tab:   '<svg viewBox="0 0 20 20" width="15" height="15" fill="none" stroke="#f0a24a" stroke-width="1.6" stroke-linejoin="round"><path d="M5 2h7l4 4v12H5z"/><path d="M12 2v4h4"/><path d="M7.5 10h5M7.5 13h5" stroke-linecap="round"/></svg>',
    chords:'<svg viewBox="0 0 20 20" width="15" height="15" fill="none" stroke="#5aa9ff" stroke-width="1.6" stroke-linecap="round"><path d="M6 3v14M10 3v14M14 3v14M3 7h14M3 13h14"/></svg>',
    video: '<svg viewBox="0 0 20 20" width="16" height="16" fill="none"><rect x="2.5" y="4.5" width="15" height="11" rx="3" fill="#ff5a5a"/><path d="M8.5 8 L13 10 L8.5 12 Z" fill="#fff"/></svg>',
    audio: '<svg viewBox="0 0 20 20" width="15" height="15" fill="none" stroke="#4bc463" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 15V5l8-2v10"/><circle cx="5" cy="15" r="2" fill="#4bc463" stroke="none"/><circle cx="13" cy="13" r="2" fill="#4bc463" stroke="none"/></svg>',
    link:  '<svg viewBox="0 0 20 20" width="15" height="15" fill="none" stroke="#9a9aa4" stroke-width="1.6" stroke-linecap="round"><path d="M8 12a3 3 0 0 0 4 0l2-2a3 3 0 0 0-4-4l-1 1"/><path d="M12 8a3 3 0 0 0-4 0l-2 2a3 3 0 0 0 4 4l1-1"/></svg>'
  };
  var RES_EXT = '<svg class="ext" viewBox="0 0 20 20" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4h9v9"/><path d="M16 4 L8 12"/><path d="M13 5H5v10h10v-8"/></svg>';
  var RES_TYPES = [['tab','Tab / Chart'],['chords','Chords'],['video','Video lesson'],['audio','Audio ref'],['link','Other link']];
  var RES_TYPE_NAME = { tab:'Tab', chords:'Chords', video:'Video', audio:'Audio', link:'Link' };

  function resIco(t){ return RES_ICONS[t] || RES_ICONS.link; }
  function resEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function resTypeOptionsHtml(sel){ return RES_TYPES.map(function(t){ return '<option value="' + t[0] + '"' + (t[0] === sel ? ' selected' : '') + '>' + t[1] + '</option>'; }).join(''); }
  var RES_PENCIL = '<svg viewBox="0 0 20 20" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12.5 3.5l4 4L7 17H3v-4z"/><path d="M11 5l4 4"/></svg>';

  // Local store of delete tokens for band items THIS browser added: { id: secret }.
  function resTokens(){ try { return JSON.parse(localStorage.getItem('smx-res-tokens') || '{}') || {}; } catch(_) { return {}; } }
  function resSaveToken(id, secret){ try { var m = resTokens(); m[id] = secret; localStorage.setItem('smx-res-tokens', JSON.stringify(m)); } catch(_){} }
  function resDropToken(id){ try { var m = resTokens(); delete m[id]; localStorage.setItem('smx-res-tokens', JSON.stringify(m)); } catch(_){} }
  function resMine(id){ var m = resTokens(); return Object.prototype.hasOwnProperty.call(m, id); }

  var resCurSong = null; // the song whose resources are currently shown
  var resEditId = null;  // id of the resource currently being edited inline (or null)

  // Mirror the panel's open state onto <body> so the backdrop scrim (a body-level
  // sibling) can show/hide with it. Called wherever #resWrap.open changes.
  function resSyncScrim(){
    var w = document.getElementById('resWrap');
    document.body.classList.toggle('res-open', !!(w && w.classList.contains('open')));
  }

  function renderResources(song){
    var wrap = document.getElementById('resWrap');
    if (!wrap) return;
    if (song && (!resCurSong || resCurSong.slug !== song.slug)) resEditId = null; // drop stale edit on song change
    resCurSong = song || null;
    var list = (song && song.resources && song.resources.length) ? song.resources.slice() : [];
    var canAdd = SMX_BAND_AUTH;
    wrap.classList.remove('open');
    resSyncScrim();

    // Nothing to show and can't add → stay empty (CSS :empty hides it).
    if (!list.length && !canAdd) { wrap.innerHTML = ''; return; }

    // Exactly one link and no add affordance → a single direct button.
    if (list.length === 1 && !canAdd) {
      var r = list[0];
      wrap.innerHTML = '<a class="slink" href="' + resEsc(r.url) + '" target="_blank" rel="noopener">'
        + resIco(r.type) + resEsc(r.label || RES_TYPE_NAME[r.type] || 'Link') + RES_EXT + '</a>';
      return;
    }

    // Otherwise the collapsible list (also used for the 0-links-but-can-add case).
    var rows = '';
    if (list.length) {
      rows += '<div class="reshead">' + list.length + ' resource' + (list.length === 1 ? '' : 's') + '</div>';
      list.forEach(function(r){
        var mine = (r.src === 'band' && resMine(r.id));
        // Any band member may edit a MIXER-added (band) item; admin-added items are locked.
        var editable = SMX_BAND_AUTH && r.src === 'band';
        if (editable && r.id === resEditId) {
          rows += '<div class="resitem editing">'
            + '<div class="res-form open" id="resEditForm">'
            +   '<div class="res-msg" id="resEMsg"></div>'
            +   '<input type="url" id="resEUrl" value="' + resEsc(r.url) + '" placeholder="https://…" autocomplete="off">'
            +   '<input type="text" id="resELabel" maxlength="80" value="' + resEsc(r.label || '') + '" placeholder="Label (e.g. Guitar lesson)" autocomplete="off">'
            +   '<textarea id="resEDesc" maxlength="160" rows="2" placeholder="Description (optional)">' + resEsc(r.desc || '') + '</textarea>'
            +   '<select id="resEType">' + resTypeOptionsHtml(r.type) + '</select>'
            +   '<div class="res-frow"><button class="res-save" id="resESaveBtn">Save</button><button class="res-cancel" id="resECancelBtn">Cancel</button></div>'
            + '</div></div>';
          return;
        }
        var desc = (r.desc || '').toString();
        rows += '<div class="resitem' + (mine ? ' res-mine' : '') + '">'
          + '<a class="resitem-open" href="' + resEsc(r.url) + '" target="_blank" rel="noopener">'
          +   '<span class="resico">' + resIco(r.type) + '</span>'
          +   '<span class="restext">'
          +     '<span class="res-l1"><span class="lab">' + resEsc(r.label || RES_TYPE_NAME[r.type] || 'Link') + '</span>'
          +       '<span class="typ">' + resEsc(RES_TYPE_NAME[r.type] || 'Link') + '</span></span>'
          +     (desc ? '<span class="res-desc">' + resEsc(desc) + '</span>' : '')
          +   '</span>' + RES_EXT
          + '</a>'
          + (editable ? '<button class="res-edit" data-id="' + resEsc(r.id) + '" title="Edit this resource">' + RES_PENCIL + '</button>' : '')
          + '<button class="res-rm" data-id="' + resEsc(r.id) + '" title="Remove (you added this)">✕</button>'
          + '</div>';
      });
    } else {
      rows += '<div class="reshead" style="padding-bottom:4px;">No resources yet</div>';
    }
    if (canAdd) {
      if (list.length) rows += '<div class="res-sep"></div>';
      rows += '<button class="res-add" id="resAddBtn">+ Add a resource</button>'
        + '<div class="res-form" id="resForm">'
        +   '<div class="res-msg" id="resMsg"></div>'
        +   '<input type="url" id="resUrl" placeholder="https://… (paste any link)" autocomplete="off">'
        +   '<input type="text" id="resLabel" placeholder="Label (optional, e.g. Guitar lesson)" maxlength="80" autocomplete="off">'
        +   '<textarea id="resDesc" class="res-desc-in" placeholder="Description (optional) — e.g. note-for-note guitar, slow then full speed" maxlength="160" rows="2"></textarea>'
        +   '<select id="resType"><option value="">Type: auto-detect from link</option>' + RES_TYPES.map(function(t){ return '<option value="' + t[0] + '">' + t[1] + '</option>'; }).join('') + '</select>'
        +   '<div class="res-frow"><button class="res-save" id="resSaveBtn">Add</button><button class="res-cancel" id="resCancelBtn">Cancel</button></div>'
        + '</div>';
    }

    wrap.innerHTML =
      '<button class="resbtn" id="resBtn" aria-haspopup="true">'
      +   '<span class="r-ico"><svg viewBox="0 0 20 20" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"><path d="M4 5h12M4 10h12M4 15h8"/></svg></span>'
      +   'Resources' + (list.length ? ' <span class="cnt">' + list.length + '</span>' : '')
      +   '<span class="car"><svg width="11" height="7" viewBox="0 0 12 8"><path d="M1 1 L6 6 L11 1" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg></span>'
      + '</button>'
      + '<div class="reslist" id="resList">' + rows + '</div>';

    wireResources(wrap);
  }

  function wireResources(wrap){
    var btn = wrap.querySelector('#resBtn');
    if (btn) btn.addEventListener('click', function(e){
      e.stopPropagation();
      var opening = !wrap.classList.contains('open');
      wrap.classList.toggle('open');
      resSyncScrim();
      // If we're opening Resources while the banner song-list is open, close that.
      if (opening) { try { closeDropdown(); } catch(_){} }
    });
    // Keep the panel open when interacting with the form/rows.
    var listEl = wrap.querySelector('#resList');
    if (listEl) listEl.addEventListener('click', function(e){ if (e.target.closest('#resForm') || e.target.closest('#resEditForm')) e.stopPropagation(); });

    var addBtn = wrap.querySelector('#resAddBtn'), form = wrap.querySelector('#resForm');
    if (addBtn && form) {
      addBtn.addEventListener('click', function(e){ e.stopPropagation(); form.classList.add('open'); addBtn.style.display='none'; var u=wrap.querySelector('#resUrl'); if(u) u.focus(); });
      var cancel = wrap.querySelector('#resCancelBtn');
      if (cancel) cancel.addEventListener('click', function(e){ e.stopPropagation(); form.classList.remove('open'); addBtn.style.display=''; resSetMsg(wrap,''); });
      var save = wrap.querySelector('#resSaveBtn');
      if (save) save.addEventListener('click', function(e){ e.stopPropagation(); resSubmitAdd(wrap); });
    }
    // Remove buttons (CSS-gated to this device's own band items).
    var rms = wrap.querySelectorAll('.res-rm');
    for (var i = 0; i < rms.length; i++) {
      rms[i].addEventListener('click', function(e){ e.stopPropagation(); resSubmitDel(wrap, this.getAttribute('data-id')); });
    }
    // Edit buttons (any band member, any mixer-added item) → open inline editor.
    function reopen(){ var w2 = document.getElementById('resWrap'); if (w2) w2.classList.add('open'); resSyncScrim(); }
    var eds = wrap.querySelectorAll('.res-edit');
    for (var j = 0; j < eds.length; j++) {
      eds[j].addEventListener('click', function(e){ e.stopPropagation(); resEditId = this.getAttribute('data-id'); renderResources(resCurSong); reopen(); });
    }
    var eSave = wrap.querySelector('#resESaveBtn'), eCancel = wrap.querySelector('#resECancelBtn');
    if (eSave)   eSave.addEventListener('click',  function(e){ e.stopPropagation(); resSubmitEdit(wrap, resEditId); });
    if (eCancel) eCancel.addEventListener('click',function(e){ e.stopPropagation(); resEditId = null; renderResources(resCurSong); reopen(); });
  }

  function resSetMsg(wrap, msg, isErr){
    var m = wrap.querySelector('#resMsg'); if (!m) return;
    m.textContent = msg || ''; m.classList.toggle('err', !!isErr);
  }

  function resSubmitAdd(wrap){
    if (!resCurSong) return;
    var url = (wrap.querySelector('#resUrl') || {}).value || '';
    var label = (wrap.querySelector('#resLabel') || {}).value || '';
    var desc = (wrap.querySelector('#resDesc') || {}).value || '';
    var type = (wrap.querySelector('#resType') || {}).value || '';
    url = url.trim();
    if (!/^https?:\/\//i.test(url)) { resSetMsg(wrap, 'Enter a full http(s) link.', true); return; }
    resSetMsg(wrap, 'Adding…', false);
    var save = wrap.querySelector('#resSaveBtn'); if (save) save.disabled = true;
    var fd = new FormData();
    fd.append('action', 'smx_res_add'); fd.append('nonce', SMX_RES_NONCE);
    fd.append('slug', resCurSong.slug); fd.append('url', url); fd.append('label', label.trim()); fd.append('desc', desc.trim()); fd.append('type', type);
    fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(res){
        if (save) save.disabled = false;
        if (!res || !res.success) { resSetMsg(wrap, resErrText(res), true); return; }
        var d = res.data || {};
        if (d.id && d.secret) resSaveToken(d.id, d.secret); // remember so THIS device can remove it
        resCurSong.resources = d.resources || [];
        // reflect into the master SONGS array so re-selecting the song keeps it
        for (var i = 0; i < SONGS.length; i++) { if (SONGS[i].slug === resCurSong.slug) { SONGS[i].resources = resCurSong.resources; break; } }
        renderResources(resCurSong);
        var w2 = document.getElementById('resWrap'); if (w2) w2.classList.add('open'); resSyncScrim(); // keep it open after re-render
      })
      .catch(function(){ if (save) save.disabled = false; resSetMsg(wrap, 'Network error — try again.', true); });
  }

  function resSubmitDel(wrap, id){
    if (!resCurSong || !id) return;
    var fd = new FormData();
    fd.append('action', 'smx_res_del'); fd.append('nonce', SMX_RES_NONCE);
    fd.append('slug', resCurSong.slug); fd.append('id', id);
    var tok = resTokens(); if (tok[id]) fd.append('secret', tok[id]);
    fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(res){
        if (!res || !res.success) return;
        resDropToken(id);
        resCurSong.resources = (res.data && res.data.resources) || [];
        for (var i = 0; i < SONGS.length; i++) { if (SONGS[i].slug === resCurSong.slug) { SONGS[i].resources = resCurSong.resources; break; } }
        renderResources(resCurSong);
        var w2 = document.getElementById('resWrap'); if (w2) w2.classList.add('open');
        resSyncScrim();
      })
      .catch(function(){});
  }

  function resErrText(res){
    var c = res && res.data ? res.data : '';
    if (c === 'bad-url')    return 'That doesn’t look like a valid link.';
    if (c === 'not-authed') return 'Session expired — reload and re-enter the band password.';
    if (c === 'too-many')   return 'This song already has the max of 20 resources.';
    if (c === 'slow-down')  return 'Too many adds just now — give it a minute.';
    return 'Couldn’t add that — try again.';
  }

  function resEditMsg(wrap, msg, isErr){
    var m = wrap.querySelector('#resEMsg'); if (!m) return;
    m.textContent = msg || ''; m.classList.toggle('err', !!isErr);
  }
  function resEditErr(res){
    var c = res && res.data ? res.data : '';
    if (c === 'locked')     return 'That link was added in Settings — only the admin can change it.';
    if (c === 'bad-url')    return 'That doesn’t look like a valid link.';
    if (c === 'not-authed') return 'Session expired — reload and re-enter the band password.';
    if (c === 'slow-down')  return 'Too many changes just now — give it a minute.';
    return 'Couldn’t save that — try again.';
  }

  // Edit an existing mixer-added resource (any band member; admin items are locked server-side).
  function resSubmitEdit(wrap, id){
    if (!resCurSong || !id) return;
    var url = (wrap.querySelector('#resEUrl') || {}).value || '';
    var label = (wrap.querySelector('#resELabel') || {}).value || '';
    var desc = (wrap.querySelector('#resEDesc') || {}).value || '';
    var type = (wrap.querySelector('#resEType') || {}).value || '';
    url = url.trim();
    if (!/^https?:\/\//i.test(url)) { resEditMsg(wrap, 'Enter a full http(s) link.', true); return; }
    resEditMsg(wrap, 'Saving…', false);
    var save = wrap.querySelector('#resESaveBtn'); if (save) save.disabled = true;
    var fd = new FormData();
    fd.append('action', 'smx_res_edit'); fd.append('nonce', SMX_RES_NONCE);
    fd.append('slug', resCurSong.slug); fd.append('id', id);
    fd.append('url', url); fd.append('label', label.trim()); fd.append('desc', desc.trim()); fd.append('type', type);
    fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(res){
        if (save) save.disabled = false;
        if (!res || !res.success) { resEditMsg(wrap, resEditErr(res), true); return; }
        resEditId = null;
        resCurSong.resources = (res.data && res.data.resources) || [];
        for (var i = 0; i < SONGS.length; i++) { if (SONGS[i].slug === resCurSong.slug) { SONGS[i].resources = resCurSong.resources; break; } }
        renderResources(resCurSong);
        var w2 = document.getElementById('resWrap'); if (w2) w2.classList.add('open'); resSyncScrim();
      })
      .catch(function(){ if (save) save.disabled = false; resEditMsg(wrap, 'Network error — try again.', true); });
  }

  // Close the resources panel on any outside click.
  document.addEventListener('click', function(e){
    var w = document.getElementById('resWrap');
    if (w && !e.target.closest('#resWrap')) w.classList.remove('open'); resSyncScrim();
  });

  /* ---------- Feedback modal: bug report / feature request → emails Chris ---------- */
  (function(){
    var modal = document.getElementById('fbModal'), backdrop = document.getElementById('fbBackdrop');
    if (!modal) return;
    var titleEl = document.getElementById('fbTitle'), subEl = document.getElementById('fbSub'),
        msgEl = document.getElementById('fbMessage'), emailEl = document.getElementById('fbEmail'),
        statusEl = document.getElementById('fbStatus'), sendBtn = document.getElementById('fbSend');
    var kind = 'bug';
    var COPY = {
      bug:     { title: 'Report a <b>bug</b>',    sub: 'Found something broken? Tell Chris what happened and he’ll take a look.', ph: 'What happened? What were you trying to do?' },
      feature: { title: 'Request a <b>feature</b>', sub: 'Got an idea to make STEMMAXXER better? Send it to Chris.',                     ph: 'What would you like STEMMAXXER to do?' }
    };
    function setStatus(t, cls){ statusEl.textContent = t || ''; statusEl.className = 'fb-msg' + (cls ? ' ' + cls : ''); }
    function open(k){
      kind = (k === 'feature') ? 'feature' : 'bug';
      titleEl.innerHTML = COPY[kind].title; subEl.textContent = COPY[kind].sub; msgEl.placeholder = COPY[kind].ph;
      setStatus(''); msgEl.value = ''; if (sendBtn) sendBtn.disabled = false;
      document.body.classList.add('fb-open');
      modal.setAttribute('aria-hidden', 'false'); backdrop.setAttribute('aria-hidden', 'false');
      setTimeout(function(){ msgEl.focus(); }, 40);
    }
    function close(){ document.body.classList.remove('fb-open'); modal.setAttribute('aria-hidden', 'true'); backdrop.setAttribute('aria-hidden', 'true'); }
    function submit(){
      var message = (msgEl.value || '').trim();
      if (message.length < 3) { setStatus('Please add a little more detail.', 'err'); msgEl.focus(); return; }
      setStatus('Sending…'); if (sendBtn) sendBtn.disabled = true;
      var song = (typeof SONGS !== 'undefined' && resCurSong) ? ((resCurSong.artist || '') + ' — ' + (resCurSong.title || '')) : '';
      var ctx = (song ? song + '  ' : '') + '[' + (window.innerWidth || 0) + 'px]';
      var fd = new FormData();
      fd.append('action', 'smx_feedback'); fd.append('nonce', SMX_FB_NONCE);
      fd.append('kind', kind); fd.append('message', message);
      fd.append('from', (emailEl.value || '').trim()); fd.append('context', ctx);
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(res){
          if (sendBtn) sendBtn.disabled = false;
          if (res && res.success) { setStatus('Thanks — sent! ✓', 'ok'); setTimeout(close, 1100); }
          else { setStatus(fbErr(res), 'err'); }
        })
        .catch(function(){ if (sendBtn) sendBtn.disabled = false; setStatus('Network error — try again.', 'err'); });
    }
    function fbErr(res){
      var c = res && res.data ? res.data : '';
      if (c === 'empty')       return 'Please write a message first.';
      if (c === 'slow-down')   return 'Too many just now — give it a few minutes.';
      if (c === 'send-failed') return 'Couldn’t send the email — tell Chris directly if it keeps failing.';
      return 'Couldn’t send that — try again.';
    }
    var bugBtn = document.getElementById('fbBugBtn'), featBtn = document.getElementById('fbFeatBtn');
    if (bugBtn)  bugBtn.addEventListener('click', function(){ open('bug'); });
    if (featBtn) featBtn.addEventListener('click', function(){ open('feature'); });
    document.getElementById('fbClose').addEventListener('click', close);
    document.getElementById('fbCancel').addEventListener('click', close);
    backdrop.addEventListener('click', close);
    sendBtn.addEventListener('click', submit);
    // Cmd/Ctrl+Enter sends; Esc closes (only while open).
    modal.addEventListener('keydown', function(e){
      if (e.key === 'Escape') { e.stopPropagation(); close(); }
      else if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(); }
    });
  })();

  var ddScroll = $('ddScroll');

  /* Custom scrollbar sync for the song list */
  function syncDdSb() {
    var sb = $('ddSb'), th = $('ddSbThumb');
    if (ddScroll.scrollHeight <= ddScroll.clientHeight + 1) { sb.classList.add('hide'); return; }
    sb.classList.remove('hide');
    var trackH = sb.clientHeight;
    var h = Math.max(30, trackH * ddScroll.clientHeight / ddScroll.scrollHeight);
    var top = (trackH - h) * (ddScroll.scrollTop / (ddScroll.scrollHeight - ddScroll.clientHeight));
    th.style.height = h + 'px';
    th.style.top = top + 'px';
  }
  ddScroll.addEventListener('scroll', syncDdSb);
  (function () {
    var th = $('ddSbThumb'), sb = $('ddSb');
    var drag = null;
    th.addEventListener('mousedown', function (e) {
      drag = { y: e.clientY, start: ddScroll.scrollTop };
      th.classList.add('drag');
      e.preventDefault();
      e.stopPropagation();
    });
    window.addEventListener('mousemove', function (e) {
      if (!drag) return;
      var trackH = sb.clientHeight, thumbH = th.offsetHeight;
      var range = ddScroll.scrollHeight - ddScroll.clientHeight;
      ddScroll.scrollTop = drag.start + (e.clientY - drag.y) * (range / Math.max(1, trackH - thumbH));
    });
    window.addEventListener('mouseup', function () {
      if (drag) { drag = null; th.classList.remove('drag'); }
    });
    sb.addEventListener('mousedown', function (e) {
      if (e.target === th) return;
      var rect = sb.getBoundingClientRect();
      var pct = (e.clientY - rect.top) / rect.height;
      ddScroll.scrollTop = pct * (ddScroll.scrollHeight - ddScroll.clientHeight);
      e.stopPropagation();
    });
  })();

  function buildDropdown() {
    ddScroll.innerHTML = '';
    SONGS.forEach(function (s, i) {
      var it = document.createElement('div');
      it.className = 'dd-item' + (i === currentSongIdx ? ' sel' : '') + (i === highlightedIdx ? ' hl' : '');
      it.setAttribute('role', 'option');
      var num = document.createElement('span');
      num.className = 'num';
      num.textContent = (i + 1 < 10 ? '0' : '') + (i + 1);
      it.appendChild(num);
      var lbl = document.createElement('span');
      if (s.artist) {
        var art = document.createElement('span');
        art.className = 'art';
        art.textContent = s.artist + ' — ';
        lbl.appendChild(art);
      }
      lbl.appendChild(document.createTextNode(s.title));
      it.appendChild(lbl);
      it.addEventListener('click', function () { selectSong(i); closeDropdown(); });
      ddScroll.appendChild(it);
    });
    syncDdSb();
  }

  function openDropdown() {
    ddWrap.classList.add('open');
    ddList.classList.add('show');              // shows the list even when it's re-parented to the banner
    document.body.classList.add('dd-open');    // rotates the banner caret
    ddButton.setAttribute('aria-expanded', 'true');
    highlightedIdx = currentSongIdx;
    buildDropdown();
    var sel = ddScroll.children[highlightedIdx];
    if (sel) sel.scrollIntoView({ block: 'nearest' });
  }
  function closeDropdown() {
    ddWrap.classList.remove('open');
    ddList.classList.remove('show');
    document.body.classList.remove('dd-open');
    ddButton.setAttribute('aria-expanded', 'false');
    highlightedIdx = -1;
    typeaheadBuffer = '';
  }
  ddButton.addEventListener('click', function (e) {
    e.stopPropagation();
    if (ddWrap.classList.contains('open')) closeDropdown(); else openDropdown();
  });
  document.addEventListener('click', function (e) {
    if (!ddWrap.classList.contains('open')) return;
    // In banner mode the list lives inside .nowsong, so treat that as "inside" too.
    var bmode = document.body.classList.contains('smx-bannersel');
    if (!e.target.closest('#dropdown') && !(bmode && e.target.closest('#nowsong'))) closeDropdown();
  });

  /* Banner-as-selector (beta 'bannersel'): the big band/song banner opens the same list. */
  (function () {
    var banner = document.getElementById('nowsong');
    if (!banner) return;
    function active(){ return document.body.classList.contains('smx-bannersel'); }
    banner.addEventListener('click', function (e) {
      if (!active()) return;
      if (e.target.closest('#resWrap')) return;    // the Resources box is its own dropdown, not the song picker
      if (e.target.closest('#ddList')) return;     // clicks inside the open list are handled by items
      e.stopPropagation();
      if (ddWrap.classList.contains('open')) closeDropdown(); else openDropdown();
    });
    banner.addEventListener('keydown', function (e) {
      if (!active()) return;
      // Don't hijack typing in the Resources add-form fields — they live INSIDE #nowsong,
      // so their keystrokes bubble here. Ignore anything from the Resources panel or any
      // editable element (else a letter triggers the song typeahead instead of typing).
      if (e.target.closest('#resWrap')) return;
      var _tn = e.target.tagName;
      if (_tn === 'INPUT' || _tn === 'TEXTAREA' || _tn === 'SELECT' || e.target.isContentEditable) return;
      var open = ddWrap.classList.contains('open');
      if (e.code === 'ArrowDown' || e.code === 'ArrowUp') {
        e.preventDefault(); e.stopPropagation();
        if (!open) { openDropdown(); return; }
        var max = SONGS.length - 1;
        highlightedIdx = Math.max(0, Math.min(max, (highlightedIdx < 0 ? 0 : highlightedIdx + (e.code === 'ArrowDown' ? 1 : -1))));
        buildDropdown();
        var el = ddScroll.children[highlightedIdx]; if (el) el.scrollIntoView({ block: 'nearest' });
        return;
      }
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault(); e.stopPropagation();
        if (open && highlightedIdx >= 0) { selectSong(highlightedIdx); closeDropdown(); }
        else if (open) closeDropdown(); else openDropdown();
        return;
      }
      if (e.code === 'Escape') { e.preventDefault(); e.stopPropagation(); closeDropdown(); return; }
      if (e.key.length === 1 && /^[a-zA-Z0-9]$/.test(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault(); e.stopPropagation();
        if (typeaheadTimer) clearTimeout(typeaheadTimer);
        typeaheadBuffer += e.key.toLowerCase();
        typeaheadTimer = setTimeout(function () { typeaheadBuffer = ''; }, 800);
        var idx = -1;
        for (var i = 0; i < SONGS.length; i++) {
          var a = (SONGS[i].artist || '').toLowerCase(), t = (SONGS[i].title || '').toLowerCase();
          if (a.indexOf(typeaheadBuffer) === 0 || t.indexOf(typeaheadBuffer) === 0) { idx = i; break; }
        }
        if (idx >= 0) {
          if (!open) openDropdown();
          highlightedIdx = idx; buildDropdown();
          var el2 = ddScroll.children[idx]; if (el2) el2.scrollIntoView({ block: 'nearest' });
        }
      }
    });
  })();

  ddButton.addEventListener('keydown', function (e) {
    var open = ddWrap.classList.contains('open');
    if (e.code === 'ArrowDown' || e.code === 'ArrowUp') {
      e.preventDefault();
      if (!open) { openDropdown(); return; }
      var max = SONGS.length - 1;
      highlightedIdx = Math.max(0, Math.min(max, (highlightedIdx < 0 ? 0 : highlightedIdx + (e.code === 'ArrowDown' ? 1 : -1))));
      buildDropdown();
      var el = ddScroll.children[highlightedIdx];
      if (el) el.scrollIntoView({ block: 'nearest' });
      return;
    }
    if (e.code === 'Enter' || e.code === 'Space') {
      e.preventDefault();
      if (open && highlightedIdx >= 0) { selectSong(highlightedIdx); closeDropdown(); }
      else if (open) closeDropdown();
      else openDropdown();
      return;
    }
    if (e.code === 'Escape') { e.preventDefault(); closeDropdown(); return; }
    if (e.key.length === 1 && /^[a-zA-Z0-9]$/.test(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      if (typeaheadTimer) clearTimeout(typeaheadTimer);
      typeaheadBuffer += e.key.toLowerCase();
      typeaheadTimer = setTimeout(function () { typeaheadBuffer = ''; }, 800);
      var idx = -1;
      for (var i = 0; i < SONGS.length; i++) {
        var a = (SONGS[i].artist || '').toLowerCase(), t = (SONGS[i].title || '').toLowerCase();
        if (a.indexOf(typeaheadBuffer) === 0 || t.indexOf(typeaheadBuffer) === 0) { idx = i; break; }
      }
      if (idx >= 0) {
        if (!ddWrap.classList.contains('open')) openDropdown();
        highlightedIdx = idx;
        buildDropdown();
        var el2 = ddScroll.children[idx];
        if (el2) el2.scrollIntoView({ block: 'nearest' });
      }
    }
  });

  function selectSong(idx) {
    if (idx < 0 || idx >= SONGS.length) return;
    currentSongIdx = idx;
    try { sessionStorage.setItem('stemmaxxer-song', String(idx)); } catch (_) {}
    loadSong(idx);
  }

  /* ============================================================
   * STEMMAXXER LITE — mobile CONSOLE skin (v2.0.0)
   * A second control surface over the SAME engine + state. No audio
   * code lives here: every control calls the desktop engine functions
   * (loadSong / togglePlay / seekTo / applyState / applyFeature /
   * setRate / setLoop* / selectSong). Visible only <=900px when the
   * `mobile` beta feature is active (body.smx-mobile). Built this pass:
   * the CONSOLE (rows) skin. PADS + chooser + skin switcher come next.
   * ============================================================ */
  var liteEl = null, liteRowsEl = null, liteBuilt = false, liteRowCache = [];
  var LITE_SPEEDS = [1, 0.9, 0.8, 0.75, 0.7, 0.6, 0.5];
  function $L(id){ return document.getElementById(id); }
  function liteEsc(x){ return String(x == null ? '' : x).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function liteActive(){ return liteEl && document.body.classList.contains('smx-mobile') && window.matchMedia('(max-width:900px)').matches; }
  function liteIsUtil(name){ return /count|click|metronome/i.test(name); }
  function liteFind(re){ for (var i = 0; i < tracks.length; i++){ if (re.test(tracks[i].name)) return i; } return -1; }
  function onTap(el, fn){ if (el) el.addEventListener('click', function(e){ e.preventDefault(); fn(e); }); }
  function liteSetLoading(on){ var el = liteEl || document.getElementById('smxLite'); if (el) el.classList.toggle('loading', !!on); }
  function liteSetProgress(done, total, pct){
    var c = $L('liteLoadCount'), pc = $L('liteLoadPct'), f = $L('liteLoadFill');
    if (c) c.textContent = done + ' of ' + total;
    if (pc) pc.textContent = Math.round(pct) + '%';
    if (f) f.style.width = pct + '%';
  }

  function liteBuild(){
    liteEl = liteEl || $L('smxLite');
    if (!liteEl) return;
    liteRowsEl = liteRowsEl || $L('liteRows');
    var song = SONGS[currentSongIdx] || {};
    var a = $L('liteArtist'), t = $L('liteTitle');
    if (a) a.textContent = (song.artist || '').toUpperCase();
    if (t) t.textContent = (song.title || '').toUpperCase();
    var html = '', vis = 0;
    for (var i = 0; i < tracks.length; i++){
      if (liteIsUtil(tracks[i].name)) continue; // Count In / Click live as chips, not rows
      vis++; // renumber visible strips: first musical stem = 1 (Count In no longer takes slot 1)
      html += '<div class="lite-row" data-i="' + i + '">'
           +    '<button class="lr-feat" data-i="' + i + '" type="button">+</button>'
           +    '<div class="lr-name">' + liteEsc(tracks[i].name) + '</div>'
           +    '<div class="lr-lane" data-i="' + i + '"><div class="lr-zones"></div><div class="lr-cover"></div><div class="lr-slits"></div><div class="lr-grip"></div><div class="lr-err" data-i="' + i + '">\u26A0 FILE ERROR <span class="rbtn">RETRY</span></div></div>'
           +    '<div class="lr-ms"><button class="lr-m" data-i="' + i + '" type="button"><span class="fl"></span><span class="lt">M</span></button><button class="lr-s" data-i="' + i + '" type="button"><span class="fl"></span><span class="lt">S</span></button></div>'
           +  '</div>';
    }
    if (liteRowsEl) liteRowsEl.innerHTML = html;
    liteRowCache = [];
    if (liteRowsEl){
      var rows = liteRowsEl.querySelectorAll('.lite-row');
      for (var k = 0; k < rows.length; k++){
        var el = rows[k];
        liteRowCache.push({ i: +el.getAttribute('data-i'), row: el,
          cover: el.querySelector('.lr-cover'), grip: el.querySelector('.lr-grip'),
          m: el.querySelector('.lr-m'), s: el.querySelector('.lr-s'), feat: el.querySelector('.lr-feat') });
      }
    }
    liteBuilt = true;
    liteChips();
  }

  function liteChips(){
    var sv = $L('liteSpeedVal'); if (sv) sv.textContent = 'SPEED ' + Math.round(rate * 100) + '%';
    var idx = LITE_SPEEDS.indexOf(rate);
    var su = $L('liteSpeedUp'), sd = $L('liteSpeedDown');
    if (su) su.classList.toggle('dis', idx <= 0);                       // already at 100% -> can't speed up
    if (sd) sd.classList.toggle('dis', idx >= LITE_SPEEDS.length - 1);  // already at 50% -> can't slow down
    var bp = $L('liteBpm'); if (bp) bp.textContent = songBpm ? String(Math.round(songBpm)) : '—';
    liteUtilChip('liteCountin', /count/i);
    liteUtilChip('liteClick', /click|metronome/i);
  }
  function liteUtilChip(id, re){
    var c = $L(id); if (!c) return;
    var idx = liteFind(re);
    if (idx < 0){ c.classList.add('disabled'); c.classList.remove('on'); return; }
    c.classList.remove('disabled');
    c.classList.toggle('on', !tracks[idx].muted);
  }
  function liteToggleUtil(re){
    var idx = liteFind(re); if (idx < 0) return;
    tracks[idx].muted = !tracks[idx].muted; applyState(); liteChips();
  }

  function litePlayIcon(on){
    var p = $L('litePlayIco'), q = $L('litePauseIco');
    if (p) p.style.display = on ? 'none' : '';
    if (q) q.style.display = on ? '' : 'none';
  }

  function liteFrame(){
    requestAnimationFrame(liteFrame);
    if (!liteActive() || !liteBuilt) return;
    var dur = duration || 0, ph = Math.min(dur, currentPlayhead());
    var f = $L('liteFill'); if (f) f.style.width = (dur > 0 ? (ph / dur * 100) : 0) + '%';
    var e = $L('liteElapsed'); if (e) e.textContent = fmt(ph);
    var tt = $L('liteTotal'); if (tt) tt.textContent = fmt(dur);
    // A/B loop: button states + region/flags on the bar
    var la = $L('liteLoopA'), lb = $L('liteLoopB'), lt = $L('liteLoopToggle'), lc = $L('liteLoopClear');
    if (la) la.classList.toggle('set', loopA !== null);
    if (lb) lb.classList.toggle('set', loopB !== null);
    if (lt) lt.classList.toggle('on', !!loopEnabled);
    if (lc) lc.classList.toggle('dis', loopA === null && loopB === null);
    var reg = $L('liteRegion'), fa = $L('liteFlagA'), fb = $L('liteFlagB');
    var aP = dur > 0 ? (loopA !== null ? loopA : 0) / dur * 100 : 0;
    var bP = dur > 0 ? (loopB !== null ? loopB : dur) / dur * 100 : 100;
    if (fa){ if (loopA !== null && dur > 0){ fa.style.display = ''; fa.style.left = aP + '%'; } else fa.style.display = 'none'; }
    if (fb){ if (loopB !== null && dur > 0){ fb.style.display = ''; fb.style.left = bP + '%'; } else fb.style.display = 'none'; }
    if (reg){ if ((loopA !== null || loopB !== null) && dur > 0){ reg.style.display = ''; reg.style.left = aP + '%'; reg.style.width = Math.max(0, bP - aP) + '%'; } else reg.style.display = 'none'; }
    litePlayIcon(playing);
    liteChips();
    var anySolo = tracks.some(function(t){ return t.soloed && !t.failed; });
    for (var c = 0; c < liteRowCache.length; c++){
      var r = liteRowCache[c], t = tracks[r.i]; if (!t) continue;
      var sig = (WB.meters && playing && !stretchActive() && !t.failed) ? t.meterDisp : t.fader;
      var lit = Math.min(sig, t.fader); // meter never rises past the handle (handle = ceiling)
      var zc = zoneClass(lit); // green/yellow/orange/red by WB thresholds — drives Solid Fill color
      if (r.zone !== zc){ r.row.classList.remove('z0','z1','z2','z3'); r.row.classList.add(zc); r.zone = zc; }
      r.cover.style.left = (lit * 100) + '%';
      r.grip.style.left = (t.fader * 100) + '%';
      r.grip.style.marginLeft = (-t.fader * 16) + 'px'; // inset so the handle's right edge never slips behind the M/S bay
      var ducked = anySolo && !t.soloed && !t.muted, foc = (activeFeature === t.name);
      var frame = foc ? 'st-focus' : (t.soloed ? 'st-solo' : (t.muted ? 'st-mute' : ''));  // focus > solo > mute
      if (r.frame !== frame){ r.row.classList.remove('st-focus','st-solo','st-mute'); if (frame) r.row.classList.add(frame); r.frame = frame; }
      r.row.classList.toggle('muted', !!t.muted);
      r.row.classList.toggle('ducked', ducked);
      r.row.classList.toggle('failed', !!t.failed);
      r.m.classList.toggle('on', !!t.muted);
      r.s.classList.toggle('on', !!t.soloed);
      if (r.feat){ r.feat.textContent = foc ? '−' : '+'; r.feat.classList.toggle('on', foc); }
    }
  }

  function liteOpenSheet(){
    var sheet = $L('liteSheet'), list = $L('liteSheetList'); if (!sheet || !list) return;
    var html = '';
    for (var i = 0; i < SONGS.length; i++){
      var so = SONGS[i];
      html += '<button class="ls-item' + (i === currentSongIdx ? ' sel' : '') + '" data-i="' + i + '" type="button">'
           +    '<span class="lsi-a">' + liteEsc((so.artist || '').toUpperCase()) + '</span>'
           +    '<span class="lsi-t">' + liteEsc((so.title || '').toUpperCase()) + '</span></button>';
    }
    list.innerHTML = html; sheet.classList.add('open');
  }
  function liteCloseSheet(){ var sheet = $L('liteSheet'); if (sheet) sheet.classList.remove('open'); }

  function liteWireRows(){
    if (!liteRowsEl) return;
    liteRowsEl.addEventListener('click', function(e){
      var er = e.target.closest('.lr-err');
      if (er){ retryStem(+er.getAttribute('data-i')); return; }
      var ft = e.target.closest('.lr-feat');
      if (ft){ var fi = +ft.getAttribute('data-i'); applyFeature(tracks[fi].name); if (typeof updateFeatureButtons === 'function') updateFeatureButtons(); return; }
      var m = e.target.closest('.lr-m'), sB = e.target.closest('.lr-s');
      if (m){ var i = +m.getAttribute('data-i'); tracks[i].muted = !tracks[i].muted; applyState(); return; }
      if (sB){ var j = +sB.getAttribute('data-i'); tracks[j].soloed = !tracks[j].soloed; applyState(); return; }
    });
    var dragI = -1, lane = null;
    function setFromX(x){
      if (dragI < 0 || !lane) return;
      var rc = lane.getBoundingClientRect();
      var v = Math.max(0, Math.min(1, (x - rc.left) / rc.width));
      tracks[dragI].fader = v;
      if (activeFeature){ activeFeature = null; if (typeof updateFeatureButtons === 'function') updateFeatureButtons(); }
      applyState(); if (typeof renderFader === 'function') renderFader(tracks[dragI]);
    }
    liteRowsEl.addEventListener('pointerdown', function(e){
      var l = e.target.closest('.lr-lane'); if (!l) return;
      dragI = +l.getAttribute('data-i'); if (tracks[dragI] && tracks[dragI].failed) { dragI = -1; return; } lane = l;
      if (l.setPointerCapture) { try { l.setPointerCapture(e.pointerId); } catch(_){} }
      setFromX(e.clientX); e.preventDefault();
    });
    liteRowsEl.addEventListener('pointermove', function(e){ if (dragI >= 0){ setFromX(e.clientX); e.preventDefault(); } });
    function endDrag(){ dragI = -1; lane = null; }
    liteRowsEl.addEventListener('pointerup', endDrag);
    liteRowsEl.addEventListener('pointercancel', endDrag);
  }

  function liteWireLoopFlags(){
    var sc = $L('liteScrub'); if (!sc) return;
    var which = null;
    function setFromX(x){
      if (!which) return;
      var rc = sc.getBoundingClientRect();
      var v = Math.max(0, Math.min(1, (x - rc.left) / rc.width)) * (duration || 0);
      if (which === 'a'){ loopA = v; if (loopB !== null && loopA >= loopB) loopA = Math.max(0, loopB - 0.05); }
      else { loopB = v; if (loopA !== null && loopB <= loopA) loopB = loopA + 0.05; }
      if (typeof updateLoopUI === 'function') updateLoopUI();
    }
    function mv(e){ setFromX(e.clientX); }
    function up(){ which = null; document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); }
    function start(w){ return function(e){ which = w; e.preventDefault(); e.stopPropagation(); setFromX((e.touches ? e.touches[0] : e).clientX); document.addEventListener('pointermove', mv); document.addEventListener('pointerup', up); }; }
    var fa = $L('liteFlagA'), fb = $L('liteFlagB');
    if (fa) fa.addEventListener('pointerdown', start('a'));
    if (fb) fb.addEventListener('pointerdown', start('b'));
  }

  function liteWireScrub(){
    var sc = $L('liteScrub'); if (!sc) return; var dragging = false;
    function seekFromX(x){ var rc = sc.getBoundingClientRect(); var v = Math.max(0, Math.min(1, (x - rc.left) / rc.width)); seekTo(v * (duration || 0)); }
    sc.addEventListener('pointerdown', function(e){ dragging = true; if (sc.setPointerCapture){ try { sc.setPointerCapture(e.pointerId); } catch(_){} } seekFromX(e.clientX); e.preventDefault(); });
    sc.addEventListener('pointermove', function(e){ if (dragging) seekFromX(e.clientX); });
    sc.addEventListener('pointerup', function(){ dragging = false; });
    sc.addEventListener('pointercancel', function(){ dragging = false; });
  }

  function liteInit(){
    liteEl = $L('smxLite'); if (!liteEl) return;
    liteRowsEl = $L('liteRows');
    // Device preview opt-in for phones: ?lite=1 turns on beta preview here, ?lite=0 clears it.
    try {
      if (/[?&]lite=1(?:&|$)/.test(location.search)) { localStorage.setItem('smx-beta', '1'); applyBeta(); }
      else if (/[?&]lite=0(?:&|$)/.test(location.search)) { localStorage.removeItem('smx-beta'); applyBeta(); }
    } catch (_) {}
    onTap($L('litePlay'), function(){ if (liteEl && liteEl.classList.contains('loading')) return; ensureContext(); togglePlay(); });
    onTap($L('liteBack'), function(){ seekTo(currentPlayhead() - 10); });
    onTap($L('liteFwd'), function(){ seekTo(currentPlayhead() + 10); });
    onTap($L('liteRestart'), function(){ if (liteEl && liteEl.classList.contains('loading')) return; ensureContext(); var b = $L('btnRestart'); if (b) b.click(); });
    onTap($L('liteReset'), function(){ var b = $L('btnReset'); if (b) b.click(); });
    onTap($L('liteBanner'), liteOpenSheet);
    onTap($L('liteSheetClose'), liteCloseSheet);
    onTap($L('liteLoopA'), function(){ setLoopA(); });
    onTap($L('liteLoopB'), function(){ setLoopB(); });
    onTap($L('liteLoopToggle'), function(){ toggleLoop(); });
    onTap($L('liteLoopClear'), function(){ clearLoop(); });
    liteWireLoopFlags();
    onTap($L('liteSpeedDown'), function(){ var i = LITE_SPEEDS.indexOf(rate); if (i < 0) i = 0; if (i < LITE_SPEEDS.length - 1){ setRate(LITE_SPEEDS[i + 1]); liteChips(); } });
    onTap($L('liteSpeedUp'), function(){ var i = LITE_SPEEDS.indexOf(rate); if (i > 0){ setRate(LITE_SPEEDS[i - 1]); liteChips(); } });
    (function(){ var sv = $L('liteSpeedVal'); if (!sv) return; var last = 0;   // double-tap the % -> reset to 100%
      sv.addEventListener('click', function(e){ e.preventDefault(); var n = +new Date(); if (n - last < 320){ setRate(1); liteChips(); last = 0; } else last = n; }); })();
    onTap($L('liteCountin'), function(){ liteToggleUtil(/count/i); });
    onTap($L('liteClick'), function(){ liteToggleUtil(/click|metronome/i); });
    var sl = $L('liteSheetList');
    if (sl) sl.addEventListener('click', function(e){ var it = e.target.closest('.ls-item'); if (!it) return; selectSong(+it.getAttribute('data-i')); liteCloseSheet(); });
    liteWireRows();
    liteWireScrub();
    if (tracks.length) liteBuild();
    requestAnimationFrame(liteFrame);
  }

  /* ============================================================
   * WORKBENCH wiring
   * ============================================================ */
  /* ---------- Whole-panel passkey lock (deploy passkey, remembered) ---------- */
  function wbStoredKey(){ try { return localStorage.getItem('smx-deploy-key') || sessionStorage.getItem('smx-deploy-key') || ''; } catch (_) { return ''; } }
  function wbUnlocked(){ return !SMX_KEY_SET || wbStoredKey() !== ''; } // no passkey set = nothing to lock; remembered = stays open
  function wbApplyLock(){ wbEl.classList.toggle('wb-locked', !wbUnlocked()); }

  function wbToggle(force) {
    var open = (force !== undefined) ? force : !wbEl.classList.contains('open');
    wbApplyLock();
    wbEl.classList.toggle('open', open);
    document.body.classList.toggle('wb-open', open);
    wbEl.setAttribute('aria-hidden', open ? 'false' : 'true');
    if (open && !wbUnlocked()) { var lk = $('wbLockKey'); if (lk) setTimeout(function(){ lk.focus(); }, 50); }
    tracks.forEach(renderFader); // strips reflow when content shifts
  }
  $('wbClose').addEventListener('click', function () { wbToggle(false); });

  (function () {
    var btn = $('wbLockBtn'), keyEl = $('wbLockKey'), msg = $('wbLockMsg');
    if (!btn) return;
    function unlock(){
      var key = keyEl.value.trim();
      if (!key) { msg.textContent = 'Enter your deploy passkey.'; keyEl.focus(); return; }
      btn.disabled = true; var t = btn.textContent; btn.textContent = 'CHECKING…'; msg.textContent = '';
      var fd = new FormData(); fd.append('action', 'smx_check_key'); fd.append('nonce', SMX_NONCE); fd.append('passkey', key);
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          btn.disabled = false; btn.textContent = t;
          if (j && j.success) {
            try { localStorage.setItem('smx-deploy-key', key); sessionStorage.setItem('smx-deploy-key', key); } catch (_) {}
            keyEl.value = ''; wbApplyLock();
          } else {
            msg.textContent = (j && j.data === 'bad-key') ? 'Passkey rejected.'
                            : (j && j.data === 'locked') ? 'Too many attempts — wait 10 minutes.'
                            : (j && j.data === 'key-not-set') ? 'No passkey set on the server yet.'
                            : 'Could not verify — try again.';
          }
        })
        .catch(function () { btn.disabled = false; btn.textContent = t; msg.textContent = 'Could not reach the server — try again.'; });
    }
    btn.addEventListener('click', unlock);
    keyEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); unlock(); } e.stopPropagation(); });
  })();

  /* ---------- Workbench tabs (Mixer | Traffic | Changelog) ---------- */
  // High-level summary of each update, newest first. (Patch runs are grouped where minor.)
  var SMX_CHANGELOG = [
    ['2.0.0-beta.13', 'Pipeline proof build — the first version delivered end-to-end through the GitHub update channel (no functional changes). If you are reading this in the Workbench, the one-click update worked.'],
    ['2.0.0-beta.12', 'STEMMAXXER now updates itself from its own GitHub release channel — new builds appear as normal one-click updates in wp-admin (with check-now, beta/stable channel switch, and one-click rollback on the Plugins screen). No more manual zip uploads.'],
    ['2.0.0-beta.11', 'Lock-screen Now-Playing artwork is now the STEMMAXXER album cover (was the low-res site favicon), with the current song’s title and artist. The widget’s play/pause, skip, and scrub controls drive the player. iOS + Android (Media Session API).'],
    ['2.0.0-beta.10', 'Mobile transport gains Restart and Reset buttons (same behavior as desktop): Restart jumps to the start and keeps playing; Reset stops, clears mute/solo/feature, returns faders to default, and clears the loop.'],
    ['2.0.0-beta.9', 'Mobile: left-justified track names + a LOADING screen that blocks play until a switched song fully loads (fixes out-of-sync playback). Desktop: track names match the channel-number size; new Workbench Fader-width control widens the LED track + handle (deployable).'],
    ['2.0.0-beta.8', 'Mobile view shows the build version next to the STEMMAXXER LITE logo.'],
    ['2.0.0-beta.7', 'Mobile track header redesign: +/− and M/S become full-height edge controls fused to the strip frame, name centered between them; the active control tints the whole frame (focus > solo > mute), with a focused strip showing solo/mute as a detached inset pill. MUTE is now blue instead of red, desktop included.'],
    ['2.0.0-beta.6', 'Fader Style (LED Ladder / Solid Fill) from the Workbench now applies to the mobile view too — deploy Solid Fill and the mobile faders match, same zone colors and thresholds as desktop.'],
    ['2.0.0-beta.5', 'More reliable song loading: stems retry with backoff instead of giving up on the first hiccup, and load a few at a time (steadier on mobile/Firefox). On mobile a failed stem shows a FILE ERROR / RETRY button to reload just that part.'],
    ['2.0.0-beta.4', 'LITE mobile: double-tap speed % to reset to 100%, loop controls centered as one cluster, playback bar timeline ticks (matching desktop), and the volume handle stays clear of the M/S buttons. Desktop: Learn button is now RTFM with a manual icon.'],
    ['2.0.0-beta.3', 'LITE mobile A/B section looping: tap A / B on the playback bar to loop just a section (draggable flags, shaded region, ⟳ to arm, ✕ to clear); no A/B = whole song.'],
    ['2.0.0-beta.2', 'LITE mobile polish: a visible + FOCUS button per channel (flips to −), speed as −/nn%/+ with + capped at 100%, channels renumbered (Drums = 1), and a chunkier high-contrast slider handle with the meter clamped so it never passes the handle.'],
    ['2.0.0-beta.1', 'STEMMAXXER LITE (beta): a finger-friendly mobile mixer. On phones the new CONSOLE view replaces the “open on desktop” screen with big touch faders, mute/solo, tap-a-name to FOCUS a part, loop, speed, and count-in/click chips — same songs, same engine. Turn on device preview to try it; Publish when ready. PADS view + skin picker next.'],
    ['1.14.35', 'On phones, the "Optimized for desktop" screen now has a "Use it here anyway" button that opens the full mixer on your phone (handy for testing) \u2014 remembered on that device. The dedicated mobile view is coming in v2.0.'],
    ['1.14.34', 'iPhone fix: songs now play even with Silent Mode on \u2014 the mixer declares itself media playback and keeps a silent loop alive, so the ring/silent switch no longer mutes the stems.'],
    ['1.14.33', 'Fixed the empty resource-type dropdown in Settings → STEMMAXXER when adding a new resource row.'],
    ['1.14.32', 'NEW Changelog tab in the Workbench (this list).'],
    ['1.14.31', 'Footer tagline and the Report-a-bug / Request-a-feature links now share one line.'],
    ['1.14.30', 'Bandmates can edit any mixer-added resource — its label, description, link or type.'],
    ['1.14.29', '“Report a bug” and “Request a feature” links in the footer email Chris directly.'],
    ['1.14.28', 'Fixed typing in a resource’s Label/Description fields (the song typeahead was stealing keystrokes).'],
    ['1.14.27', 'Footer redone as a cleaner, more readable two-line stack.'],
    ['1.14.26', 'Optional short description under each resource link.'],
    ['1.14.25', 'Resources list widened, lighter panel with an orange frame, and dims the mixer behind it — plus Workbench controls to tune it.'],
    ['1.14.24', 'Fixed the band resource Add form (all fields visible); type now auto-detects from the link.'],
    ['1.14.23', 'Song banner and Resources became one flush, segmented bar.'],
    ['1.14.22', 'Moved Resources up into the song banner, out of the crowded transport.'],
    ['1.14.21', 'NEW per-song Resources — labeled links per song; bandmates can add their own.'],
    ['1.14.20', 'The whole Workbench is now behind your deploy passkey.'],
    ['1.14.19', 'NEW Workbench “Traffic” tab — a light per-day page hit counter.'],
    ['1.14.18', 'Song titles now keep punctuation the file name can’t hold (parentheses, apostrophes, ampersands).'],
    ['1.14.17', 'New Reset button icon (mixer-faders glyph) so it no longer reads as “stop”.'],
    ['1.14.16', 'Publishing a beta feature to the band is now one-way and permanent (“baked in”).'],
    ['1.14.15', 'The A and B loop flags can be dragged along the playback bar.'],
    ['1.14.14', 'Workbench control for the A/B marker color; fixed deploy of the playback-handle colors.'],
    ['1.14.13', '“Add stem to existing song” on the on-site Add page.'],
    ['1.14.12', 'Playback bar shows a subtle timeline ruler.'],
    ['1.14.11', 'Workbench cleanup (retired the old EQ controls).'],
    ['1.14.10', 'A/B looping graduated to a permanent feature; published features now persist across updates.'],
    ['1.14.9', 'NEW band/song banner selector (beta); an A/B loop clear button.'],
    ['1.14.8', 'Workbench controls for the playback-bar drag handle.'],
    ['1.14.7', 'Playback-bar drag handle restyled (flat, hamburger lines).'],
    ['1.14.6', 'Beta/Preview became per-feature; A/B position flags; a taller playback bar.'],
    ['1.14.5', 'Workbench Beta list shows exactly which features are still unpublished.'],
    ['1.14.4', 'The “Learn” (teacher mode) button moved to the far right.'],
    ['1.14.3', 'Channel “+” feature buttons turned accent orange.'],
    ['1.14.2', 'Fixed the Preview / Publish buttons in the Workbench.'],
    ['1.14.1', 'Song selector no longer squashed by a crowded transport.'],
    ['1.14.0', 'NEW Charts/Lesson links per song, A/B section looping (beta), and the beta/preview channel.'],
    ['1.13.0', 'Each channel’s “+” feature button moved into that channel’s header.'],
    ['1.12.0', 'NEW “Click” / metronome channel.'],
    ['1.11.x', 'NEW Teacher mode (“Learn” — hover any control for a plain-English explanation); no more Save-Permalinks step.'],
    ['1.10.x', 'NEW on-site “Add a Song” page — convert Logic exports and upload right in the browser, passkey-gated.'],
    ['1.9.0', 'NEW Band__Song__Instrument naming (no track numbers); alphabetical selector; the companion Stem Converter tool.'],
    ['1.8.x', 'Deploy-live settings, a drag grip on the playback bar, a one-line keyboard legend, and polish.'],
    ['1.7.0', 'The banner shows a live EQ visualization of the playing mix.'],
    ['1.6.x', 'NEW now-loaded song banner (BAND — TITLE) and a master volume slider.'],
    ['1.5.x', 'Deploy Settings Live; the Workbench became fully hidden (Shift+W only).'],
    ['1.4.0', 'Playback bar taller and clickable; a silence watchdog.'],
    ['1.3.0', 'NEW pitch-preserved slow-down speed; automatic BPM detection.'],
    ['1.2.x', 'NEW live LED meters; a feature “+” button per stem; a meter-range control.'],
    ['1.1.0', 'NEW Workbench panel; LED-ladder faders; full-width logo.'],
    ['1.0.0', 'Initial release — the vertical channel-strip stem mixer.']
  ];
  (function () {
    var mBtn = $('wbTabMixerBtn'), tBtn = $('wbTabTrafficBtn'), lBtn = $('wbTabLogBtn'),
        mPane = $('wbPaneMixer'), tPane = $('wbPaneTraffic'), lPane = $('wbPaneLog');
    if (!mBtn || !tBtn) return;
    function renderChangelog(){
      var box = document.getElementById('clList'); if (!box || box.getAttribute('data-done')) return;
      var cur = (typeof SMX_VERSION !== 'undefined') ? String(SMX_VERSION) : '';
      var html = '';
      for (var i = 0; i < SMX_CHANGELOG.length; i++) {
        var v = SMX_CHANGELOG[i][0], t = SMX_CHANGELOG[i][1], isCur = (v === cur);
        html += '<div class="cl-row' + (isCur ? ' cur' : '') + '"><span class="cl-v">' + v + '</span>'
             +  '<span class="cl-t">' + t + (isCur ? '<span class="cl-badge">now</span>' : '') + '</span></div>';
      }
      box.innerHTML = html; box.setAttribute('data-done', '1');
    }
    function arr(){ return (SMX_STATS && SMX_STATS.days) ? SMX_STATS.days : []; }
    function maxN(){ var m=1, d=arr(); for (var i=0;i<d.length;i++) if (d[i].n>m) m=d[i].n; return m; }
    function peakN(){ var m=0, d=arr(); for (var i=0;i<d.length;i++) if (d[i].n>m) m=d[i].n; return m; }
    function sumLast(k){ var d=arr(), s=0; for (var i=Math.max(0,d.length-k);i<d.length;i++) s+=d[i].n; return s; }
    function renderTraffic(){
      var d = arr(), n = d.length;
      $('trToday').textContent = n ? d[n-1].n : 0;
      $('trYest').textContent  = n>1 ? d[n-2].n : 0;
      $('tr7').textContent     = sumLast(7);
      $('tr30').textContent    = (SMX_STATS && SMX_STATS.total) || sumLast(30);
      var mx = maxN(), chart = $('trChart'); chart.innerHTML='';
      for (var i=0;i<d.length;i++){
        var bar = document.createElement('div');
        bar.className = 'tr-bar' + (d[i].n===0?' zero':'');
        bar.style.height = Math.max(2, Math.round(d[i].n / mx * 62)) + 'px';
        bar.title = d[i].d + ': ' + d[i].n + ' hit' + (d[i].n===1?'':'s');
        chart.appendChild(bar);
      }
      var peak = peakN(), total = (SMX_STATS && SMX_STATS.total) || sumLast(30), flag = $('trFlag');
      if (peak >= 500){ flag.className='tr-flag hot'; flag.textContent = 'A single day hit ' + peak + ' — far more than a few people practicing. Worth changing the band password.'; }
      else if (peak >= 150){ flag.className='tr-flag warn'; flag.textContent = 'Busier than expected (peak ' + peak + '/day). Keep an eye on it.'; }
      else if (total === 0){ flag.className='tr-flag ok'; flag.textContent = 'No hits recorded yet.'; }
      else { flag.className='tr-flag ok'; flag.textContent = 'Looks normal for a small group.'; }
    }
    function tab(which){ // 'mixer' | 'traffic' | 'log'
      mBtn.classList.toggle('on', which === 'mixer'); mPane.classList.toggle('on', which === 'mixer');
      tBtn.classList.toggle('on', which === 'traffic'); tPane.classList.toggle('on', which === 'traffic');
      if (lBtn) lBtn.classList.toggle('on', which === 'log');
      if (lPane) lPane.classList.toggle('on', which === 'log');
      if (which === 'traffic') renderTraffic();
      if (which === 'log') renderChangelog();
    }
    mBtn.addEventListener('click', function(){ tab('mixer'); });
    tBtn.addEventListener('click', function(){ tab('traffic'); });
    if (lBtn) lBtn.addEventListener('click', function(){ tab('log'); });
  })();

  function paintSlider(el) {
    var min = +el.min, max = +el.max, v = +el.value;
    el.style.setProperty('--fill', ((v - min) / (max - min) * 100) + '%');
  }
  function bindSlider(id, lblId, unit, get, set) {
    var el = $(id), lbl = $(lblId);
    el.value = get();
    lbl.textContent = get() + unit;
    paintSlider(el);
    el.addEventListener('input', function () {
      set(+el.value);
      lbl.textContent = get() + unit;
      paintSlider(el);
      wbSave();
      wbApplyVisual();
    });
    return el;
  }

  bindSlider('sDef',  'vDef',  '%',  function(){return WB.defLevel;},  function(v){ WB.defLevel = v; });
  bindSlider('sFeat', 'vFeat', '%',  function(){return WB.featLevel;}, function(v){ WB.featLevel = v; reapplyActiveFeature(); });
  bindSlider('sDuck', 'vDuck', '%',  function(){return WB.duckLevel;}, function(v){ WB.duckLevel = v; reapplyActiveFeature(); });
  bindSlider('sSeg',  'vSeg',  'px', function(){return WB.seg;},       function(v){ WB.seg = v; });
  bindSlider('sFaderW','vFaderW','px', function(){return WB.faderW;}, function(v){ WB.faderW = v; });
  bindSlider('sZ1',   'vZ1',   '%',  function(){return WB.z1;},        function(v){ WB.z1 = v; });
  bindSlider('sZ2',   'vZ2',   '%',  function(){return WB.z2;},        function(v){ WB.z2 = v; });
  bindSlider('sZ3',   'vZ3',   '%',  function(){return WB.z3;},        function(v){ WB.z3 = v; });
  bindSlider('sLogo', 'vLogo', '%',  function(){return WB.logoW;},     function(v){ WB.logoW = v; });
  bindSlider('sMet',  'vMet',  ' dB',function(){return WB.meterDb;},   function(v){ WB.meterDb = v; });
  bindSlider('sScrub','vScrub','px', function(){return WB.scrubH;},    function(v){ WB.scrubH = v; });
  bindSlider('sGripW','vGripW','px', function(){return WB.gripW;},     function(v){ WB.gripW = v; });
  bindSlider('sNsL',  'vNsL',  'px', function(){return WB.nsL;},       function(v){ WB.nsL = v; });
  bindSlider('sNsR',  'vNsR',  'px', function(){return WB.nsR;},       function(v){ WB.nsR = v; });
  bindSlider('sResW', 'vResW', 'px', function(){return WB.resW;},      function(v){ WB.resW = v; });
  bindSlider('sResGlow','vResGlow','%', function(){return WB.resGlow;},function(v){ WB.resGlow = v; });
  bindSlider('sResScrim','vResScrim','%', function(){return WB.resScrim;}, function(v){ WB.resScrim = v; });

  function setFaderStyle(style) {
    WB.faderStyle = style;
    $('tLed').classList.toggle('on', style === 'led');
    $('tSolid').classList.toggle('on', style === 'solid');
    wbSave();
    wbApplyVisual();
  }
  $('tLed').addEventListener('click', function () { setFaderStyle('led'); });
  $('tSolid').addEventListener('click', function () { setFaderStyle('solid'); });

  function setMeters(on) {
    WB.meters = on;
    $('tMetOn').classList.toggle('on', on);
    $('tMetOff').classList.toggle('on', !on);
    wbSave();
  }
  $('tMetOn').addEventListener('click', function () { setMeters(true); });
  $('tMetOff').addEventListener('click', function () { setMeters(false); });

  function setPeakHold(on) {
    WB.peakHold = on;
    $('tPkOn').classList.toggle('on', on);
    $('tPkOff').classList.toggle('on', !on);
    wbSave();
  }
  $('tPkOn').addEventListener('click', function () { setPeakHold(true); });
  $('tPkOff').addEventListener('click', function () { setPeakHold(false); });

  var cAccent = $('cAccent');
  cAccent.value = WB.accent;
  cAccent.addEventListener('input', function () { WB.accent = cAccent.value; wbSave(); wbApplyVisual(); });
  var cScrub = $('cScrub');
  cScrub.value = WB.scrubC;
  cScrub.addEventListener('input', function () { WB.scrubC = cScrub.value; wbSave(); wbApplyVisual(); });
  var cGripBg = $('cGripBg'), cGripLn = $('cGripLn');
  cGripBg.value = WB.gripBg;
  cGripBg.addEventListener('input', function () { WB.gripBg = cGripBg.value; wbSave(); wbApplyVisual(); });
  cGripLn.value = WB.gripLines;
  cGripLn.addEventListener('input', function () { WB.gripLines = cGripLn.value; wbSave(); wbApplyVisual(); });
  var cLoop = $('cLoop');
  cLoop.value = WB.loopC;
  cLoop.addEventListener('input', function () { WB.loopC = cLoop.value; wbSave(); wbApplyVisual(); });
  var cResBg = $('cResBg'), cResBd = $('cResBd');
  cResBg.value = WB.resBg;
  cResBg.addEventListener('input', function () { WB.resBg = cResBg.value; wbSave(); wbApplyVisual(); });
  cResBd.value = WB.resBd;
  cResBd.addEventListener('input', function () { WB.resBd = cResBd.value; wbSave(); wbApplyVisual(); });
  (function () {
    var sws = document.querySelectorAll('.wb-sw');
    for (var i = 0; i < sws.length; i++) {
      (function (sw) {
        sw.addEventListener('click', function () {
          var ac = sw.getAttribute('data-c'), sc = sw.getAttribute('data-sc'),
              gb = sw.getAttribute('data-gb'), gl = sw.getAttribute('data-gl'),
              lc = sw.getAttribute('data-lc'),
              rb = sw.getAttribute('data-rb'), rf = sw.getAttribute('data-rf');
          if (ac) { WB.accent = ac; cAccent.value = ac; }
          else if (sc) { WB.scrubC = sc; cScrub.value = sc; }
          else if (gb) { WB.gripBg = gb; cGripBg.value = gb; }
          else if (gl) { WB.gripLines = gl; cGripLn.value = gl; }
          else if (lc) { WB.loopC = lc; cLoop.value = lc; }
          else if (rb) { WB.resBg = rb; cResBg.value = rb; }
          else if (rf) { WB.resBd = rf; cResBd.value = rf; }
          wbSave();
          wbApplyVisual();
        });
      })(sws[i]);
    }
  })();

  /* ---------- Teacher mode: hover any control for a plain-English explanation ---------- */
  (function () {
    var app = $('app'), toggle = $('teachToggle'), panel = $('teachPanel'), tEl = $('teachT'), dEl = $('teachD');
    if (!toggle || !panel) return;
    var on = false, curHi = null;
    var DEF_T = 'Teacher mode', DEF_D = 'Hover any button, fader, or control and its plain-English explanation appears right next to it. Click the cap again to turn this off.';
    function setPanel(t, d) { tEl.textContent = t || DEF_T; dEl.innerHTML = d || DEF_D; }
    function clearHi() { if (curHi) { curHi.classList.remove('teach-hi'); curHi = null; } }
    function highlight(el) { if (curHi === el) return; clearHi(); curHi = el; el.classList.add('teach-hi'); }

    // Place the panel next to the given element so it NEVER overlaps it. Prefers
    // below, then above, then right, then left — whichever side has room — and
    // clamps to the viewport. Panel has pointer-events:none so it can't flicker.
    function placeBy(el) {
      var r = el.getBoundingClientRect();
      var gap = 10, pad = 10;
      var pw = panel.offsetWidth, ph = panel.offsetHeight;
      var vw = window.innerWidth, vh = window.innerHeight;
      var below = vh - r.bottom, above = r.top, right = vw - r.right, left = r.left;
      var top, lft;
      if (below >= ph + gap + pad) {            // below
        top = r.bottom + gap; lft = r.left;
      } else if (above >= ph + gap + pad) {     // above
        top = r.top - gap - ph; lft = r.left;
      } else if (right >= pw + gap + pad) {     // right
        lft = r.right + gap; top = r.top;
      } else if (left >= pw + gap + pad) {      // left
        lft = r.left - gap - pw; top = r.top;
      } else {                                   // pick the roomiest side, still outside the element
        var m = Math.max(below, above, right, left);
        if (m === below)      { top = r.bottom + gap; lft = r.left; }
        else if (m === above) { top = Math.max(pad, r.top - gap - ph); lft = r.left; }
        else if (m === right) { lft = r.right + gap; top = r.top; }
        else                  { lft = Math.max(pad, r.left - gap - pw); top = r.top; }
      }
      lft = Math.max(pad, Math.min(lft, vw - pw - pad));
      top = Math.max(pad, Math.min(top, vh - ph - pad));
      panel.style.left = Math.round(lft) + 'px';
      panel.style.top  = Math.round(top) + 'px';
    }

    function setMode(next) {
      on = next;
      app.classList.toggle('teach', on);
      panel.classList.toggle('open', on);
      toggle.setAttribute('aria-pressed', on ? 'true' : 'false');
      if (on) { setPanel(DEF_T, DEF_D); placeBy(toggle); } else clearHi();
    }
    toggle.addEventListener('click', function () { setMode(!on); });
    document.addEventListener('mouseover', function (e) {
      if (!on) return;
      var el = e.target.closest ? e.target.closest('[data-teach]') : null;
      if (el && panel.contains(el)) return;            // ignore hovering the panel itself
      if (el) { setPanel(el.getAttribute('data-teach-title'), el.getAttribute('data-teach')); highlight(el); placeBy(el); }
      else { setPanel(DEF_T, DEF_D); clearHi(); placeBy(toggle); }
    });
    // ESC turns teacher mode off (only when the workbench isn't the ESC target)
    document.addEventListener('keydown', function (e) { if (on && e.key === 'Escape') setMode(false); });
  })();

  /* ---------- Add a Song: validate the passkey here, then open the uploader
       already unlocked (passkey shared to the uploader tab via localStorage) ---------- */
  (function () {
    var btn = $('wbAddSong'), keyEl = $('wbAddKey'), note = $('wbAddNote');
    if (!btn) return;
    var ADD_URL = <?php echo isset($smx_add_url) ? wp_json_encode($smx_add_url) : '""'; ?>;
    function readKey(){ try { return localStorage.getItem('smx-deploy-key') || sessionStorage.getItem('smx-deploy-key') || ''; } catch (_) { return ''; } }
    function saveKey(k){ try { localStorage.setItem('smx-deploy-key', k); sessionStorage.setItem('smx-deploy-key', k); } catch (_) {} }
    keyEl.value = readKey();
    function openUploader(){
      var pass = keyEl.value.trim();
      if (!pass) { note.textContent = 'Enter your passkey first.'; keyEl.focus(); return; }
      btn.disabled = true; var orig = btn.textContent; btn.textContent = 'CHECKING…';
      var fd = new FormData();
      fd.append('action', 'smx_check_key');
      fd.append('nonce', SMX_NONCE);
      fd.append('passkey', pass);
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          btn.disabled = false; btn.textContent = orig;
          if (res.j && res.j.success) {
            saveKey(pass);
            note.textContent = 'Passkey OK — opening the uploader in a new tab…';
            window.open(ADD_URL, '_blank', 'noopener');
            return;
          }
          var code = res.j && res.j.data ? String(res.j.data) : '';
          if (code === 'bad-key')          { note.textContent = 'Passkey rejected. (It’s the Deploy passkey in wp-content/stemmaxxer-key.php, not the band login password.)'; keyEl.focus(); }
          else if (code === 'locked')      { note.textContent = 'Too many attempts — wait 10 minutes, then try once more.'; }
          else if (code === 'key-not-set') { note.textContent = 'No passkey set on the server yet — edit wp-content/stemmaxxer-key.php and change CHANGE-ME to your secret.'; }
          else                             { note.textContent = 'Could not verify the passkey — try again.'; }
        })
        .catch(function () { btn.disabled = false; btn.textContent = orig; note.textContent = 'Could not reach the server — try again.'; });
    }
    btn.addEventListener('click', openUploader);
    keyEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); openUploader(); } e.stopPropagation(); });
  })();

  /* ---------- Beta / preview channel controls (per-feature) ---------- */
  (function () {
    var devBtn = $('wbBetaDevice'), note = $('wbBetaNote'), keyEl = $('wbBetaKey'), listEl = $('wbBetaList');
    if (!devBtn) return;
    function storedKey(){ try { return localStorage.getItem('smx-deploy-key') || sessionStorage.getItem('smx-deploy-key') || ''; } catch (_) { return ''; } }
    function getKey(){ var typed = keyEl ? keyEl.value.trim() : ''; return typed || storedKey(); }
    function rememberKey(k){ try { localStorage.setItem('smx-deploy-key', k); sessionStorage.setItem('smx-deploy-key', k); } catch (_) {} }
    if (keyEl) keyEl.value = storedKey();
    var NEEDKEY = 'Type your passkey in the box above first, then tap again.';
    function titleFor(key){ for (var i=0;i<BETA_FEATURES.length;i++){ if (BETA_FEATURES[i].key===key) return BETA_FEATURES[i].title; } return key; }
    function reflect() {
      devBtn.textContent = deviceBeta() ? 'STOP PREVIEWING ON THIS DEVICE' : 'PREVIEW NEW FEATURES ON THIS DEVICE';
      renderBetaList();
    }
    reflect();

    devBtn.addEventListener('click', function () {
      if (deviceBeta()) {
        try { localStorage.removeItem('smx-beta'); } catch (_) {}
        applyBeta(); reflect(); note.textContent = 'Preview off — this device now sees what the band sees.';
        return;
      }
      var key = getKey();
      if (!key) { note.textContent = NEEDKEY; if (keyEl) keyEl.focus(); return; }
      devBtn.disabled = true; var t = devBtn.textContent; devBtn.textContent = 'CHECKING…';
      var fd = new FormData(); fd.append('action', 'smx_check_key'); fd.append('nonce', SMX_NONCE); fd.append('passkey', key);
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          devBtn.disabled = false;
          if (j && j.success) { rememberKey(key); try { localStorage.setItem('smx-beta', '1'); } catch (_) {} applyBeta(); reflect(); note.textContent = 'Now previewing every pipeline feature on this device — the band still sees the stable version.'; }
          else { devBtn.textContent = t; note.textContent = (j && j.data === 'bad-key') ? 'Passkey rejected.' : (j && j.data === 'key-not-set') ? 'Set your passkey in wp-content/stemmaxxer-key.php first.' : 'Could not verify — try again.'; }
        })
        .catch(function () { devBtn.disabled = false; reflect(); note.textContent = 'Could not reach the server — try again.'; });
    });

    // Per-feature publish / hide — delegated so it survives re-renders of the list.
    if (listEl) listEl.addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('.bl-pub') : null;
      if (!btn || btn.disabled) return;
      var feat = btn.getAttribute('data-feat'), makeLive = btn.getAttribute('data-live') === '1';
      var key = getKey();
      if (!key) { note.textContent = NEEDKEY; if (keyEl) keyEl.focus(); return; }
      btn.disabled = true; var t = btn.textContent; btn.textContent = 'WORKING…';
      var fd = new FormData();
      fd.append('action', 'smx_preview_publish'); fd.append('nonce', SMX_NONCE);
      fd.append('passkey', key); fd.append('feature', feat); fd.append('live', makeLive ? '1' : '0');
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.success) {
            rememberKey(key);
            SMX_PUBLISHED = (j.data && j.data.features) ? j.data.features : SMX_PUBLISHED;
            applyBeta(); reflect();
            note.textContent = isPublished(feat) ? ('“' + titleFor(feat) + '” is now baked in — live for the whole band, permanently.') : ('“' + titleFor(feat) + '” updated.');
          } else {
            btn.disabled = false; btn.textContent = t;
            note.textContent = (j && j.data === 'bad-key') ? 'Passkey rejected.' : (j && j.data === 'key-not-set') ? 'Set your passkey in wp-content/stemmaxxer-key.php first.' : (j && j.data === 'no-feature') ? 'Feature not recognized.' : 'Could not publish — try again.';
          }
        })
        .catch(function () { btn.disabled = false; btn.textContent = t; note.textContent = 'Could not reach the server — try again.'; });
    });

    if (keyEl) keyEl.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); devBtn.click(); } e.stopPropagation(); });
  })();

  /* ---------- Deploy: always available, gated by a server-side passkey ---------- */
  (function () {
    var btn = $('wbDeploy'), keyRow = $('wbKeyRow'), keyInput = $('wbKey');
    var savedKey = '';
    try { savedKey = sessionStorage.getItem('smx-deploy-key') || localStorage.getItem('smx-deploy-key') || ''; } catch (_) {}

    function flash(cls, label, revert) {
      btn.classList.remove('ok', 'err');
      if (cls) btn.classList.add(cls);
      btn.textContent = label;
      if (revert) setTimeout(function () {
        btn.classList.remove('ok', 'err');
        btn.textContent = 'DEPLOY SETTINGS LIVE';
      }, 2800);
    }

    function send(passkey) {
      btn.disabled = true;
      flash(null, 'DEPLOYING…', false);
      var fd = new FormData();
      fd.append('action', 'smx_deploy_wb');
      fd.append('nonce', SMX_NONCE);
      fd.append('passkey', passkey);
      fd.append('settings', JSON.stringify(WB));
      fetch(SMX_AJAX, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
          btn.disabled = false;
          if (res.j && res.j.success) {
            for (var k in WB) WB_LIVE[k] = WB[k]; // live baseline now matches
            try { sessionStorage.setItem('smx-deploy-key', passkey); } catch (_) {}
            savedKey = passkey;
            keyRow.style.display = 'none';
            keyInput.value = '';
            flash('ok', '✓ LIVE FOR THE BAND', true);
            return;
          }
          var code = res.j && res.j.data ? String(res.j.data) : '';
          if (code === 'bad-key') {
            savedKey = '';
            try { sessionStorage.removeItem('smx-deploy-key'); } catch (_) {}
            keyRow.style.display = '';
            keyInput.value = '';
            keyInput.focus();
            flash('err', 'WRONG PASSKEY', true);
          } else if (code === 'locked') {
            flash('err', 'LOCKED — TRY IN 10 MIN', true);
          } else if (code === 'key-not-set') {
            $('wbDeployNote').textContent = 'Passkey not set yet — edit wp-content/stemmaxxer-key.php on the server and change CHANGE-ME to your secret.';
            flash('err', 'PASSKEY NOT SET ON SERVER', true);
          } else {
            flash('err', 'DEPLOY FAILED — RETRY', true);
          }
        })
        .catch(function () {
          btn.disabled = false;
          flash('err', 'DEPLOY FAILED — RETRY', true);
        });
    }

    function attempt() {
      var typed = keyInput.value.trim();
      if (typed) { send(typed); return; }
      if (savedKey) { send(savedKey); return; }
      // No key yet: reveal the input and wait for it
      keyRow.style.display = '';
      keyInput.focus();
      flash(null, 'ENTER PASSKEY, THEN DEPLOY', false);
      setTimeout(function () {
        btn.classList.remove('ok', 'err');
        if (btn.textContent === 'ENTER PASSKEY, THEN DEPLOY') btn.textContent = 'DEPLOY SETTINGS LIVE';
      }, 3200);
    }

    btn.addEventListener('click', attempt);
    keyInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); attempt(); }
      e.stopPropagation(); // keep player shortcuts out of the passkey field
    });
  })();

  $('wbReset').addEventListener('click', function () {
    // Clear local tweaks; fall back to the deployed live settings (then factory)
    try { localStorage.removeItem('smx-workbench'); } catch (_) {}
    wbSuppressSave = true;
    for (var k in WB_FACTORY) WB[k] = (WB_LIVE[k] !== undefined) ? WB_LIVE[k] : WB_FACTORY[k];
    // repaint every control
    $('sDef').value = WB.defLevel;   $('vDef').textContent  = WB.defLevel + '%';  paintSlider($('sDef'));
    $('sFeat').value = WB.featLevel; $('vFeat').textContent = WB.featLevel + '%'; paintSlider($('sFeat'));
    $('sDuck').value = WB.duckLevel; $('vDuck').textContent = WB.duckLevel + '%'; paintSlider($('sDuck'));
    $('sSeg').value = WB.seg;        $('vSeg').textContent  = WB.seg + 'px';      paintSlider($('sSeg'));
    $('sFaderW').value = WB.faderW;  $('vFaderW').textContent = WB.faderW + 'px'; paintSlider($('sFaderW'));
    $('sZ1').value = WB.z1;          $('vZ1').textContent   = WB.z1 + '%';        paintSlider($('sZ1'));
    $('sZ2').value = WB.z2;          $('vZ2').textContent   = WB.z2 + '%';        paintSlider($('sZ2'));
    $('sZ3').value = WB.z3;          $('vZ3').textContent   = WB.z3 + '%';        paintSlider($('sZ3'));
    $('sLogo').value = WB.logoW;     $('vLogo').textContent = WB.logoW + '%';     paintSlider($('sLogo'));
    $('sMet').value = WB.meterDb;    $('vMet').textContent  = WB.meterDb + ' dB'; paintSlider($('sMet'));
    $('sScrub').value = WB.scrubH;   $('vScrub').textContent = WB.scrubH + 'px';  paintSlider($('sScrub'));
    $('sGripW').value = WB.gripW;    $('vGripW').textContent = WB.gripW + 'px';   paintSlider($('sGripW'));
    $('sNsL').value = WB.nsL;        $('vNsL').textContent   = WB.nsL + 'px';     paintSlider($('sNsL'));
    $('sNsR').value = WB.nsR;        $('vNsR').textContent   = WB.nsR + 'px';     paintSlider($('sNsR'));
    $('sResW').value = WB.resW;      $('vResW').textContent  = WB.resW + 'px';    paintSlider($('sResW'));
    $('sResGlow').value = WB.resGlow;$('vResGlow').textContent = WB.resGlow + '%';paintSlider($('sResGlow'));
    $('sResScrim').value = WB.resScrim;$('vResScrim').textContent = WB.resScrim + '%';paintSlider($('sResScrim'));
    cScrub.value = WB.scrubC;
    cAccent.value = WB.accent;
    cGripBg.value = WB.gripBg;
    cGripLn.value = WB.gripLines;
    cLoop.value = WB.loopC;
    cResBg.value = WB.resBg;
    cResBd.value = WB.resBd;
    setFaderStyle(WB.faderStyle);
    setMeters(WB.meters);
    setPeakHold(WB.peakHold);
    reapplyActiveFeature();
    wbApplyVisual();
    wbSuppressSave = false;
    // stay clean of local tweaks so future deploys flow through to this browser
    try { localStorage.removeItem('smx-workbench'); } catch (_) {}
  });

  /* ---------- Resize: keep fader handles aligned ---------- */
  window.addEventListener('resize', function () { tracks.forEach(renderFader); });

  /* ---------- Init ---------- */
  wbSuppressSave = true;
  setFaderStyle(WB.faderStyle);
  setMeters(WB.meters);
  setPeakHold(WB.peakHold);
  wbApplyVisual();
  wbSuppressSave = false;
  buildSpeedMenu();
  renderBpm();

  if (!SONGS.length) {
    renderDropdownButton();
    setStatus('error', 'no songs found in media library');
    return;
  }
  var startIdx = 0;
  try {
    var saved = sessionStorage.getItem('stemmaxxer-song');
    var n = saved !== null ? parseInt(saved, 10) : NaN;
    if (!isNaN(n) && n >= 0 && n < SONGS.length) startIdx = n;
  } catch (_) {}
  currentSongIdx = startIdx;
  liteInit();
  loadSong(startIdx);
})();
</script>
</body>
</html>
